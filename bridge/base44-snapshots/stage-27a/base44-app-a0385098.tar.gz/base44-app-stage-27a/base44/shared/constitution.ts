export const DealState = Object.freeze({
  Draft: "Draft",
  PendingTarget: "PendingTarget",
  TargetReached: "TargetReached",
  ClosedForJoining: "ClosedForJoining",
  ReadyForCharging: "ReadyForCharging",
  Charging: "Charging",
  CompletionWindow: "CompletionWindow",
  Completed: "Completed",
  Failed: "Failed",
  Cancelled: "Cancelled",
} as const);

export const BuyerState = Object.freeze({
  NotJoined: "NotJoined",
  JoinedAuthorized: "JoinedAuthorized",
  LockedIn: "LockedIn",
  ChargingAttempt: "ChargingAttempt",
  ChargedSuccess: "ChargedSuccess",
  ChargeFailedCompletion: "ChargeFailedCompletion",
  Recovered: "Recovered",
  Dropped: "Dropped",
  DealCompleted: "DealCompleted",
  DealFailed: "DealFailed",
} as const);

export const MoneyState = Object.freeze({
  NoFinancial: "NoFinancial",
  AuthHeld: "AuthHeld",
  AuthLocked: "AuthLocked",
  ChargeAttempt: "ChargeAttempt",
  ChargedSuccess: "ChargedSuccess",
  ChargeFailedRecovery: "ChargeFailedRecovery",
  RecoveredCharge: "RecoveredCharge",
  AuthReleased: "AuthReleased",
  Refunded: "Refunded",
} as const);

export const Action = Object.freeze({
  DealPublish: "deal.publish",
  DealCloseJoining: "deal.close_joining",
  DealPrepareCharging: "deal.prepare_charging",
  ChargingStart: "charging.start",
  ChargingRecovery: "charging.recovery",
  ChargingFinalize: "charging.finalize",
  RefundIssue: "refund.issue",
} as const);

export const ErrorCode = Object.freeze({
  InvalidInput: "INVALID_INPUT",
  IllegalStateTransition: "ILLEGAL_STATE_TRANSITION",
  NotInWindow: "NOT_IN_WINDOW",
  WindowNotExpired: "WINDOW_NOT_EXPIRED",
  IdempotentReplay: "IDEMPOTENT_REPLAY",
  PaymentFailed: "PAYMENT_FAILED",
  AuthExpired: "AUTH_EXPIRED",
  ForbiddenAction: "FORBIDDEN_ACTION",
  TemporarilyUnavailable: "TEMPORARILY_UNAVAILABLE",
} as const);

export const DEAL_TRANSITIONS: Record<string, readonly string[]> = Object.freeze({
  [DealState.Draft]: Object.freeze([DealState.PendingTarget]),
  [DealState.PendingTarget]: Object.freeze([DealState.TargetReached, DealState.Failed]),
  [DealState.TargetReached]: Object.freeze([DealState.ClosedForJoining]),
  [DealState.ClosedForJoining]: Object.freeze([DealState.ReadyForCharging]),
  [DealState.ReadyForCharging]: Object.freeze([DealState.Charging]),
  [DealState.Charging]: Object.freeze([DealState.CompletionWindow]),
  [DealState.CompletionWindow]: Object.freeze([DealState.Completed, DealState.Failed]),
  [DealState.Completed]: Object.freeze([]),
  [DealState.Failed]: Object.freeze([]),
  [DealState.Cancelled]: Object.freeze([]),
});

export const BUYER_TRANSITIONS: Record<string, readonly string[]> = Object.freeze({
  [BuyerState.NotJoined]: Object.freeze([BuyerState.JoinedAuthorized, BuyerState.DealFailed]),
  [BuyerState.JoinedAuthorized]: Object.freeze([BuyerState.LockedIn, BuyerState.DealFailed]),
  [BuyerState.LockedIn]: Object.freeze([BuyerState.ChargingAttempt, BuyerState.DealFailed]),
  [BuyerState.ChargingAttempt]: Object.freeze([BuyerState.ChargedSuccess, BuyerState.ChargeFailedCompletion, BuyerState.DealFailed]),
  [BuyerState.ChargeFailedCompletion]: Object.freeze([BuyerState.Recovered, BuyerState.Dropped, BuyerState.DealFailed]),
  [BuyerState.ChargedSuccess]: Object.freeze([BuyerState.DealCompleted, BuyerState.DealFailed]),
  [BuyerState.Recovered]: Object.freeze([BuyerState.DealCompleted, BuyerState.DealFailed]),
  [BuyerState.Dropped]: Object.freeze([BuyerState.DealFailed]),
  [BuyerState.DealCompleted]: Object.freeze([]),
  [BuyerState.DealFailed]: Object.freeze([]),
});

export const MONEY_TRANSITIONS: Record<string, readonly string[]> = Object.freeze({
  [MoneyState.NoFinancial]: Object.freeze([MoneyState.AuthHeld]),
  [MoneyState.AuthHeld]: Object.freeze([MoneyState.AuthLocked]),
  [MoneyState.AuthLocked]: Object.freeze([MoneyState.ChargeAttempt]),
  [MoneyState.ChargeAttempt]: Object.freeze([MoneyState.ChargedSuccess, MoneyState.ChargeFailedRecovery]),
  [MoneyState.ChargeFailedRecovery]: Object.freeze([MoneyState.RecoveredCharge, MoneyState.AuthReleased]),
  [MoneyState.ChargedSuccess]: Object.freeze([MoneyState.Refunded]),
  [MoneyState.RecoveredCharge]: Object.freeze([]),
  [MoneyState.AuthReleased]: Object.freeze([]),
  [MoneyState.Refunded]: Object.freeze([]),
});

export function thresholdUnits(minUnits: number) {
  if (!Number.isInteger(minUnits) || minUnits < 1) throw new Error("min_units must be a positive integer");
  return Math.ceil(0.9 * minUnits);
}

function constitutionalError(message: string, status: number, code: string, extra: Record<string, unknown> = {}) {
  return Object.assign(new Error(message), { status, code, ...extra });
}

export function assertChargingStartAllowed(dealState: string, completionWindowUntil?: string | null) {
  if (dealState === DealState.CompletionWindow) throw constitutionalError("charging.start is forbidden inside CompletionWindow", 403, ErrorCode.ForbiddenAction);
  if (dealState !== DealState.ReadyForCharging) throw constitutionalError("charging.start requires ReadyForCharging", 409, ErrorCode.IllegalStateTransition);
  if (completionWindowUntil) throw constitutionalError("completion window already exists before charging.start", 409, ErrorCode.IllegalStateTransition);
}

export function assertRecoveryAllowed(dealState: string, completionWindowUntil: string | null | undefined, eligibleParticipantCount: number, nowMs = Date.now(), allowTimeoutReconcile = false) {
  if (dealState !== DealState.CompletionWindow) throw constitutionalError("charging.recovery requires CompletionWindow", 409, ErrorCode.NotInWindow);
  const untilMs = Date.parse(String(completionWindowUntil || ""));
  if (!Number.isFinite(untilMs)) throw constitutionalError("completion window missing", 409, ErrorCode.NotInWindow);
  if (nowMs >= untilMs && !allowTimeoutReconcile) throw constitutionalError("completion window expired", 409, ErrorCode.NotInWindow);
  if (eligibleParticipantCount < 1) throw constitutionalError("charging.recovery requires ChargeFailedCompletion participant", 403, ErrorCode.ForbiddenAction);
}

export function assertFinalizeAllowed(dealState: string, completionWindowUntil: string | null | undefined, nowMs = Date.now()) {
  if (dealState !== DealState.CompletionWindow) throw constitutionalError("charging.finalize requires CompletionWindow", 409, ErrorCode.NotInWindow);
  const completionMs = Date.parse(String(completionWindowUntil || ""));
  if (!Number.isFinite(completionMs)) throw constitutionalError("completion window missing", 409, ErrorCode.IllegalStateTransition);
  if (nowMs < completionMs) throw constitutionalError("completion window has not expired", 409, ErrorCode.WindowNotExpired, { retry_at: new Date(completionMs).toISOString() });
}

export function resolveFinalDealState(capturedUnits: number, threshold: number) {
  return Math.max(0, Number(capturedUnits || 0)) >= Math.max(0, Number(threshold || 0)) ? DealState.Completed : DealState.Failed;
}

function assertTransition(table: Record<string, readonly string[]>, kind: string, fromState: string, toState: string) {
  if (!table[fromState]?.includes(toState)) {
    const error: any = new Error(`illegal ${kind} transition ${fromState} -> ${toState}`);
    error.status = 409;
    error.code = ErrorCode.IllegalStateTransition;
    throw error;
  }
}

export function assertDealTransition(fromState: string, toState: string) {
  assertTransition(DEAL_TRANSITIONS, "deal", fromState, toState);
}
export function assertBuyerTransition(fromState: string, toState: string) {
  assertTransition(BUYER_TRANSITIONS, "buyer", fromState, toState);
}
export function assertMoneyTransition(fromState: string, toState: string) {
  assertTransition(MONEY_TRANSITIONS, "money", fromState, toState);
}
