function isEmail(value: unknown) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || "").trim().toLowerCase());
}
function isPhone(value: unknown) {
  const normalized = String(value || "").replace(/[^0-9+]/g, "");
  return /^\+?[0-9]{7,15}$/.test(normalized);
}

export async function ensureNotification(admin: any, args: {
  eventType: string;
  recipientType: "buyer" | "seller" | "admin";
  dealId?: string | null;
  participantId?: string | null;
  sellerId?: string | null;
  channel: "sms" | "email";
  templateKey: string;
  payload?: Record<string, unknown>;
  keySeed: string;
}) {
  const idempotencyKey = `notification:${args.eventType}:${args.keySeed}:${args.channel}`.slice(0, 400);
  const prior = await admin.entities.NotificationEvent.filter({ idempotency_key: idempotencyKey }, "-created_at", 1).catch(() => []);
  if (prior?.[0]) return prior[0];
  const at = new Date().toISOString();
  const created = await admin.entities.NotificationEvent.create({
    notification_id: crypto.randomUUID(),
    event_type: args.eventType,
    recipient_type: args.recipientType,
    recipient_ref: null,
    deal_id: args.dealId || null,
    participant_id: args.participantId || null,
    seller_id: args.sellerId || null,
    channel: args.channel,
    template_key: args.templateKey,
    locale: "he-IL",
    payload_jsonb: args.payload || {},
    status: "pending",
    idempotency_key: idempotencyKey,
    attempt_count: 0,
    max_attempts: 3,
    scheduled_for: at,
    created_at: at,
    updated_at: at,
    event_journal: [{ event_type: "notification.queued", created_at: at, payload: { event_type: args.eventType, channel: args.channel } }]
  }).catch(() => undefined);
  if (created) return created;
  const recovered = await admin.entities.NotificationEvent.filter({ idempotency_key: idempotencyKey }, "-created_at", 1).catch(() => []);
  if (recovered?.[0]) return recovered[0];
  throw Object.assign(new Error("notification projection could not be created"), { status: 503, code: "notification_projection_failed" });
}

export async function enqueueBuyerNotifications(admin: any, deal: any, reservation: any, eventType: string, templateKey: string, payload: Record<string, unknown>, keySeed: string) {
  const participantId = String(reservation?.participant_id || "");
  if (!participantId) return;
  const common = { eventType, recipientType: "buyer" as const, dealId: String(deal?.deal_id || ""), participantId, sellerId: String(deal?.seller_id || "") || null, templateKey, payload, keySeed: `${keySeed}:${participantId}` };
  if (isPhone(reservation?.buyer_phone)) await ensureNotification(admin, { ...common, channel: "sms" });
  const email = isEmail(reservation?.buyer_email) ? reservation.buyer_email : isEmail(reservation?.buyer_id) ? reservation.buyer_id : null;
  if (email) await ensureNotification(admin, { ...common, channel: "email" });
}

export async function enqueueSellerNotifications(admin: any, deal: any, eventType: string, templateKey: string, payload: Record<string, unknown>, keySeed: string) {
  const sellerId = String(deal?.seller_id || "");
  if (!sellerId) return;
  const seller = (await admin.entities.SellerAccount.filter({ seller_id: sellerId }, "-created_date", 1).catch(() => []))?.[0];
  if (!seller) return;
  const common = { eventType, recipientType: "seller" as const, dealId: String(deal?.deal_id || ""), sellerId, participantId: null, templateKey, payload, keySeed: `${keySeed}:${sellerId}` };
  if (isPhone(seller.support_phone)) await ensureNotification(admin, { ...common, channel: "sms" });
  if (isEmail(seller.support_email)) await ensureNotification(admin, { ...common, channel: "email" });
}
