import { ErrorCode } from "./constitution.ts";

const encoder = new TextEncoder();
const CANONICAL_COMMISSION_RATE = 0.08;
const CANONICAL_COMPLETION_WINDOW_HOURS = 24;

function integritySecret() {
  const secret = String(Deno.env.get("DEAL_TERMS_INTEGRITY_SECRET") || "");
  if (secret.length < 32) throw Object.assign(new Error("DEAL_TERMS_INTEGRITY_SECRET is not configured"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
  return secret;
}
function stable(value: any): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stable).join(",")}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stable(value[key])}`).join(",")}}`;
}
async function hmacHex(secret: string, value: string) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const bits = await crypto.subtle.sign("HMAC", key, encoder.encode(value));
  return [...new Uint8Array(bits)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function equalHex(a: unknown, b: unknown) {
  const left = String(a || "").toLowerCase();
  const right = String(b || "").toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(left) || !/^[0-9a-f]{64}$/.test(right)) return false;
  let diff = 0;
  for (let index = 0; index < left.length; index += 1) diff |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return diff === 0;
}

export function canonicalCriticalTerms(deal: any, overrides: Record<string, unknown> = {}) {
  return {
    deal_id: String(overrides.deal_id ?? deal?.deal_id ?? ""),
    published_at: String(overrides.published_at ?? deal?.published_at ?? ""),
    price_per_unit: Number(overrides.price_per_unit ?? deal?.price_per_unit ?? 0),
    min_units: Number(overrides.min_units ?? deal?.min_units ?? 0),
    max_units: Number(overrides.max_units ?? deal?.max_units ?? 0),
    deadline: String(overrides.deadline ?? deal?.deadline ?? ""),
    commission_rate: Number(overrides.commission_rate ?? deal?.commission_rate ?? CANONICAL_COMMISSION_RATE),
    completion_window_hours: Number(overrides.completion_window_hours ?? deal?.completion_window_hours ?? CANONICAL_COMPLETION_WINDOW_HOURS),
    threshold_units: Number(overrides.threshold_units ?? deal?.threshold_units ?? 0),
  };
}

export async function signCriticalTerms(deal: any, overrides: Record<string, unknown> = {}) {
  const terms = canonicalCriticalTerms(deal, overrides);
  if (!terms.deal_id || !terms.published_at || !(terms.price_per_unit > 0) || !(terms.min_units > 0) || !(terms.max_units >= terms.min_units) || !(terms.threshold_units > 0)) {
    throw Object.assign(new Error("critical Deal terms are incomplete and cannot be signed"), { status: 409, code: ErrorCode.IllegalStateTransition });
  }
  if (terms.commission_rate !== CANONICAL_COMMISSION_RATE || terms.completion_window_hours !== CANONICAL_COMPLETION_WINDOW_HOURS) {
    throw Object.assign(new Error("critical Deal constants differ from the current Siton contract"), { status: 409, code: ErrorCode.IllegalStateTransition });
  }
  return hmacHex(integritySecret(), `siton:deal-critical:v1:${stable(terms)}`);
}

export async function assertCriticalTermsIntegrity(deal: any) {
  const expected = await signCriticalTerms(deal);
  if (!equalHex(deal?.critical_terms_signature, expected)) {
    throw Object.assign(new Error("published Deal critical terms failed integrity verification"), { status: 409, code: ErrorCode.IllegalStateTransition });
  }
  return true;
}

export async function signCompletionWindow(deal: any, completionWindowUntil: string) {
  await assertCriticalTermsIntegrity(deal);
  const canonical = {
    deal_id: String(deal?.deal_id || ""),
    completion_window_hours: Number(deal?.completion_window_hours ?? CANONICAL_COMPLETION_WINDOW_HOURS),
    completion_window_until: String(completionWindowUntil || ""),
  };
  if (!canonical.deal_id || !Number.isFinite(Date.parse(canonical.completion_window_until)) || canonical.completion_window_hours !== CANONICAL_COMPLETION_WINDOW_HOURS) {
    throw Object.assign(new Error("completion window cannot be signed"), { status: 409, code: ErrorCode.IllegalStateTransition });
  }
  return hmacHex(integritySecret(), `siton:completion-window:v1:${stable(canonical)}`);
}

export async function assertCompletionWindowIntegrity(deal: any) {
  await assertCriticalTermsIntegrity(deal);
  const until = String(deal?.completion_window_until || "");
  if (!until) throw Object.assign(new Error("completion window is missing"), { status: 409, code: ErrorCode.NotInWindow });
  const expected = await signCompletionWindow({ ...deal, completion_window_until: until }, until);
  if (!equalHex(deal?.completion_window_signature, expected)) {
    throw Object.assign(new Error("completion window failed integrity verification"), { status: 409, code: ErrorCode.IllegalStateTransition });
  }
  return true;
}

export const SITON_CRITICAL_TERMS = Object.freeze({ commission_rate: CANONICAL_COMMISSION_RATE, completion_window_hours: CANONICAL_COMPLETION_WINDOW_HOURS });
