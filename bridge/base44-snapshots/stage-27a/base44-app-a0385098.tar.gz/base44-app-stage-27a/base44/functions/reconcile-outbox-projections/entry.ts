import { DealState } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const ALLOWED_EVENT_TYPES = new Set([
  "charge_deal",
  "recovery_deal",
  "finalize_deal",
  "refund_issue",
  "deadline_check",
  "cancel_refund"
]);

function safeEvent(raw: any) {
  if (!raw || typeof raw !== "object") return null;
  const eventUuid = String(raw.event_uuid || "").trim();
  const aggregateId = String(raw.aggregate_id || "").trim();
  const eventType = String(raw.event_type || "").trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(eventUuid)) return null;
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(aggregateId)) return null;
  if (!ALLOWED_EVENT_TYPES.has(eventType)) return null;
  return {
    event_uuid: eventUuid,
    aggregate_type: raw.aggregate_type === "participant" ? "participant" : "deal",
    aggregate_id: aggregateId,
    event_type: eventType,
    status: ["pending", "processing", "sent", "failed", "dead_letter"].includes(String(raw.status || "")) ? String(raw.status) : "pending",
    payload: raw.payload && typeof raw.payload === "object" && !Array.isArray(raw.payload) ? raw.payload : {},
    idempotency_key: String(raw.idempotency_key || `${eventType}:${aggregateId}`),
    available_at: raw.available_at || new Date().toISOString(),
    attempt_count: Math.max(0, Number(raw.attempt_count || 0)),
    max_attempts: Math.max(1, Number(raw.max_attempts || 4)),
    lease_owner: raw.lease_owner || null,
    lease_expires_at: raw.lease_expires_at || null,
    last_error: raw.last_error || null,
    processed_at: raw.processed_at || null
  };
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return Response.json({ ok: false, error: "method_not_allowed" }, { status: 405 });
  const base44 = createClientFromRequest(req);
  let body: any = {};
  try { body = await req.json(); } catch { body = {}; }

  const requestedDealId = String(body?.deal_id || "").trim();
  let deals: any[] = [];
  if (requestedDealId) {
    deals = await base44.asServiceRole.entities.Deal.filter({ deal_id: requestedDealId }, "-created_date", 1);
  } else {
    deals = await base44.asServiceRole.entities.Deal.filter({ state: { $in: [DealState.Charging, DealState.CompletionWindow, DealState.Completed, DealState.Failed] } }, "-updated_date", 200);
  }

  let inspected = 0;
  let created = 0;
  let alreadyPresent = 0;
  let invalid = 0;
  const createdEventUuids: string[] = [];

  for (const deal of deals || []) {
    const embedded = Array.isArray(deal?.outbox_events) ? deal.outbox_events : [];
    for (const raw of embedded) {
      inspected += 1;
      const event = safeEvent(raw);
      if (!event) {
        invalid += 1;
        continue;
      }
      const existing = await base44.asServiceRole.entities.OutboxEvent.filter({ event_uuid: event.event_uuid }, "-created_date", 1);
      if (existing?.[0]) {
        alreadyPresent += 1;
        continue;
      }
      try {
        await base44.asServiceRole.entities.OutboxEvent.create(event);
        created += 1;
        createdEventUuids.push(event.event_uuid);
      } catch {
        const raced = await base44.asServiceRole.entities.OutboxEvent.filter({ event_uuid: event.event_uuid }, "-created_date", 1);
        if (raced?.[0]) alreadyPresent += 1;
        else throw new Error(`failed to rebuild outbox projection ${event.event_uuid}`);
      }
    }
  }

  return Response.json({
    ok: true,
    mode: "projection-reconciliation-only",
    money_side_effects: false,
    deals_inspected: (deals || []).length,
    events_inspected: inspected,
    projections_created: created,
    already_present: alreadyPresent,
    invalid_embedded_events: invalid,
    created_event_uuids: createdEventUuids
  });
});
