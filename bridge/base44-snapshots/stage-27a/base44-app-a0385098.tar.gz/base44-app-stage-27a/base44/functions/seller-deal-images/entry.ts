import { DealState, ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const MIME = new Set(["image/jpeg","image/png","image/webp"]);
function fail(status:number,error:string,code?:string){return Response.json({ok:false,error,...(code?{code}:{})},{status});}
function uuid(value:unknown){const t=String(value||"").trim();return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(t)?t:"";}
function safeUrl(value:unknown){const t=String(value||"").trim();try{const u=new URL(t);const canonical=(u.hostname==="media.base44.com"&&u.pathname.startsWith("/images/public/"))||(u.hostname==="static.wixstatic.com"&&u.pathname.startsWith("/media/"));return u.protocol==="https:"&&!u.username&&!u.password&&(!u.port||u.port==="443")&&canonical?u.toString():"";}catch{return "";}}
function safeImages(deal:any){return (Array.isArray(deal.images)?deal.images:[]).slice().sort((a:any,b:any)=>Number(a.sort_order||0)-Number(b.sort_order||0)).map((row:any)=>({image_id:row.image_id,file_url:row.file_url,mime_type:row.mime_type,file_name:row.file_name||null,sort_order:Number(row.sort_order||0),created_at:row.created_at||null}));}

Deno.serve(async(req)=>{
 if(req.method!=="POST")return fail(405,"method_not_allowed", ErrorCode.ForbiddenAction);
 const base44=createClientFromRequest(req);let user:any;try{user=await base44.auth.me();}catch{return fail(401,"authentication required",ErrorCode.ForbiddenAction);}
 if(!user?.id)return fail(401,"authentication required", ErrorCode.ForbiddenAction);
 let body:any;try{body=await req.json();}catch{return fail(400,"invalid JSON body",ErrorCode.InvalidInput);}
 const dealId=uuid(body?.deal_id);if(!dealId)return fail(400,"deal_id must be a UUID", ErrorCode.InvalidInput);
 const admin=base44.asServiceRole;const deal=(await admin.entities.Deal.filter({deal_id:dealId,owner_user_id:String(user.id)},"-created_date",1))?.[0];if(!deal)return fail(404,"deal not found", ErrorCode.InvalidInput);
 const operation=String(body?.operation||"list");
 if(operation==="list")return Response.json({ok:true,deal_id:dealId,state:String(deal.state||""),images:safeImages(deal),editable:String(deal.state)===DealState.Draft});
 if(String(deal.state)!==DealState.Draft)return fail(409,"deal images can be changed only while Draft", ErrorCode.IllegalStateTransition);
 const current=safeImages(deal);
 if(operation==="attach"){
   const fileUrl=safeUrl(body.file_url);const mime=String(body.mime_type||"");if(!fileUrl)return fail(400,"file_url must be a canonical Base44 public image URL",ErrorCode.InvalidInput);if(!MIME.has(mime))return fail(400,"unsupported image MIME type", ErrorCode.InvalidInput);
   const rawName=String(body.file_name||"").normalize("NFC").trim();if(rawName.includes("/")||rawName.includes("\\")||rawName.includes("\0"))return fail(400,"invalid image filename",ErrorCode.InvalidInput);const fileName=rawName.slice(0,200)||null;
   const image={image_id:crypto.randomUUID(),file_url:fileUrl,mime_type:mime,file_name:fileName,sort_order:current.length,created_at:new Date().toISOString()};
   await admin.entities.Deal.update(deal.id,{images:[...current,image]});
   return Response.json({ok:true,image,images:[...current,image]});
 }
 if(operation==="remove"){
   const imageId=uuid(body.image_id);if(!imageId)return fail(400,"image_id must be a UUID", ErrorCode.InvalidInput);
   const next=current.filter((row:any)=>String(row.image_id)!==imageId).map((row:any,index:number)=>({...row,sort_order:index}));if(next.length===current.length)return fail(404,"image not found", ErrorCode.InvalidInput);
   await admin.entities.Deal.update(deal.id,{images:next});return Response.json({ok:true,images:next});
 }
 if(operation==="reorder"){
   const ids=Array.isArray(body.image_ids)?body.image_ids.map((v:any)=>String(v)):[];if(ids.length!==current.length||new Set(ids).size!==current.length||current.some((row:any)=>!ids.includes(String(row.image_id))))return fail(400,"image_ids must contain every current image exactly once", ErrorCode.InvalidInput);
   const byId=new Map(current.map((row:any)=>[String(row.image_id),row]));const next=ids.map((id:string,index:number)=>({...byId.get(id),sort_order:index}));await admin.entities.Deal.update(deal.id,{images:next});return Response.json({ok:true,images:next});
 }
 return fail(400,"unsupported image operation", ErrorCode.InvalidInput);
});
