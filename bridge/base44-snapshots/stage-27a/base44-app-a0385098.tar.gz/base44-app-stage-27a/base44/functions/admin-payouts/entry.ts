import { DealState, ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const BLOCKING_PAYOUT_STATUSES = new Set(["batched", "processing", "paid", "reconciled"]);
function fail(status: number, error: string, code?: string) { return Response.json({ ok:false, error, ...(code?{code}:{}) }, { status }); }
function round(value: number) { return Math.round((Number(value)||0)*100)/100; }
function sum(rows: any[], field: string) { return round(rows.reduce((n,row)=>n+Number(row?.[field]||0),0)); }
function event(type:string, actor:string, payload:any={}) { return { event_type:type, created_at:new Date().toISOString(), actor_user_id:actor, payload }; }
async function sha256(value:string) { const buf=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(value)); return [...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,"0")).join(""); }

async function payoutFrozen(admin:any, sellerId:string, dealId:string) {
  const rows=await admin.entities.AdminControlFlag.filter({ flag_type:"payout_freeze", status:"active" },"-created_at",500).catch(()=>[]);
  const now=Date.now();
  return (rows||[]).some((row:any)=>{
    if(row.expires_at){const ms=Date.parse(String(row.expires_at));if(Number.isFinite(ms)&&ms<=now)return false;}
    const scope=String(row.scope_type||"global"),id=String(row.scope_id||"");
    return scope==="global"||(scope==="seller"&&id===sellerId)||(scope==="deal"&&id===dealId);
  });
}

async function refreshSettlements(admin:any, actorId:string) {
  const [deals,sellers,existing,batches]=await Promise.all([
    admin.entities.Deal.list("-created_date",5000),
    admin.entities.SellerAccount.list("-created_date",1000),
    admin.entities.SellerSettlement.list("-last_calculated_at",5000).catch(()=>[]),
    admin.entities.SellerPayoutBatch.list("-created_at",5000).catch(()=>[])
  ]);
  const sellerById=new Map((sellers||[]).map((row:any)=>[String(row.seller_id||""),row]));
  const settlementByDeal=new Map((existing||[]).map((row:any)=>[String(row.deal_id||""),row]));
  const payoutByDeal=new Map<string,string[]>();
  for(const batch of batches||[]) for(const dealId of Array.isArray(batch.deal_ids)?batch.deal_ids:[]) {
    const rows=payoutByDeal.get(String(dealId))||[];rows.push(String(batch.payout_status||""));payoutByDeal.set(String(dealId),rows);
  }
  let refreshed=0;
  for(const deal of deals||[]) {
    const dealId=String(deal.deal_id||""); const sellerId=String(deal.seller_id||"");
    if(!dealId||!sellerId) continue;
    const seller=sellerById.get(sellerId);
    const ledger=Array.isArray(deal.money_ledger_events)?deal.money_ledger_events:[];
    const gross=sum(ledger,"gross_amount");
    const fee=sum(ledger,"platform_fee_total_amount");
    const sellerNet=sum(ledger,"seller_net_amount");
    const refunds=round(ledger.filter((r:any)=>Number(r.gross_amount||0)<0).reduce((n:number,r:any)=>n+Math.abs(Number(r.gross_amount||0)),0));
    const statuses=payoutByDeal.get(dealId)||[];
    const blocking:string[]=[];
    if(String(deal.state||"")!==DealState.Completed) blocking.push(`deal_state_${String(deal.state||"").toLowerCase()}`);
    const settlementStatus=String(seller?.settlement_status||"active");
    if(settlementStatus!=="active") blocking.push(`seller_settlement_status_${settlementStatus}`);
    if(!(gross>0)) blocking.push("no_gross_collected");
    if(!(sellerNet>0)) blocking.push("seller_net_non_positive");
    if(statuses.some((s:string)=>BLOCKING_PAYOUT_STATUSES.has(s))) blocking.push("deal_already_payouted_or_inflight");
    if(await payoutFrozen(admin,sellerId,dealId)) blocking.push("payout_freeze_admin_flag_active");
    const eligible=blocking.length===0;
    const previous=settlementByDeal.get(dealId);
    let payoutStatus=String(previous?.payout_status||"pending");
    if(!["batched","processing","paid","failed","returned","reconciled"].includes(payoutStatus)) payoutStatus=eligible?"ready":"pending";
    const now=new Date().toISOString();
    const snapshot={
      seller_id:sellerId,deal_id:dealId,payout_status:payoutStatus,gross_collected:gross,platform_fee_total:fee,refunds_total:refunds,reserve_amount:0,
      seller_net_payable:sellerNet,payout_amount:eligible?sellerNet:0,paid_amount:["paid","reconciled"].includes(payoutStatus)?Math.max(0,sellerNet):0,
      failed_amount:payoutStatus==="failed"?Math.max(0,sellerNet):0,returned_amount:payoutStatus==="returned"?Math.max(0,sellerNet):0,
      blocked_amount:!eligible&&sellerNet>0?sellerNet:0,delayed_amount:0,source_money_event_count:ledger.length,blocking_reasons:blocking,eligible,
      financial_rules_version:String(ledger.at(-1)?.financial_rules_version||"siton-platform-fee-v1"),last_calculated_at:now
    };
    if(previous) {
      await admin.entities.SellerSettlement.updateMany({ settlement_id:String(previous.settlement_id) },{ $set:snapshot, $push:{ event_journal:event("seller_settlement.recalculated",actorId,{ eligible, blocking_reasons:blocking }) } });
    } else {
      await admin.entities.SellerSettlement.create({ settlement_id:crypto.randomUUID(),...snapshot,event_journal:[event("seller_settlement.created",actorId,{ eligible, blocking_reasons:blocking })] });
    }
    refreshed+=1;
  }
  return refreshed;
}

Deno.serve(async(req)=>{
  if(req.method!=="POST") return fail(405,"method_not_allowed", ErrorCode.ForbiddenAction);
  const base44=createClientFromRequest(req);let user:any;try{user=await base44.auth.me();}catch{return fail(401,"authentication required",ErrorCode.ForbiddenAction);}
  if(String(user?.role||"")!=="admin") return fail(403,"admin required", ErrorCode.ForbiddenAction);
  let body:any;try{body=await req.json();}catch{return fail(400,"invalid JSON body",ErrorCode.InvalidInput);}
  const admin=base44.asServiceRole,operation=String(body?.operation||"list"),actorId=String(user.id||"");

  if(operation==="refresh"||operation==="list") await refreshSettlements(admin,actorId);

  if(operation==="create_batch") {
    const sellerId=String(body?.seller_id||"").trim(); if(!sellerId) return fail(400,"seller_id required", ErrorCode.InvalidInput);
    await refreshSettlements(admin,actorId);
    const ready=(await admin.entities.SellerSettlement.filter({ seller_id:sellerId, payout_status:"ready", eligible:true },"deal_id",1000).catch(()=>[]));
    const selectedIds=Array.isArray(body?.settlement_ids)?new Set(body.settlement_ids.map(String)):null;
    const rows=(ready||[]).filter((row:any)=>!selectedIds||selectedIds.has(String(row.settlement_id)));
    if(!rows.length) return fail(409,"no ready settlements for seller", ErrorCode.IllegalStateTransition);
    const ids=rows.map((r:any)=>String(r.settlement_id)).sort();
    const batchKey=`seller-payout:${sellerId}:${await sha256(ids.join("|"))}`;
    const prior=(await admin.entities.SellerPayoutBatch.filter({ batch_key:batchKey },"-created_at",1))?.[0];
    if(prior) return Response.json({ok:true,batch:prior,replay:true,external_transfer_executed:false});
    const at=new Date().toISOString(),batchId=crypto.randomUUID();
    const batch=await admin.entities.SellerPayoutBatch.create({
      payout_batch_id:batchId,batch_key:batchKey,seller_id:sellerId,payout_status:"batched",settlement_ids:ids,deal_ids:rows.map((r:any)=>String(r.deal_id)),settlement_count:rows.length,
      gross_collected:sum(rows,"gross_collected"),platform_fee_total:sum(rows,"platform_fee_total"),refunds_total:sum(rows,"refunds_total"),seller_net_payable:sum(rows,"seller_net_payable"),payout_amount:sum(rows,"payout_amount"),
      provider_code:"internal-truth-only",correlation_id:`payout:${batchId}`,attempt_count:0,created_by_user_id:actorId,created_at:at,updated_at:at,event_journal:[event("seller_payout_batch.created",actorId,{ settlement_ids:ids })]
    });
    for(const row of rows) await admin.entities.SellerSettlement.updateMany({ settlement_id:String(row.settlement_id), payout_status:"ready" },{ $set:{ payout_status:"batched",payout_batch_id:batchId },$push:{event_journal:event("seller_settlement.batched",actorId,{payout_batch_id:batchId})} });
    return Response.json({ok:true,batch,replay:false,external_transfer_executed:false});
  }

  if(operation==="dispatch"||operation==="retry") {
    return fail(503,"external payout provider is not connected; no transfer was executed", ErrorCode.TemporarilyUnavailable);
  }

  if(operation==="list"||operation==="refresh") {
    const [settlements,batches]=await Promise.all([admin.entities.SellerSettlement.list("-last_calculated_at",5000),admin.entities.SellerPayoutBatch.list("-created_at",5000)]);
    const summary={
      ready:(settlements||[]).filter((r:any)=>r.payout_status==="ready").length,
      batched:(settlements||[]).filter((r:any)=>r.payout_status==="batched").length,
      processing:(settlements||[]).filter((r:any)=>r.payout_status==="processing").length,
      paid:(settlements||[]).filter((r:any)=>["paid","reconciled"].includes(String(r.payout_status))).length,
      failed:(settlements||[]).filter((r:any)=>r.payout_status==="failed").length,
      ready_amount:round((settlements||[]).filter((r:any)=>r.payout_status==="ready").reduce((n:number,r:any)=>n+Number(r.payout_amount||0),0))
    };
    return Response.json({ok:true,settlements,batches,summary,provider:{mode:"internal-truth-only",external_transfer_enabled:false},financial_rules:{platform_fee_rate:0.08,distributor_commission:0}});
  }
  return fail(400,"unsupported payout operation", ErrorCode.InvalidInput);
});
