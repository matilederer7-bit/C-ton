import { Action, ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const ACTION = Action.ChargingFinalize;
const INVALID_INPUT = ErrorCode.InvalidInput;
const TEMPORARILY_UNAVAILABLE = ErrorCode.TemporarilyUnavailable;

function fail(status: number, error: string, code: string, extra: Record<string, unknown> = {}) {
  return Response.json({ ok: false, error, code, ...extra }, { status });
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", INVALID_INPUT);
  const base44 = createClientFromRequest(req);
  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", INVALID_INPUT); }
  const dealId = String(body?.deal_id || "").trim();
  const sourceEventUuid = String(body?.source_event_uuid || "").trim();
  const idempotencyKey = String(body?.idempotency_key || "").trim();
  if (!dealId || !sourceEventUuid || !idempotencyKey) return fail(400, "deal_id, source_event_uuid and idempotency_key are required", INVALID_INPUT);

  try {
    const response = await base44.functions.invoke("transition-engine", {
      ...body,
      deal_id: dealId,
      source_event_uuid: sourceEventUuid,
      action: ACTION,
      idempotency_key: idempotencyKey,
    });
    return Response.json(response?.data || response);
  } catch (error: any) {
    const data = error?.response?.data || error?.data || {};
    const status = Number(error?.response?.status || error?.status || 503);
    const extra = data?.retry_at ? { retry_at: data.retry_at } : {};
    return fail(status >= 400 && status < 600 ? status : 503, String(data?.error || error?.message || "transition engine unavailable"), String(data?.code || error?.code || TEMPORARILY_UNAVAILABLE), extra);
  }
});
