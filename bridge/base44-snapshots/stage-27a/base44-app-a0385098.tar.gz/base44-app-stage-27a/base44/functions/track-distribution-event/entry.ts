import { DealState, ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const encoder = new TextEncoder();

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}

function normalizeCode(value: unknown) {
  return String(value || "").trim().toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
}

function hex(buffer: ArrayBuffer) {
  return [...new Uint8Array(buffer)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function sha256(value: string) {
  return hex(await crypto.subtle.digest("SHA-256", encoder.encode(value)));
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }

  const dealId = String(body?.deal_id || "").trim();
  const sourceCode = normalizeCode(body?.source_code);
  const eventType = String(body?.event_type || "").trim();
  const clientEventKey = String(body?.event_key || "").trim().slice(0, 240);

  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(dealId)) return fail(400, "deal_id must be a valid UUID", ErrorCode.InvalidInput);
  if (!sourceCode) return fail(400, "source_code required", ErrorCode.InvalidInput);
  if (!["click", "visit"].includes(eventType)) return fail(400, "event_type invalid", ErrorCode.InvalidInput);
  if (clientEventKey.length < 12) return fail(400, "event_key required", ErrorCode.InvalidInput);

  const admin = base44.asServiceRole;
  const [source, deal] = await Promise.all([
    admin.entities.DistributionSource.filter({ source_code: sourceCode, active: true }, "-created_date", 1).then((rows: any[]) => rows?.[0] || null),
    admin.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1).then((rows: any[]) => rows?.[0] || null)
  ]);
  if (!source || !deal) return Response.json({ ok: true, recorded: false, reason: "unknown_source_or_deal" });
  if (String(source.source_type || "admin") === "distributor") {
    if (String(source.deal_id || "") !== dealId || !source.distributor_access_id || !source.owner_user_id) {
      return Response.json({ ok: true, recorded: false, reason: "distributor_source_scope_mismatch" });
    }
    const access = (await admin.entities.DistributorDealAccess.filter({ access_id: String(source.distributor_access_id), owner_user_id: String(source.owner_user_id), deal_id: dealId, status: "active" }, "-created_at", 1))?.[0];
    if (!access) return Response.json({ ok: true, recorded: false, reason: "distributor_access_inactive" });
  }

  const publicStates = [DealState.PendingTarget, DealState.TargetReached, DealState.ClosedForJoining, DealState.ReadyForCharging, DealState.Charging, DealState.CompletionWindow, DealState.Completed, DealState.Failed];
  if (!publicStates.includes(String(deal.state || ""))) return Response.json({ ok: true, recorded: false, reason: "deal_not_public" });

  const eventKeyHash = await sha256(`distribution:${source.source_id}:${dealId}:${eventType}:${clientEventKey}`);
  const existing = await admin.entities.DistributionEvent.filter({ event_key_hash: eventKeyHash }, "-created_at", 1).catch(() => []);
  if (existing?.[0]) return Response.json({ ok: true, recorded: false, replay: true });

  const createdAt = new Date().toISOString();
  const eventIdSeed = eventKeyHash.slice(0, 32);
  const eventId = `${eventIdSeed.slice(0,8)}-${eventIdSeed.slice(8,12)}-4${eventIdSeed.slice(13,16)}-a${eventIdSeed.slice(17,20)}-${eventIdSeed.slice(20,32)}`;
  await admin.entities.DistributionEvent.create({
    event_id: eventId,
    event_key_hash: eventKeyHash,
    source_id: String(source.source_id),
    source_code: String(source.source_code),
    deal_id: dealId,
    event_type: eventType,
    created_at: createdAt
  });
  return Response.json({ ok: true, recorded: true, event_type: eventType });
});
