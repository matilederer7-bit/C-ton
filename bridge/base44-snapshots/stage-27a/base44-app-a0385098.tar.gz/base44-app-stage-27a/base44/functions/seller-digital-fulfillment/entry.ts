import { BuyerState, DealState, ErrorCode, MoneyState } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const ELIGIBLE_MONEY = new Set([MoneyState.ChargedSuccess,MoneyState.RecoveredCharge]);
const DIGITAL_TYPES = new Set(["voucher","ticket"]);
const REDEEMABLE = new Set(["Issued","Sent"]);

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}
function uuid(value: unknown) {
  const text = String(value || "").trim();
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(text) ? text : "";
}
function text(value: unknown, max: number) { return String(value ?? "").trim().slice(0, max); }
function safeUnit(row: any) {
  return {
    fulfillment_unit_id: row.fulfillment_unit_id,
    deal_id: row.deal_id,
    participant_id: row.participant_id,
    deal_type: row.deal_type,
    fulfillment_kind: row.fulfillment_kind,
    unit_index: Number(row.unit_index || 0),
    status: row.status,
    code_display_last4: row.code_display_last4 || null,
    issued_at: row.issued_at || null,
    sent_at: row.sent_at || null,
    redeemed_at: row.redeemed_at || null,
    expired_at: row.expired_at || null,
    event_count: Array.isArray(row.event_journal) ? row.event_journal.length : 0
  };
}
function csvSafe(value: unknown) {
  const source = String(value ?? "");
  return /^[=+\-@]/.test(source) ? `'${source}` : source;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (!user?.id) return fail(401, "authentication required", ErrorCode.ForbiddenAction);
  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }

  const dealId = uuid(body?.deal_id);
  if (!dealId) return fail(400, "deal_id must be a UUID", ErrorCode.InvalidInput);
  const admin = base44.asServiceRole;
  const deal = (await admin.entities.Deal.filter({ deal_id: dealId, owner_user_id: String(user.id) }, "-created_date", 1))?.[0];
  if (!deal) return fail(404, "deal not found", ErrorCode.InvalidInput);
  const dealType = String(deal.deal_type || "physical_product");
  if (!DIGITAL_TYPES.has(dealType)) return fail(409, "digital fulfillment is only available for voucher or ticket deals", ErrorCode.IllegalStateTransition);
  if (String(deal.state || "") !== DealState.Completed) return fail(409, "digital fulfillment is available only after Completed", ErrorCode.IllegalStateTransition);

  const operation = String(body?.operation || "list");
  const reservations = Array.isArray(deal.join_reservations) ? deal.join_reservations : [];
  const eligible = reservations.filter((row: any) => String(row?.buyer_state || "") === BuyerState.DealCompleted && ELIGIBLE_MONEY.has(String(row?.money_state || "")));
  const expectedUnits = eligible.reduce((sum: number, row: any) => sum + Math.max(1, Number(row?.qty || 1)), 0);
  const rows = await admin.entities.FulfillmentUnit.filter({ deal_id: dealId, deal_owner_user_id: String(user.id) }, "unit_index", 5000).catch(() => []);
  const units = (rows || []).map(safeUnit);

  if (operation === "list" || operation === "export") {
    const eligibleParticipants = new Set(eligible.map((row: any) => String(row?.participant_id || "")));
    const safeRows = units.filter((row: any) => eligibleParticipants.has(String(row.participant_id)));
    const exportRows = operation === "export" ? safeRows.map((row: any) => {
      const reservation = eligible.find((item: any) => String(item?.participant_id || "") === String(row.participant_id));
      return dealType === "voucher"
        ? {
            participant_id: csvSafe(row.participant_id),
            unit_index: row.unit_index,
            status: csvSafe(row.status),
            voucher_code_last4: csvSafe(row.code_display_last4 || ""),
            buyer_name: csvSafe(reservation?.buyer_name || "")
          }
        : {
            participant_id: csvSafe(row.participant_id),
            unit_index: row.unit_index,
            status: csvSafe(row.status),
            ticket_code_last4: csvSafe(row.code_display_last4 || ""),
            event_name: csvSafe(deal.ticket_terms?.event_name || ""),
            buyer_name: csvSafe(reservation?.buyer_name || "")
          };
    }) : undefined;

    return Response.json({
      ok: true,
      deal: {
        deal_id: dealId,
        title: String(deal.title || ""),
        deal_type: dealType,
        state: DealState.Completed,
        voucher_terms: dealType === "voucher" ? deal.voucher_terms || null : null,
        ticket_terms: dealType === "ticket" ? deal.ticket_terms || null : null
      },
      units: safeRows,
      readiness: {
        eligible_participants: eligible.length,
        expected_units: expectedUnits,
        existing_units: safeRows.length,
        missing_units: Math.max(0, expectedUnits - safeRows.length),
        issued: safeRows.filter((row: any) => ["Issued","Sent","Redeemed"].includes(String(row.status))).length,
        redeemed: safeRows.filter((row: any) => row.status === "Redeemed").length,
        issuance_enabled: false,
        issuance_blocker: "reliable one-time full-code delivery is not proven"
      },
      export_rows: exportRows
    });
  }

  if (operation === "redeem") {
    const unitId = uuid(body?.fulfillment_unit_id);
    if (!unitId) return fail(400, "fulfillment_unit_id must be a UUID", ErrorCode.InvalidInput);
    const unit = (await admin.entities.FulfillmentUnit.filter({ fulfillment_unit_id: unitId, deal_id: dealId, deal_owner_user_id: String(user.id) }, "-created_date", 1))?.[0];
    if (!unit) return fail(404, "fulfillment unit not found", ErrorCode.InvalidInput);
    if (String(unit.status) === "Redeemed") return Response.json({ ok: true, fulfillment_unit_id: unitId, status: "Redeemed", idempotent: true });
    if (!REDEEMABLE.has(String(unit.status))) return fail(409, "unit is not redeemable", ErrorCode.IllegalStateTransition);
    const participant = eligible.find((row: any) => String(row?.participant_id || "") === String(unit.participant_id || ""));
    if (!participant) return fail(409, "participant is no longer eligible for fulfillment", ErrorCode.IllegalStateTransition);
    const now = new Date().toISOString();
    const event = { event_type: "fulfillment.redeem", from_status: String(unit.status), to_status: "Redeemed", created_at: now, actor_user_id: String(user.id), note: text(body.note, 1000) || null };
    await admin.entities.FulfillmentUnit.update(unit.id, {
      status: "Redeemed",
      redeemed_at: now,
      event_journal: [...(Array.isArray(unit.event_journal) ? unit.event_journal : []), event]
    });
    return Response.json({ ok: true, fulfillment_unit_id: unitId, status: "Redeemed", idempotent: false });
  }

  return fail(400, "unsupported digital fulfillment operation", ErrorCode.InvalidInput);
});
