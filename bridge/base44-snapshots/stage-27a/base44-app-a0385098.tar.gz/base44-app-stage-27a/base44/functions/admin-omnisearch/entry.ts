import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status:number,error:string,code?:string){return Response.json({ok:false,error,...(code?{code}:{})},{status});}
function clean(v:unknown){return String(v||"").trim();}
function low(v:unknown){return clean(v).toLowerCase();}
function asArray(v:unknown){return Array.isArray(v)?v:[];}
function num(v:unknown){const n=Number(v||0);return Number.isFinite(n)?n:0;}
function iso(v:unknown){const t=Date.parse(String(v||""));return Number.isFinite(t)?new Date(t).toISOString():null;}
function isUuid(v:string){return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);}

async function safeFilter(entity:any,query:any,sort="-created_date",limit=20){try{return await entity.filter(query,sort,limit);}catch{return [];}}
async function recent(entity:any,limit=500){try{return await entity.list("-created_date",limit,0);}catch{return [];}}

Deno.serve(async(req)=>{
 if(req.method!=="POST")return fail(405,"method_not_allowed", ErrorCode.ForbiddenAction);
 const base44=createClientFromRequest(req);let user:any;try{user=await base44.auth.me();}catch{return fail(401,"authentication required",ErrorCode.ForbiddenAction);}
 if(String(user?.role||"")!=="admin")return fail(403,"admin required", ErrorCode.ForbiddenAction);
 let body:any;try{body=await req.json();}catch{return fail(400,"invalid JSON body",ErrorCode.InvalidInput);}
 const admin=base44.asServiceRole;const operation=String(body?.operation||"search");

 if(operation==="search"){
  const q=clean(body?.query);if(q.length<2)return fail(400,"query must contain at least 2 characters", ErrorCode.InvalidInput);
  const ql=low(q);const uuid=isUuid(q);
  const dealCandidates:any[]=[];const buyerCandidates:any[]=[];const sellerCandidates:any[]=[];const caseCandidates:any[]=[];
  if(uuid){dealCandidates.push(...await safeFilter(admin.entities.Deal,{deal_id:q}));buyerCandidates.push(...await safeFilter(admin.entities.Participant,{participant_id:q}));caseCandidates.push(...await safeFilter(admin.entities.OperationalCase,{case_id:q}));}
  buyerCandidates.push(...await safeFilter(admin.entities.Participant,{buyer_id:q}),...await safeFilter(admin.entities.Participant,{buyer_phone:q}),...await safeFilter(admin.entities.Participant,{buyer_email:q}));
  sellerCandidates.push(...await safeFilter(admin.entities.SellerAccount,{seller_id:q}),...await safeFilter(admin.entities.SellerAccount,{owner_user_id:q}),...await safeFilter(admin.entities.SellerAccount,{support_phone:q}),...await safeFilter(admin.entities.SellerAccount,{support_email:q}));
  caseCandidates.push(...await safeFilter(admin.entities.OperationalCase,{correlation_id:q}),...await safeFilter(admin.entities.OperationalCase,{participant_id:q}),...await safeFilter(admin.entities.OperationalCase,{deal_id:q}),...await safeFilter(admin.entities.OperationalCase,{seller_id:q}));
  const [recentDeals,recentSellers,recentCases]=await Promise.all([recent(admin.entities.Deal,500),recent(admin.entities.SellerAccount,500),recent(admin.entities.OperationalCase,500)]);
  dealCandidates.push(...recentDeals.filter((d:any)=>low(d?.title).includes(ql)||low(d?.seller_display_name).includes(ql)||low(d?.deal_id).includes(ql)));
  sellerCandidates.push(...recentSellers.filter((s:any)=>low(s?.business_name).includes(ql)||low(s?.display_name).includes(ql)||low(s?.support_email).includes(ql)||low(s?.support_phone).includes(ql)));
  caseCandidates.push(...recentCases.filter((c:any)=>low(c?.subject).includes(ql)||low(c?.correlation_id).includes(ql)));
  const uniq=(rows:any[],key:(r:any)=>string)=>[...new Map(rows.filter(Boolean).map(r=>[key(r),r])).values()];
  const deals=uniq(dealCandidates,r=>String(r.deal_id||r.id||"")).slice(0,3).map((d:any)=>({deal_id:String(d.deal_id||""),title:String(d.title||""),state:String(d.state||""),seller_display_name:String(d.seller_display_name||""),updated_at:iso(d.updated_date||d.created_date)}));
  const buyerRows=uniq(buyerCandidates,r=>String(r.buyer_id||r.participant_id||r.id||""));
  const buyers=buyerRows.slice(0,3).map((p:any)=>({kind:"buyer",ref:String(p.buyer_id||""),display_name:String(p.buyer_name||p.buyer_id||"קונה"),phone:String(p.buyer_phone||""),email:String(p.buyer_email||""),status:String(p.buyer_state||""),updated_at:iso(p.updated_date||p.created_date)})).filter((r:any)=>r.ref);
  const sellers=uniq(sellerCandidates,r=>String(r.seller_id||r.id||"")).slice(0,3).map((s:any)=>({kind:"seller",ref:String(s.seller_id||""),display_name:String(s.business_name||s.display_name||s.seller_id||"מוכר"),phone:String(s.support_phone||""),email:String(s.support_email||""),status:String(s.seller_status||""),updated_at:iso(s.updated_date||s.created_date)})).filter((r:any)=>r.ref);
  const cases=uniq(caseCandidates,r=>String(r.case_id||r.id||"")).slice(0,3).map((c:any)=>({case_id:String(c.case_id||""),subject:String(c.subject||""),status:String(c.status||""),priority:String(c.priority||""),opened_at:iso(c.opened_at||c.created_date)}));
  return Response.json({ok:true,query:q,deals,users:[...buyers,...sellers].slice(0,6),cases,limits:{per_category:3},generated_at:new Date().toISOString()});
 }

 if(operation==="user_detail"){
  const kind=String(body?.kind||"");const ref=clean(body?.ref);if(!["buyer","seller"].includes(kind)||!ref)return fail(400,"invalid user reference", ErrorCode.InvalidInput);
  if(kind==="seller"){
   const seller=(await safeFilter(admin.entities.SellerAccount,{seller_id:ref},"-created_date",1))?.[0];if(!seller)return fail(404,"seller not found", ErrorCode.InvalidInput);
   const [deals,cases]=await Promise.all([safeFilter(admin.entities.Deal,{seller_id:ref},"-updated_date",500),safeFilter(admin.entities.OperationalCase,{seller_id:ref},"-created_date",100)]);
   return Response.json({ok:true,profile:{kind:"seller",ref,seller_id:ref,display_name:String(seller.business_name||seller.display_name||ref),phone:String(seller.support_phone||""),email:String(seller.support_email||""),status:String(seller.seller_status||""),verification_status:String(seller.verification_status||"")},stats:{deals:deals.length,financial_amounts_proven:false},deals:deals.slice(0,200).map((d:any)=>({deal_id:String(d.deal_id||""),title:String(d.title||""),state:String(d.state||""),reserved_units:num(d.reserved_units),updated_at:iso(d.updated_date||d.created_date)})),support:cases.slice(0,50).map((c:any)=>({case_id:String(c.case_id||""),subject:String(c.subject||""),status:String(c.status||""),priority:String(c.priority||"")})),actions:{seller_status_management:"/admin/sellers",freeze_payouts:"/admin/controls",buyer_ban:false},financial_amounts_proven:false});
  }
  const participants=await safeFilter(admin.entities.Participant,{buyer_id:ref},"-created_date",500);if(!participants.length)return fail(404,"buyer not found", ErrorCode.InvalidInput);
  const latest=participants[0];const dealIds=[...new Set(participants.map((p:any)=>String(p.deal_id||"")).filter(Boolean))];
  const deals:any[]=[];for(const id of dealIds.slice(0,200)){const d=(await safeFilter(admin.entities.Deal,{deal_id:id},"-created_date",1))?.[0];if(d)deals.push(d);}
  const participantIds=participants.map((p:any)=>String(p.participant_id||"")).filter(Boolean);const support:any[]=[];for(const id of participantIds.slice(0,100)){support.push(...await safeFilter(admin.entities.OperationalCase,{participant_id:id},"-created_date",20));}
  const states:Record<string,number>={};const money:Record<string,number>={};let units=0;for(const p of participants){const q=Math.max(0,num(p.qty));units+=q;const b=String(p.buyer_state||"unknown"),m=String(p.money_state||"unknown");states[b]=(states[b]||0)+q;money[m]=(money[m]||0)+q;}
  return Response.json({ok:true,profile:{kind:"buyer",ref,display_name:String(latest.buyer_name||ref),phone:String(latest.buyer_phone||""),email:String(latest.buyer_email||""),status:"participant_identity"},stats:{deals:dealIds.length,participation_records:participants.length,units,buyer_state_units:states,money_state_units:money,financial_amounts_proven:false},deals:deals.map((d:any)=>({deal_id:String(d.deal_id||""),title:String(d.title||""),state:String(d.state||""),updated_at:iso(d.updated_date||d.created_date)})),support:[...new Map(support.map((c:any)=>[String(c.case_id||c.id||""),c])).values()].slice(0,50).map((c:any)=>({case_id:String(c.case_id||""),subject:String(c.subject||""),status:String(c.status||""),priority:String(c.priority||"")})),actions:{buyer_ban:false,buyer_suspend:false,forensics:"/admin/forensics"},financial_amounts_proven:false});
 }
 return fail(400,"unsupported operation", ErrorCode.InvalidInput);
});