import { BuyerState, DealState, ErrorCode, MoneyState } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";
import { enqueueBuyerNotifications } from "../../shared/notifications.ts";

const ELIGIBLE_MONEY = new Set([MoneyState.ChargedSuccess,MoneyState.RecoveredCharge]);
const DELIVERY_STATUSES = new Set(["ready_to_fulfill","shipped","delivered","issue"]);

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}

function uuid(value: unknown) {
  const text = String(value || "").trim();
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(text) ? text : "";
}

function text(value: unknown, max: number) {
  return String(value ?? "").trim().slice(0, max);
}

function safeDeliveryRow(row: any) {
  return {
    delivery_id: row.delivery_id,
    deal_id: row.deal_id,
    participant_id: row.participant_id,
    status: row.status,
    qty: Number(row.qty || 0),
    money_state_at_eligibility: row.money_state_at_eligibility,
    delivery_method_type: row.delivery_method_type || null,
    delivery_method_label: row.delivery_method_label || null,
    delivery_cost: Number(row.delivery_cost || 0),
    buyer_name: row.buyer_name || null,
    buyer_phone: row.buyer_phone || null,
    buyer_email: row.buyer_email || null,
    delivery_address: row.delivery_address || null,
    delivery_city: row.delivery_city || null,
    delivery_notes: row.delivery_notes || null,
    carrier: row.carrier || null,
    tracking_number: row.tracking_number || null,
    seller_note: row.seller_note || null,
    created_at: row.created_at || row.created_date || null,
    shipped_at: row.shipped_at || null,
    delivered_at: row.delivered_at || null,
    issue_at: row.issue_at || null,
    event_count: Array.isArray(row.event_journal) ? row.event_journal.length : 0
  };
}

async function requireCompletedDeal(admin: any, userId: string, dealId: string) {
  const deal = (await admin.entities.Deal.filter({ deal_id: dealId, owner_user_id: userId }, "-created_date", 1))?.[0];
  if (!deal) throw Object.assign(new Error("deal not found"), { status: 404, code: ErrorCode.InvalidInput });
  if (String(deal.state) !== DealState.Completed) throw Object.assign(new Error("fulfillment is available only for Completed deals"), { status: 409, code: ErrorCode.IllegalStateTransition });
  return deal;
}

async function ensureRecords(admin: any, deal: any) {
  const reservations = Array.isArray(deal.join_reservations) ? deal.join_reservations : [];
  const eligible = reservations.filter((row: any) => String(row?.buyer_state || "") === BuyerState.DealCompleted && ELIGIBLE_MONEY.has(String(row?.money_state || "")));
  for (const reservation of eligible) {
    const participantId = uuid(reservation?.participant_id);
    if (!participantId) continue;
    const prior = await admin.entities.DeliveryRecord.filter({ deal_id: String(deal.deal_id), participant_id: participantId }, "-created_date", 1);
    if (prior?.[0]) continue;
    const now = new Date().toISOString();
    const event = { event_type: "delivery.ready_to_fulfill", from_status: null, to_status: "ready_to_fulfill", reason: "eligible completed purchase projected to fulfillment", created_at: now };
    await admin.entities.DeliveryRecord.create({
      delivery_id: crypto.randomUUID(),
      deal_id: String(deal.deal_id),
      participant_id: participantId,
      deal_owner_user_id: String(deal.owner_user_id || ""),
      seller_id: String(deal.seller_id || ""),
      status: "ready_to_fulfill",
      qty: Math.max(1, Number(reservation.qty || 1)),
      money_state_at_eligibility: String(reservation.money_state),
      delivery_method_type: reservation.delivery_method_type || null,
      delivery_method_label: reservation.delivery_method_label || null,
      delivery_cost: Number(reservation.delivery_cost || 0),
      buyer_name: reservation.buyer_name || null,
      buyer_phone: reservation.buyer_phone || reservation.buyer_id || null,
      buyer_email: reservation.buyer_email || null,
      delivery_address: reservation.delivery_address || null,
      delivery_city: reservation.delivery_city || null,
      delivery_notes: reservation.delivery_notes || null,
      created_at: now,
      event_journal: [event]
    }).catch(() => undefined);
  }
  return eligible.length;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (!user?.id) return fail(401, "authentication required", ErrorCode.ForbiddenAction);
  const admin = base44.asServiceRole;

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const operation = String(body?.operation || "list");
  const dealId = uuid(body?.deal_id);
  if (!dealId) return fail(400, "deal_id must be a UUID", ErrorCode.InvalidInput);

  try {
    const deal = await requireCompletedDeal(admin, String(user.id), dealId);
    await ensureRecords(admin, deal);

    if (operation === "list" || operation === "export") {
      const rows = await admin.entities.DeliveryRecord.filter({ deal_id: dealId, deal_owner_user_id: String(user.id) }, "created_at", 1000);
      const deliveries = (rows || []).map(safeDeliveryRow);
      return Response.json({
        ok: true,
        deal: { deal_id: dealId, title: String(deal.title || ""), state: DealState.Completed, seller_id: String(deal.seller_id || "") },
        deliveries,
        summary: {
          total_records: deliveries.length,
          total_units: deliveries.reduce((sum: number, row: any) => sum + Number(row.qty || 0), 0),
          ready_to_fulfill: deliveries.filter((row: any) => row.status === "ready_to_fulfill").length,
          shipped: deliveries.filter((row: any) => row.status === "shipped").length,
          delivered: deliveries.filter((row: any) => row.status === "delivered").length,
          issue: deliveries.filter((row: any) => row.status === "issue").length
        },
        export_rows: operation === "export" ? deliveries.map((row: any) => ({
          participant_id: row.participant_id,
          qty: row.qty,
          status: row.status,
          buyer_name: row.buyer_name,
          buyer_phone: row.buyer_phone,
          buyer_email: row.buyer_email,
          delivery_method: row.delivery_method_label || row.delivery_method_type,
          delivery_address: row.delivery_address,
          delivery_city: row.delivery_city,
          delivery_notes: row.delivery_notes,
          carrier: row.carrier,
          tracking_number: row.tracking_number
        })) : undefined
      });
    }

    if (operation !== "update") return fail(400, "unsupported fulfillment operation", ErrorCode.InvalidInput);
    const participantId = uuid(body.participant_id);
    if (!participantId) return fail(400, "participant_id must be a UUID", ErrorCode.InvalidInput);
    const nextStatus = String(body.status || "");
    if (!DELIVERY_STATUSES.has(nextStatus)) return fail(400, "invalid delivery status", ErrorCode.InvalidInput);
    const reason = text(body.reason, 1000);
    if (!reason) return fail(400, "reason is required for fulfillment changes", ErrorCode.InvalidInput);
    const rawSellerNote = String(body.seller_note ?? "").trim();
    if (nextStatus === "issue" && rawSellerNote.length > 200) return fail(400, "shipping issue note must be at most 200 characters", ErrorCode.InvalidInput);
    const sellerNote = text(rawSellerNote, nextStatus === "issue" ? 200 : 2000);

    const record = (await admin.entities.DeliveryRecord.filter({ deal_id: dealId, participant_id: participantId, deal_owner_user_id: String(user.id) }, "-created_date", 1))?.[0];
    if (!record) return fail(404, "delivery record not found", ErrorCode.InvalidInput);
    if (!ELIGIBLE_MONEY.has(String(record.money_state_at_eligibility || ""))) return fail(409, "delivery record is not financially eligible", ErrorCode.IllegalStateTransition);

    const now = new Date().toISOString();
    const event = {
      event_type: "delivery.update",
      from_status: String(record.status || ""),
      to_status: nextStatus,
      reason,
      carrier: text(body.carrier, 200) || null,
      tracking_number: text(body.tracking_number, 300) || null,
      seller_note: sellerNote || null,
      created_at: now,
      actor_user_id: String(user.id)
    };
    const patch: Record<string, unknown> = {
      status: nextStatus,
      carrier: text(body.carrier, 200) || record.carrier || null,
      tracking_number: text(body.tracking_number, 300) || record.tracking_number || null,
      seller_note: sellerNote || record.seller_note || null,
      event_journal: [...(Array.isArray(record.event_journal) ? record.event_journal : []), event]
    };
    if (nextStatus === "shipped" && !record.shipped_at) patch.shipped_at = now;
    if (nextStatus === "delivered" && !record.delivered_at) patch.delivered_at = now;
    if (nextStatus === "issue" && !record.issue_at) patch.issue_at = now;
    await admin.entities.DeliveryRecord.update(record.id, patch);
    const latest = (await admin.entities.DeliveryRecord.filter({ deal_id: dealId, participant_id: participantId, deal_owner_user_id: String(user.id) }, "-created_date", 1))?.[0];
    if (["shipped", "delivered"].includes(nextStatus)) {
      const [deal, participant] = await Promise.all([
        admin.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1).then((rows: any[]) => rows?.[0]).catch(() => null),
        admin.entities.Participant.filter({ participant_id: participantId, deal_id: dealId }, "-created_date", 1).then((rows: any[]) => rows?.[0]).catch(() => null)
      ]);
      if (deal && participant) {
        await enqueueBuyerNotifications(
          admin,
          deal,
          participant,
          nextStatus === "shipped" ? "buyer_shipped" : "buyer_delivered",
          nextStatus === "shipped" ? "buyer_shipped_he" : "buyer_delivered_he",
          { deal_title: String(deal.title || ""), carrier: patch.carrier || null, tracking_number: patch.tracking_number || null, delivery_status: nextStatus },
          `delivery:${String(record.delivery_id || participantId)}:${nextStatus}`
        );
      }
    }
    return Response.json({ ok: true, delivery: safeDeliveryRow(latest) });
  } catch (error: any) {
    const status = Number(error?.status || error?.statusCode || 500);
    return fail(status >= 400 && status < 600 ? status : 500, String(error?.message || "fulfillment failed"), String(error?.code || "fulfillment_failed"));
  }
});
