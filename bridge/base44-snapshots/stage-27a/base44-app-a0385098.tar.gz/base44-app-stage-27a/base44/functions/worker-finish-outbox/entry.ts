import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const OUTBOX_POLL_MS = 1000;

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (!user?.id || String(user.role || "") !== "admin") return fail(403, "admin worker authority required", ErrorCode.ForbiddenAction);

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }

  const eventUuid = String(body?.event_uuid || "").trim();
  const leaseOwner = String(body?.lease_owner || "").trim();
  const outcome = String(body?.outcome || "").trim();
  const errorMessage = String(body?.error || "").slice(0, 500);
  const temporary = body?.temporary === true;
  if (!eventUuid || !leaseOwner) return fail(400, "event_uuid and lease_owner are required", ErrorCode.InvalidInput);
  if (!["sent", "retry", "permanent_fail", "deferred"].includes(outcome)) return fail(400, "invalid worker outcome", ErrorCode.InvalidInput);

  const now = new Date();
  const rows = await base44.asServiceRole.entities.OutboxEvent.filter({ event_uuid: eventUuid }, "-updated_date", 1);
  const event = rows?.[0];
  if (!event) return fail(404, "outbox event not found", ErrorCode.InvalidInput);
  if (String(event.status) !== "processing" || String(event.lease_owner || "") !== leaseOwner || Date.parse(String(event.lease_expires_at || "")) <= now.getTime()) {
    return fail(409, "worker lease is missing or expired", ErrorCode.NotInWindow);
  }

  if (outcome === "sent") {
    const result = await base44.asServiceRole.entities.OutboxEvent.updateMany(
      { event_uuid: eventUuid, status: "processing", lease_owner: leaseOwner, lease_expires_at: { $gt: now.toISOString() } },
      {
        $set: {
          status: "sent",
          processed_at: now.toISOString(),
          last_error: "",
          lease_owner: "",
          lease_expires_at: null
        }
      }
    );
    if (Number(result?.updated || 0) !== 1) return fail(409, "worker lease was lost before ack", ErrorCode.IllegalStateTransition);
    return Response.json({ ok: true, event_uuid: eventUuid, status: "sent" });
  }

  if (outcome === "deferred") {
    const retryAt = new Date(String(body?.retry_at || ""));
    if (!Number.isFinite(retryAt.getTime()) || retryAt.getTime() <= now.getTime()) return fail(400, "retry_at must be a future ISO date", ErrorCode.InvalidInput);
    const result = await base44.asServiceRole.entities.OutboxEvent.updateMany(
      { event_uuid: eventUuid, status: "processing", lease_owner: leaseOwner },
      {
        $set: {
          status: "pending",
          available_at: retryAt.toISOString(),
          last_error: errorMessage || "deferred_event",
          lease_owner: "",
          lease_expires_at: null
        }
      }
    );
    if (Number(result?.updated || 0) !== 1) return fail(409, "worker lease was lost before defer", ErrorCode.IllegalStateTransition);
    return Response.json({ ok: true, event_uuid: eventUuid, status: "pending", available_at: retryAt.toISOString(), deferred: true });
  }

  const attemptCount = Math.max(0, Number(event.attempt_count || 0));
  const maxAttempts = Math.max(1, Number(event.max_attempts || 4));
  const shouldDeadLetter = outcome === "permanent_fail" || attemptCount >= maxAttempts;

  if (shouldDeadLetter) {
    const deadLetteredAt = now.toISOString();
    await base44.asServiceRole.entities.OutboxDeadLetter.create({
      event_uuid: String(event.event_uuid),
      event_type: String(event.event_type || ""),
      aggregate_type: String(event.aggregate_type || ""),
      aggregate_id: String(event.aggregate_id || ""),
      payload: event.payload && typeof event.payload === "object" ? event.payload : {},
      attempt_count: attemptCount,
      max_attempts: maxAttempts,
      last_error: errorMessage || (outcome === "permanent_fail" ? "permanent_fail" : "max_attempts_exhausted"),
      dead_lettered_at: deadLetteredAt
    }).catch(() => undefined);

    const result = await base44.asServiceRole.entities.OutboxEvent.updateMany(
      { event_uuid: eventUuid, status: "processing", lease_owner: leaseOwner },
      {
        $set: {
          status: "dead_letter",
          processed_at: deadLetteredAt,
          last_error: errorMessage || (outcome === "permanent_fail" ? "permanent_fail" : "max_attempts_exhausted"),
          lease_owner: "",
          lease_expires_at: null
        }
      }
    );
    if (Number(result?.updated || 0) !== 1) return fail(409, "worker lease was lost before DLQ", ErrorCode.IllegalStateTransition);
    return Response.json({ ok: true, event_uuid: eventUuid, status: "dead_letter" });
  }

  const nextDelay = temporary
    ? Math.floor(OUTBOX_POLL_MS * 1.5 * (1 + attemptCount))
    : OUTBOX_POLL_MS * (1 + attemptCount);
  const availableAt = new Date(now.getTime() + nextDelay).toISOString();
  const result = await base44.asServiceRole.entities.OutboxEvent.updateMany(
    { event_uuid: eventUuid, status: "processing", lease_owner: leaseOwner },
    {
      $set: {
        status: "pending",
        available_at: availableAt,
        last_error: errorMessage || "worker_retry",
        lease_owner: "",
        lease_expires_at: null
      }
    }
  );
  if (Number(result?.updated || 0) !== 1) return fail(409, "worker lease was lost before retry", ErrorCode.IllegalStateTransition);
  return Response.json({ ok: true, event_uuid: eventUuid, status: "pending", available_at: availableAt, retry_delay_ms: nextDelay });
});
