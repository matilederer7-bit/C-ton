import { createClientFromRequest } from "npm:@base44/sdk";
import { Action, DealState, ErrorCode } from "../../shared/constitution.ts";

function fail(status:number,error:string,code:string){return Response.json({ok:false,error,code},{status});}
async function sha256(value:string){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(value));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("");}
async function authorized(base44:any,body:any){
  try{const user=await base44.auth.me();if(String(user?.role||"")==="admin")return true;}catch{}
  const expected=String(Deno.env.get("PAYMENT_RECONCILE_WORKER_SECRET")||"");
  if(expected.length<32)return false;
  return (await sha256(String(body?.internal_call_token||"")))===(await sha256(expected));
}
function syntheticResult(participantId:string){return {participant_id:participantId,result_class:"permanent_fail",provider_reference:null,provider_event_type:"reconcile_timeout_24h",error_code:"unknown_timeout_24h",error_message:"provider outcome remained unknown until the constitutional 24h deadline",correlation_id:`reconcile-timeout:${participantId}`};}
async function updateEmbeddedJob(admin:any,dealId:string,jobId:string,status:string,lastError:string|null){
  const deal=(await admin.entities.Deal.filter({deal_id:dealId},"-created_date",1).catch(()=>[]))?.[0];
  if(!deal)return;
  const jobs=Array.isArray(deal.payment_reconcile_jobs)?deal.payment_reconcile_jobs:[];
  const next=jobs.map((job:any)=>String(job?.job_id||"")===jobId?{...job,status,last_error:lastError,updated_at:new Date().toISOString(),...(status==="resolved"?{resolved_at:new Date().toISOString()}:{})}:job);
  await admin.entities.Deal.updateMany({deal_id:dealId},{ $set:{payment_reconcile_jobs:next} }).catch(()=>undefined);
}

Deno.serve(async(req)=>{
  if(req.method!=="POST")return fail(405,"method_not_allowed",ErrorCode.ForbiddenAction);
  const base44=createClientFromRequest(req);let body:any;try{body=await req.json();}catch{return fail(400,"invalid JSON body",ErrorCode.InvalidInput);}
  if(!(await authorized(base44,body)))return fail(403,"worker authorization required",ErrorCode.ForbiddenAction);
  const admin=base44.asServiceRole;
  const nowIso=new Date().toISOString();
  const limit=Math.max(1,Math.min(50,Number(body?.limit||20)));
  const jobs=await admin.entities.PaymentReconcileJob.filter({status:"pending",deadline_at:{$lte:nowIso}},"deadline_at",limit).catch(()=>[]);
  const results:any[]=[];
  for(const row of jobs||[]){
    const jobId=String(row.job_id||"");const dealId=String(row.deal_id||"");const phase=String(row.phase||"");
    const claim=await admin.entities.PaymentReconcileJob.updateMany({job_id:jobId,status:"pending",attempt_count:Number(row.attempt_count||0)},{ $set:{status:"processing",updated_at:new Date().toISOString()},$inc:{attempt_count:1} }).catch(()=>({updated:0}));
    if(Number(claim?.updated||0)!==1){results.push({job_id:jobId,result:"not_claimed"});continue;}
    try{
      const deal=(await admin.entities.Deal.filter({deal_id:dealId},"-created_date",1))?.[0];
      if(!deal)throw Object.assign(new Error("deal missing for reconcile job"),{code:ErrorCode.InvalidInput});
      if([DealState.Completed,DealState.Failed,DealState.Cancelled].includes(String(deal.state||"") as any))throw Object.assign(new Error("late reconcile job found after terminal deal"),{code:ErrorCode.IllegalStateTransition});
      const known=Array.isArray(row.known_results)?row.known_results:[];
      const unresolved=Array.isArray(row.unknown_participant_ids)?row.unknown_participant_ids.map(String):[];
      const finalResults=[...known,...unresolved.map(syntheticResult)];
      if(!finalResults.length)throw Object.assign(new Error("reconcile job has no provider results"),{code:ErrorCode.InvalidInput});
      const action=phase==="charge"?Action.ChargingStart:phase==="recovery"?Action.ChargingRecovery:null;
      if(!action)throw Object.assign(new Error("unsupported reconcile phase"),{code:ErrorCode.InvalidInput});
      const invoke=await admin.functions.invoke("transition-engine",{
        deal_id:dealId,
        action,
        source_event_uuid:String(row.source_event_uuid||""),
        results:finalResults,
        reconcile_timeout_resolution:true,
        request_id:`reconcile-timeout:${jobId}`,
        idempotency_key:`reconcile-timeout:${jobId}`
      });
      const response=invoke?.data||invoke;
      if(!response?.ok)throw Object.assign(new Error(String(response?.error||"transition reconcile failed")),{code:String(response?.code||ErrorCode.TemporarilyUnavailable)});
      await updateEmbeddedJob(admin,dealId,jobId,"resolved",null);
      await admin.entities.PaymentReconcileJob.updateMany({job_id:jobId,status:"processing"},{ $set:{status:"resolved",resolved_at:new Date().toISOString(),updated_at:new Date().toISOString(),last_error:""} });
      results.push({job_id:jobId,result:"resolved",state:response.state||null});
    }catch(error:any){
      const attempt=Number(row.attempt_count||0)+1;const max=Math.max(1,Number(row.max_attempts||3));const terminal=attempt>=max;
      const message=String(error?.message||"reconcile timeout resolution failed").slice(0,1500);
      await updateEmbeddedJob(admin,dealId,jobId,terminal?"failed":"pending",message);
      await admin.entities.PaymentReconcileJob.updateMany({job_id:jobId,status:"processing"},{ $set:{status:terminal?"failed":"pending",available_at:new Date(Date.now()+30_000).toISOString(),updated_at:new Date().toISOString(),last_error:message} }).catch(()=>undefined);
      results.push({job_id:jobId,result:terminal?"failed":"retry",error_code:String(error?.code||ErrorCode.TemporarilyUnavailable)});
    }
  }
  return Response.json({ok:true,processed:results.length,results});
});
