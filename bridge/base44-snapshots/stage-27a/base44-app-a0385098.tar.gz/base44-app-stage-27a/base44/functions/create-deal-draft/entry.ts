import { DealState, ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const DEADLINE_MIN_MS = 2 * 60 * 60 * 1000;
const DEADLINE_MAX_MS = 7 * 24 * 60 * 60 * 1000;
const DEADLINE_DEFAULT_MS = 24 * 60 * 60 * 1000;
const DEAL_TYPES = ["physical_product", "voucher", "ticket"];
const SELLER_STATUSES = ["Active", "UnderReview", "Restricted", "Suspended", "Banned"];

function responseError(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}

function normalizeSellerId(value: unknown) {
  const normalized = String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64);
  return normalized || "seller-default";
}

function normalizeDisplayName(value: unknown, fallback: string) {
  const normalized = String(value || "").trim().replace(/\s+/g, " ").slice(0, 80);
  return normalized || fallback;
}

function readTitle(body: Record<string, unknown>) {
  for (const field of ["title", "sellerTitle", "dealTitle", "productName", "name", "deal_name"]) {
    const value = String(body?.[field] || "").trim();
    if (value) return value;
  }
  return "";
}

function sanitizeDeliveryOptions(raw: unknown) {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((option: any, index: number) => ({
      option_id: crypto.randomUUID(),
      option_type: ["delivery", "pickup", "distribution_point"].includes(String(option?.option_type || ""))
        ? String(option.option_type)
        : "pickup",
      label: String(option?.label || "").trim().slice(0, 160),
      cost: Math.max(0, Number(option?.cost || 0)),
      sort_order: Number.isFinite(Number(option?.sort_order)) ? Number(option.sort_order) : index
    }))
    .filter((option: any) => option.label)
    .slice(0, 5);
}

function normalizeVoucherTerms(input: any) {
  if (!input || typeof input !== "object") return null;
  const faceValue = Number(input.face_value_amount);
  if (!Number.isFinite(faceValue) || faceValue <= 0) {
    throw Object.assign(new Error("face_value_amount must be a positive number"), { status: 400, code: ErrorCode.InvalidInput });
  }
  const mode = String(input.voucher_code_mode || "system_generated");
  if (mode === "seller_uploaded") {
    throw Object.assign(new Error("seller_uploaded voucher codes are not supported yet"), { status: 400, code: ErrorCode.InvalidInput });
  }
  return {
    face_value_amount: faceValue,
    currency: String(input.currency || "ILS").trim().slice(0, 8) || "ILS",
    valid_from: input.valid_from || null,
    valid_until: input.valid_until || null,
    redemption_location: String(input.redemption_location || "").trim().slice(0, 500),
    redemption_instructions: String(input.redemption_instructions || "").trim().slice(0, 1000),
    terms: String(input.terms || "").trim().slice(0, 2000),
    is_single_use: input.is_single_use !== false,
    allow_partial_redemption: input.allow_partial_redemption === true,
    voucher_code_mode: mode
  };
}

function normalizeTicketTerms(input: any) {
  if (!input || typeof input !== "object") return null;
  const eventName = String(input.event_name || "").trim().slice(0, 200);
  if (!eventName) {
    throw Object.assign(new Error("event_name is required for ticket deals"), { status: 400, code: ErrorCode.InvalidInput });
  }
  const startsAtMs = new Date(String(input.event_starts_at || "")).getTime();
  if (!Number.isFinite(startsAtMs)) {
    throw Object.assign(new Error("event_starts_at must be a valid ISO date"), { status: 400, code: ErrorCode.InvalidInput });
  }
  const seatMode = String(input.seat_mode || "general_admission");
  if (seatMode === "assigned_seating_not_supported_yet") {
    throw Object.assign(new Error("assigned seating is not supported yet — use general_admission or external_seating"), { status: 400, code: ErrorCode.InvalidInput });
  }
  const endsAt = input.event_ends_at ? new Date(String(input.event_ends_at)) : null;
  return {
    event_name: eventName,
    event_starts_at: new Date(startsAtMs).toISOString(),
    event_ends_at: endsAt && Number.isFinite(endsAt.getTime()) ? endsAt.toISOString() : null,
    venue_name: String(input.venue_name || "").trim().slice(0, 200),
    venue_address: String(input.venue_address || "").trim().slice(0, 300),
    venue_city: String(input.venue_city || "").trim().slice(0, 100),
    entry_instructions: String(input.entry_instructions || "").trim().slice(0, 1000),
    ticket_type: String(input.ticket_type || "general_admission"),
    seat_mode: seatMode,
    transfer_allowed: input.transfer_allowed === true
  };
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return responseError(405, "method_not_allowed", ErrorCode.ForbiddenAction);

  const base44 = createClientFromRequest(req);
  let user: any;
  try {
    user = await base44.auth.me();
  } catch {
    return responseError(401, "authentication required", ErrorCode.ForbiddenAction);
  }
  if (!user?.id) return responseError(401, "authentication required", ErrorCode.ForbiddenAction);

  let body: any;
  try {
    body = await req.json();
  } catch {
    return responseError(400, "invalid JSON body");
  }

  try {
    const dealType = body.deal_type == null ? "physical_product" : String(body.deal_type);
    if (!DEAL_TYPES.includes(dealType)) {
      return responseError(400, "deal_type must be one of physical_product, voucher, ticket", ErrorCode.InvalidInput);
    }

    if (dealType === "voucher" && (!body.voucher_terms || typeof body.voucher_terms !== "object")) {
      return responseError(400, "voucher_terms is required for voucher deals", ErrorCode.InvalidInput);
    }
    if (dealType === "ticket" && (!body.ticket_terms || typeof body.ticket_terms !== "object")) {
      return responseError(400, "ticket_terms is required for ticket deals", ErrorCode.InvalidInput);
    }

    const title = readTitle(body);
    if (!title) return responseError(400, "title is required", ErrorCode.InvalidInput);
    if (title.length > 200) return responseError(400, "title must be 200 characters or fewer");
    const shortDescription = String(body.short_description || "").trim().slice(0, 1200);
    const whatYouGet = String(body.what_you_get || "").trim().slice(0, 2000);

    const priceRaw = Number(body.price_per_unit);
    if (!Number.isFinite(priceRaw) || priceRaw <= 0) {
      return responseError(400, "price_per_unit must be a positive number");
    }

    const requestedMinUnitsRaw = body.min_units ?? body.threshold_units ?? 10;
    const minUnits = Math.max(1, Number(requestedMinUnitsRaw || 10));
    if (!Number.isFinite(minUnits)) return responseError(400, "min_units must be a positive number");

    const requestedMaxUnitsRaw = body.max_units ?? Math.max(minUnits, 20);
    const maxUnits = Math.max(minUnits, Number(requestedMaxUnitsRaw || 20));
    if (!Number.isFinite(maxUnits)) return responseError(400, "max_units must be a positive number");

    const draftThreshold = Math.ceil(0.9 * minUnits);
    const deliveryOptions = sanitizeDeliveryOptions(body.delivery_options);

    const now = Date.now();
    let deadlineMs: number;
    if (body.deadline === undefined || body.deadline === null || body.deadline === "") {
      deadlineMs = now + DEADLINE_DEFAULT_MS;
    } else {
      deadlineMs = new Date(body.deadline).getTime();
      if (!Number.isFinite(deadlineMs)) return responseError(400, "deadline must be a valid ISO date");
    }
    const deadlineDiffMs = deadlineMs - now;
    if (deadlineDiffMs < DEADLINE_MIN_MS) {
      return responseError(400, "deadline must be at least 2 hours in the future", ErrorCode.InvalidInput);
    }
    if (deadlineDiffMs > DEADLINE_MAX_MS) {
      return responseError(400, "deadline must be within 7 days from now", ErrorCode.InvalidInput);
    }

    const accounts = await base44.asServiceRole.entities.SellerAccount.filter({ owner_user_id: String(user.id) }, "-created_date", 1);
    let sellerAccount = accounts?.[0];
    if (!sellerAccount) {
      const proposedSellerId = normalizeSellerId(body.seller_id || user.email || user.id);
      const displayName = normalizeDisplayName(body.seller_display_name || user.name || user.full_name || user.email, proposedSellerId);
      sellerAccount = await base44.asServiceRole.entities.SellerAccount.create({
        seller_id: proposedSellerId,
        display_name: displayName,
        seller_status: "Active",
        owner_user_id: String(user.id),
        business_name: displayName,
        support_email: String(user.email || "").trim().toLowerCase(),
        verification_status: "pending",
        review_history: []
      });
    }

    const sellerStatus = SELLER_STATUSES.includes(String(sellerAccount.seller_status)) ? String(sellerAccount.seller_status) : "Active";
    if (sellerStatus === "Suspended") {
      return responseError(403, "seller is suspended from new seller actions", ErrorCode.ForbiddenAction);
    }
    if (sellerStatus === "Banned") {
      return responseError(403, "seller is banned from seller actions", ErrorCode.ForbiddenAction);
    }

    const voucherTerms = dealType === "voucher" ? normalizeVoucherTerms(body.voucher_terms) : null;
    const ticketTerms = dealType === "ticket" ? normalizeTicketTerms(body.ticket_terms) : null;
    const dealId = crypto.randomUUID();

    const deal = await base44.asServiceRole.entities.Deal.create({
      deal_id: dealId,
      owner_user_id: String(user.id),
      seller_id: String(sellerAccount.seller_id),
      seller_display_name: String(sellerAccount.display_name || sellerAccount.seller_id),
      state: DealState.Draft,
      deal_type: dealType,
      title,
      short_description: shortDescription || null,
      what_you_get: whatYouGet || null,
      price_per_unit: priceRaw,
      min_units: Math.trunc(minUnits),
      max_units: Math.trunc(maxUnits),
      threshold_units: Math.ceil(0.9 * Math.trunc(minUnits)),
      commission_rate: 0.08,
      completion_window_hours: 24,
      reserved_units: 0,
      join_reservations: [],
      join_idempotency_keys: [],
      pending_join_keys: [],
      pending_join_intents: [],
      money_ledger_events: [],
      payment_reconcile_jobs: [],
      outbox_events: [],
      deadline: new Date(deadlineMs).toISOString(),
      delivery_options: dealType === "physical_product" ? deliveryOptions : [],
      voucher_terms: voucherTerms,
      ticket_terms: ticketTerms,
      contract_version: "c-ton-master-2026-08-10"
    });

    return Response.json({ deal_id: deal.deal_id, state: deal.state, deal_type: deal.deal_type });
  } catch (error: any) {
    const status = Number(error?.status || error?.statusCode || 500);
    const safeStatus = status >= 400 && status < 600 ? status : 500;
    return responseError(safeStatus, String(error?.message || "internal_error"), error?.code ? String(error.code) : undefined);
  }
});
