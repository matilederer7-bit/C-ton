import { ErrorCode } from "../../shared/constitution.ts";
const FORBIDDEN_ACTION = ErrorCode.ForbiddenAction;

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return Response.json({ ok: false, error: "method_not_allowed", code: FORBIDDEN_ACTION }, { status: 405 });
  }
  return Response.json({
    ok: false,
    error: "refund result application is fail-closed until Constitution conflicts C-02 and C-08 are explicitly resolved",
    code: FORBIDDEN_ACTION,
    blocker: "BASE44_CONSTITUTION_CONFLICTS:C-02,C-08"
  }, { status: 503 });
});
