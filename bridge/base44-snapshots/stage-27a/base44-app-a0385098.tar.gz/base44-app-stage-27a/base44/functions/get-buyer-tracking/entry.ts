import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const encoder = new TextEncoder();

function fail(status: number, message: string, code?: string) {
  return Response.json({ ok: false, error: message, ...(code ? { code } : {}) }, { status });
}

function bytesToHex(bytes: ArrayBuffer) {
  return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function sha256Hex(value: string) {
  return bytesToHex(await crypto.subtle.digest("SHA-256", encoder.encode(value)));
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }

  const participantId = String(body.participant_id || "").trim();
  const token = String(body.tracking_token || "").trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(participantId)) {
    return fail(400, "participant_id must be a valid UUID", ErrorCode.InvalidInput);
  }
  if (!token) return fail(401, "tracking token required", ErrorCode.ForbiddenAction);

  const rows = await base44.asServiceRole.entities.Participant.filter({ participant_id: participantId }, "-created_date", 1);
  const participant = rows?.[0];
  if (!participant) return fail(404, "participant not found", ErrorCode.InvalidInput);

  if (!participant.tracking_token_hash || !participant.tracking_token_expires_at) {
    return fail(403, "tracking access is unavailable", ErrorCode.ForbiddenAction);
  }
  if (Date.parse(String(participant.tracking_token_expires_at)) <= Date.now()) {
    return fail(401, "tracking token expired", ErrorCode.NotInWindow);
  }
  const presentedHash = await sha256Hex(`tracking:${token}`);
  if (presentedHash !== String(participant.tracking_token_hash)) {
    return fail(403, "invalid tracking token", ErrorCode.ForbiddenAction);
  }

  const dealRows = await base44.asServiceRole.entities.Deal.filter({ deal_id: String(participant.deal_id) }, "-created_date", 1);
  const deal = dealRows?.[0];
  if (!deal) return fail(404, "deal not found", ErrorCode.InvalidInput);
  const seller = (await base44.asServiceRole.entities.SellerAccount.filter({ seller_id: String(deal.seller_id || "") }, "-created_date", 1).catch(() => []))?.[0];

  const completionUntil = deal.completion_window_until ? String(deal.completion_window_until) : null;
  const secondsRemaining = completionUntil ? Math.max(0, Math.floor((Date.parse(completionUntil) - Date.now()) / 1000)) : null;
  const dealType = String(deal.deal_type || "physical_product");
  const reservations = Array.isArray(deal.join_reservations) ? deal.join_reservations : [];
  const participantCount = new Set(reservations.map((row: any) => String(row?.buyer_id || "").trim()).filter(Boolean)).size;
  const unitRows = dealType === "physical_product"
    ? []
    : await base44.asServiceRole.entities.FulfillmentUnit.filter({ participant_id: participantId, deal_id: String(participant.deal_id) }, "unit_index", 1000).catch(() => []);
  const fulfillmentUnits = (unitRows || []).map((unit: any) => ({
    fulfillment_unit_id: String(unit.fulfillment_unit_id || ""),
    fulfillment_kind: String(unit.fulfillment_kind || ""),
    unit_index: Number(unit.unit_index || 0),
    status: String(unit.status || ""),
    code_display_last4: unit.code_display_last4 ? String(unit.code_display_last4).slice(-4) : null,
    issued_at: unit.issued_at || null,
    sent_at: unit.sent_at || null,
    redeemed_at: unit.redeemed_at || null,
    expired_at: unit.expired_at || null
  }));

  return Response.json({
    ok: true,
    participant: {
      participant_id: String(participant.participant_id),
      deal_id: String(participant.deal_id),
      qty: Number(participant.qty || 0),
      buyer_state: String(participant.buyer_state || ""),
      money_state: String(participant.money_state || ""),
      hold_total: Number(participant.hold_total || 0),
      delivery_method_type: participant.delivery_method_type || null,
      delivery_method_label: participant.delivery_method_label || null,
      delivery_cost: Number(participant.delivery_cost || 0)
    },
    deal: {
      title: String(deal.title || ""),
      deal_type: dealType,
      state: String(deal.state || ""),
      seller_display_name: String(seller?.business_name || seller?.display_name || deal.seller_display_name || ""),
      seller_contact: seller ? {
        support_phone: String(seller.support_phone || ""),
        support_email: String(seller.support_email || "")
      } : null,
      deadline: deal.deadline || null,
      min_units: Number(deal.min_units || 0),
      threshold_units: Number(deal.threshold_units || 0),
      reserved_units: Number(deal.reserved_units || 0),
      max_units: Number(deal.max_units || 0),
      participant_count: participantCount,
      updated_at: deal.updated_date || deal.updated_at || null,
      completion_window_until: completionUntil,
      completion_seconds_remaining: secondsRemaining,
      voucher_terms: dealType === "voucher" && deal.voucher_terms ? {
        face_value_amount: Number(deal.voucher_terms.face_value_amount || 0),
        currency: String(deal.voucher_terms.currency || "ILS"),
        valid_from: deal.voucher_terms.valid_from || null,
        valid_until: deal.voucher_terms.valid_until || null,
        redemption_location: String(deal.voucher_terms.redemption_location || ""),
        redemption_instructions: String(deal.voucher_terms.redemption_instructions || "")
      } : null,
      ticket_terms: dealType === "ticket" && deal.ticket_terms ? {
        event_name: String(deal.ticket_terms.event_name || ""),
        event_starts_at: deal.ticket_terms.event_starts_at || null,
        event_ends_at: deal.ticket_terms.event_ends_at || null,
        venue_name: String(deal.ticket_terms.venue_name || ""),
        venue_address: String(deal.ticket_terms.venue_address || ""),
        venue_city: String(deal.ticket_terms.venue_city || ""),
        entry_instructions: String(deal.ticket_terms.entry_instructions || ""),
        ticket_type: String(deal.ticket_terms.ticket_type || "general_admission")
      } : null
    },
    fulfillment_units: fulfillmentUnits,
    fulfillment: {
      expected_units: Math.max(0, Number(participant.qty || 0)),
      existing_units: fulfillmentUnits.length,
      issuance_enabled: false,
      issuance_blocker: dealType === "physical_product" ? null : "reliable one-time full-code delivery is not proven"
    },
    safety: {
      join_enabled: false,
      real_money_enabled: false
    },
    refreshed_at: new Date().toISOString()
  });
});
