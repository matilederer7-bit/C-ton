import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const STATUSES = new Set(["Open","NeedsSeller","NeedsAdmin","WaitingExternal","Resolved","Closed"]);
const PRIORITIES = new Set(["Low","Normal","High","Urgent"]);
const TYPES = new Set(["RefundRequest","DeliveryIssue","SellerRisk","BuyerComplaint","PaymentMismatch","InvoiceIssue","ContentReport","SystemException","Other"]);
const CLOSED = new Set(["Resolved","Closed"]);
const SLA_MS: Record<string, number> = {
  Urgent: 4 * 60 * 60_000,
  High: 24 * 60 * 60_000,
  Normal: 72 * 60 * 60_000,
  Low: 7 * 24 * 60 * 60_000
};

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}

function text(value: unknown, max: number) {
  return String(value ?? "").trim().slice(0, max);
}

function uuid(value: unknown) {
  const result = text(value, 80);
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(result) ? result : "";
}

function event(args: { caseId: string; type: string; requestId: string; idem: string; actor: string; payload: Record<string, unknown>; createdAt?: string }) {
  return {
    event_id: crypto.randomUUID(),
    case_id: args.caseId,
    event_type: args.type,
    request_id: args.requestId,
    idempotency_key: args.idem,
    actor_user_id: args.actor,
    created_at: args.createdAt || new Date().toISOString(),
    payload: args.payload
  };
}

function slaView(row: any, now = Date.now()) {
  const priority = String(row.priority || "Normal");
  const opened = Date.parse(String(row.opened_at || row.created_date || ""));
  const isOpen = !CLOSED.has(String(row.status || ""));
  const deadline = Number.isFinite(opened) ? opened + (SLA_MS[priority] || SLA_MS.Normal) : null;
  const overdue = Boolean(isOpen && deadline !== null && now > deadline);
  return {
    ...row,
    sla_due_at: deadline === null ? null : new Date(deadline).toISOString(),
    sla_overdue: overdue,
    sla_seconds_overdue: overdue && deadline !== null ? Math.floor((now - deadline) / 1000) : 0
  };
}

async function writeEvent(admin: any, row: any) {
  await admin.entities.OperationalCaseEvent.create(row).catch(() => undefined);
}

async function listCases(admin: any, body: any) {
  const query: Record<string, unknown> = {};
  if (body.status && STATUSES.has(String(body.status))) query.status = String(body.status);
  if (body.priority && PRIORITIES.has(String(body.priority))) query.priority = String(body.priority);
  if (body.case_type && TYPES.has(String(body.case_type))) query.case_type = String(body.case_type);
  if (body.deal_id) query.deal_id = text(body.deal_id, 80);
  if (body.seller_id) query.seller_id = text(body.seller_id, 120);
  const limit = Math.min(500, Math.max(1, Number(body.limit || 200)));
  const rows = await admin.entities.OperationalCase.filter(query, "-opened_at", limit);
  const cases = (rows || []).map((row: any) => slaView(row));
  const open = cases.filter((row: any) => !CLOSED.has(String(row.status))).length;
  const urgentOpen = cases.filter((row: any) => row.status !== "Resolved" && row.status !== "Closed" && row.priority === "Urgent").length;
  const highOpen = cases.filter((row: any) => row.status !== "Resolved" && row.status !== "Closed" && row.priority === "High").length;
  const overdue = cases.filter((row: any) => row.sla_overdue);
  const sla: Record<string, number> = { Urgent: 0, High: 0, Normal: 0, Low: 0 };
  for (const row of overdue) sla[String(row.priority)] = (sla[String(row.priority)] || 0) + 1;
  return {
    ok: true,
    cases,
    support_readiness: {
      open,
      urgent_open: urgentOpen,
      high_open: highOpen,
      overdue_count: overdue.length,
      sla,
      sla_breached_cases: overdue.slice(0, 20).map((row: any) => ({ case_id: row.case_id, subject: row.subject, priority: row.priority, status: row.status, sla_due_at: row.sla_due_at })),
      verdict: overdue.some((row: any) => row.priority === "Urgent") ? "blocked" : overdue.length || urgentOpen || highOpen ? "warning" : "ready"
    }
  };
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (String(user?.role || "") !== "admin") return fail(403, "admin required", ErrorCode.ForbiddenAction);
  const admin = base44.asServiceRole;

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const operation = String(body?.operation || "list");

  if (operation === "list") return Response.json(await listCases(admin, body));

  if (operation === "create") {
    const subject = text(body.subject, 200);
    const reason = text(body.reason, 2000);
    const caseType = String(body.case_type || "Other");
    const priority = String(body.priority || "Normal");
    if (!subject) return fail(400, "subject is required", ErrorCode.InvalidInput);
    if (!reason) return fail(400, "reason is required", ErrorCode.InvalidInput);
    if (!TYPES.has(caseType)) return fail(400, "invalid case type", ErrorCode.InvalidInput);
    if (!PRIORITIES.has(priority)) return fail(400, "invalid priority", ErrorCode.InvalidInput);

    const autoKey = text(body.auto_key, 300);
    if (autoKey) {
      const prior = await admin.entities.OperationalCase.filter({ auto_key: autoKey }, "-opened_at", 1);
      if (prior?.[0]) return Response.json({ ok: true, case: slaView(prior[0]), replay: true });
    }

    const caseId = crypto.randomUUID();
    const now = new Date().toISOString();
    const requestId = text(body.request_id, 200) || `req:${crypto.randomUUID()}`;
    const idem = text(body.idempotency_key, 300) || `case-create:${caseId}`;
    const createdEvent = event({ caseId, type: "case.create", requestId, idem, actor: String(user.id), createdAt: now, payload: { reason, case_type: caseType, priority } });
    const row = await admin.entities.OperationalCase.create({
      case_id: caseId,
      case_type: caseType,
      priority,
      status: "Open",
      subject,
      reason,
      last_note: text(body.note, 4000) || null,
      resolution_note: null,
      assignee: text(body.assignee, 200) || null,
      deal_id: uuid(body.deal_id) || null,
      participant_id: uuid(body.participant_id) || null,
      seller_id: text(body.seller_id, 120) || null,
      correlation_id: text(body.correlation_id, 200) || null,
      request_id: requestId,
      auto_key: autoKey || null,
      opened_at: now,
      event_journal: [createdEvent]
    });
    await writeEvent(admin, createdEvent);
    return Response.json({ ok: true, case: slaView(row), replay: false });
  }

  const caseId = uuid(body.case_id);
  if (!caseId) return fail(400, "case_id must be a UUID", ErrorCode.InvalidInput);
  const current = (await admin.entities.OperationalCase.filter({ case_id: caseId }, "-opened_at", 1))?.[0];
  if (!current) return fail(404, "support case not found", ErrorCode.InvalidInput);

  if (operation === "escalate") {
    const reason = text(body.reason, 2000);
    if (!reason) return fail(400, "reason is required", ErrorCode.InvalidInput);
    if (CLOSED.has(String(current.status))) return fail(409, "closed case cannot be escalated", ErrorCode.IllegalStateTransition);
    const requestId = text(body.request_id, 200) || `req:${crypto.randomUUID()}`;
    const idem = text(body.idempotency_key, 300) || `case-escalate:${caseId}:${requestId}`;
    const ev = event({ caseId, type: "case.escalate", requestId, idem, actor: String(user.id), payload: { reason, from_priority: current.priority, to_priority: "Urgent" } });
    await admin.entities.OperationalCase.update(current.id, { priority: "Urgent", reason, last_note: text(body.note, 4000) || current.last_note || null, event_journal: [...(Array.isArray(current.event_journal) ? current.event_journal : []), ev] });
    await writeEvent(admin, ev);
    const latest = (await admin.entities.OperationalCase.filter({ case_id: caseId }, "-opened_at", 1))?.[0];
    return Response.json({ ok: true, case: slaView(latest) });
  }

  if (operation !== "update") return fail(400, "unsupported support operation", ErrorCode.InvalidInput);
  const reason = text(body.reason, 2000);
  if (!reason) return fail(400, "reason is required on every case change", ErrorCode.InvalidInput);

  const nextStatus = body.status ? String(body.status) : String(current.status);
  const nextPriority = body.priority ? String(body.priority) : String(current.priority);
  if (!STATUSES.has(nextStatus)) return fail(400, "invalid status", ErrorCode.InvalidInput);
  if (!PRIORITIES.has(nextPriority)) return fail(400, "invalid priority", ErrorCode.InvalidInput);
  const resolution = body.resolution_note !== undefined ? text(body.resolution_note, 4000) : text(current.resolution_note, 4000);
  if (CLOSED.has(nextStatus) && !resolution) return fail(409, "resolution_note is required for Resolved or Closed", ErrorCode.IllegalStateTransition);

  const assignee = body.assignee !== undefined ? text(body.assignee, 200) : text(current.assignee, 200);
  const statusChanged = nextStatus !== String(current.status);
  const assigneeChanged = assignee !== text(current.assignee, 200);
  const requestId = text(body.request_id, 200) || `req:${crypto.randomUUID()}`;
  const idem = text(body.idempotency_key, 300) || `case-update:${caseId}:${requestId}`;
  const eventType = CLOSED.has(nextStatus) && statusChanged ? "case.close" : assigneeChanged && !statusChanged ? "case.assign" : "case.update_status";
  const ev = event({ caseId, type: eventType, requestId, idem, actor: String(user.id), payload: { reason, from_status: current.status, to_status: nextStatus, from_priority: current.priority, to_priority: nextPriority, from_assignee: current.assignee || null, to_assignee: assignee || null, note: text(body.note, 4000) || null } });
  const now = new Date().toISOString();
  await admin.entities.OperationalCase.update(current.id, {
    status: nextStatus,
    priority: nextPriority,
    assignee: assignee || null,
    reason,
    last_note: body.note !== undefined ? text(body.note, 4000) || null : current.last_note || null,
    resolution_note: resolution || null,
    resolved_at: nextStatus === "Resolved" ? (current.resolved_at || now) : current.resolved_at || null,
    closed_at: nextStatus === "Closed" ? (current.closed_at || now) : current.closed_at || null,
    request_id: requestId,
    event_journal: [...(Array.isArray(current.event_journal) ? current.event_journal : []), ev]
  });
  await writeEvent(admin, ev);
  const latest = (await admin.entities.OperationalCase.filter({ case_id: caseId }, "-opened_at", 1))?.[0];
  return Response.json({ ok: true, case: slaView(latest) });
});
