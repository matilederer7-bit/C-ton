import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const BACKOFF_SECONDS=[30,90,270];
function fail(status:number,error:string,code?:string){return Response.json({ok:false,error,...(code?{code}:{})},{status});}
async function hash(value:string){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(value));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("");}
async function authorized(req:any,base44:any,body:any){
  try{const u=await base44.auth.me();if(String(u?.role||"")==="admin")return true;}catch{}
  const expected=String(Deno.env.get("NOTIFICATION_WORKER_INTERNAL_SECRET")||"");
  if(expected.length<32)return false;return (await hash(String(body?.internal_call_token||"")))===(await hash(expected));
}
async function destination(admin:any,row:any){
  const channel=String(row.channel||"");
  if(row.recipient_type==="buyer"&&row.participant_id){const p=(await admin.entities.Participant.filter({participant_id:String(row.participant_id)},"-created_date",1))?.[0];if(!p)return null;return channel==="email"?p.buyer_email:channel==="sms"?p.buyer_phone:null;}
  if(row.recipient_type==="seller"&&row.seller_id){const s=(await admin.entities.SellerAccount.filter({seller_id:String(row.seller_id)},"-created_date",1))?.[0];if(!s)return null;return channel==="email"?s.support_email:channel==="sms"?s.support_phone:null;}
  return null;
}
Deno.serve(async(req)=>{
  if(req.method!=="POST")return fail(405,"method_not_allowed", ErrorCode.ForbiddenAction);
  const base44=createClientFromRequest(req);let body:any;try{body=await req.json();}catch{return fail(400,"invalid JSON body",ErrorCode.InvalidInput);}
  if(!(await authorized(req,base44,body)))return fail(403,"worker authorization required", ErrorCode.ForbiddenAction);
  const admin=base44.asServiceRole,limit=Math.max(1,Math.min(50,Number(body?.limit||20))),now=new Date().toISOString();
  const rows=await admin.entities.NotificationEvent.filter({status:"pending",scheduled_for:{$lte:now}},"scheduled_for",limit).catch(()=>[]);
  const results=[];
  for(const row of rows||[]){
    const notificationId=String(row.notification_id||"");
    const claimed=await admin.entities.NotificationEvent.updateMany({notification_id:notificationId,status:"pending",attempt_count:Number(row.attempt_count||0)},{ $set:{status:"processing",updated_at:new Date().toISOString()} });
    if(Number(claimed?.updated||0)!==1){results.push({notification_id:notificationId,result:"not_claimed"});continue;}
    const dest=await destination(admin,row);
    if(!dest){await admin.entities.NotificationEvent.updateMany({notification_id:notificationId,status:"processing"},{ $set:{status:"failed",last_error:"recipient_destination_unavailable",updated_at:new Date().toISOString()},$inc:{attempt_count:1} });results.push({notification_id:notificationId,result:"destination_missing"});continue;}
    const internal=String(Deno.env.get("COMMUNICATION_INTERNAL_CALL_SECRET")||"");let delivery:any;
    if(internal.length<32){delivery={result_class:"skipped",provider:"log",provider_mode:"disabled",error_code:"communication_provider_not_connected",error_message:"communication provider not connected"};}
    else try{const r=await admin.functions.invoke("communication-delivery",{internal_call_token:internal,channel:row.channel,destination:dest,template_key:row.template_key,locale:row.locale||"he-IL",idempotency_key:String(row.idempotency_key),variables:row.payload_jsonb||{}});delivery=r?.data||r;}catch{delivery={result_class:"unknown",provider:"provider-ready",provider_mode:"configured",error_code:"delivery_invocation_unknown",error_message:"delivery invocation outcome unknown"};}
    const resultClass=String(delivery?.result_class||"unknown"),actualAttempt=resultClass!=="skipped",nextAttempt=Number(row.attempt_count||0)+(actualAttempt?1:0);
    const rawProviderMode=String(delivery?.provider_mode||"disabled").toLowerCase();
    const providerMode=["dev","real","disabled","log-only"].includes(rawProviderMode)?rawProviderMode:(resultClass==="skipped"?"disabled":"real");
    await admin.entities.NotificationAttempt.create({attempt_id:crypto.randomUUID(),notification_id:notificationId,provider:String(delivery?.provider||"provider-ready"),provider_mode:providerMode,result_status:resultClass,provider_message_id:delivery?.provider_message_id||null,error_code:delivery?.error_code||null,error_message:delivery?.error_message||null,created_at:new Date().toISOString()}).catch(()=>undefined);
    if(resultClass==="success"){
      await admin.entities.NotificationEvent.updateMany({notification_id:notificationId,status:"processing"},{ $set:{status:"sent",attempt_count:nextAttempt,provider_code:String(delivery.provider||"provider-ready"),provider_message_id:delivery.provider_message_id||null,sent_at:new Date().toISOString(),last_error:"",updated_at:new Date().toISOString()},$push:{event_journal:{event_type:"notification.sent",created_at:new Date().toISOString(),payload:{provider:String(delivery.provider||"provider-ready")}}} });
    }else if(resultClass==="permanent_fail"||nextAttempt>=Number(row.max_attempts||3)){
      await admin.entities.NotificationEvent.updateMany({notification_id:notificationId,status:"processing"},{ $set:{status:"failed",attempt_count:nextAttempt,last_error:String(delivery?.error_code||resultClass),updated_at:new Date().toISOString()},$push:{event_journal:{event_type:"notification.failed",created_at:new Date().toISOString(),payload:{result_class:resultClass}}} });
    }else{
      const delay=resultClass==="skipped"?300:BACKOFF_SECONDS[Math.min(nextAttempt,BACKOFF_SECONDS.length)-1]||270;
      await admin.entities.NotificationEvent.updateMany({notification_id:notificationId,status:"processing"},{ $set:{status:"pending",attempt_count:nextAttempt,scheduled_for:new Date(Date.now()+delay*1000).toISOString(),last_error:String(delivery?.error_code||resultClass),updated_at:new Date().toISOString()},$push:{event_journal:{event_type:"notification.retry_scheduled",created_at:new Date().toISOString(),payload:{result_class:resultClass,delay_seconds:delay}}} });
    }
    results.push({notification_id:notificationId,result:resultClass});
  }
  return Response.json({ok:true,processed:results.length,results});
});
