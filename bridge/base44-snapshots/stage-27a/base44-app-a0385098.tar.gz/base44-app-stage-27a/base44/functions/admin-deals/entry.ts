import { BuyerState, DealState, ErrorCode, MoneyState } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}

function asArray(value: unknown) { return Array.isArray(value) ? value : []; }
function num(value: unknown) { const n = Number(value || 0); return Number.isFinite(n) ? n : 0; }
function iso(value: unknown) { const t = Date.parse(String(value || "")); return Number.isFinite(t) ? new Date(t).toISOString() : null; }
function qty(rows: any[], predicate: (row: any) => boolean) {
  return rows.reduce((sum, row) => predicate(row) ? sum + Math.max(0, num(row?.qty)) : sum, 0);
}

async function listAll(entity: any, sort = "-created_date", max = 10000) {
  const out: any[] = [];
  let skip = 0;
  while (out.length < max) {
    const take = Math.min(5000, max - out.length);
    const page = await entity.list(sort, take, skip);
    if (!Array.isArray(page) || page.length === 0) break;
    out.push(...page);
    if (page.length < take) break;
    skip += page.length;
  }
  return out;
}

function aggregateDeal(deal: any) {
  const reservations = asArray(deal?.join_reservations);
  const finalUnits = qty(reservations, (r) => [MoneyState.ChargedSuccess, MoneyState.RecoveredCharge].includes(String(r?.money_state || "")));
  const recoveredUnits = qty(reservations, (r) => String(r?.money_state || "") === MoneyState.RecoveredCharge);
  const pendingUnits = qty(reservations, (r) => String(r?.buyer_state || "") === BuyerState.ChargeFailedCompletion || String(r?.money_state || "") === MoneyState.ChargeFailedRecovery);
  const totalUnits = qty(reservations, () => true);
  const participantRecords = reservations.length;
  return {
    final_units: finalUnits,
    recovered_units: recoveredUnits,
    pending_units: pendingUnits,
    failed_units: Math.max(0, totalUnits - finalUnits - pendingUnits),
    participant_records: participantRecords,
    total_units: totalUnits
  };
}

function buildAttemptMaps(attempts: any[]) {
  const failedByDealParticipant = new Map<string, number>();
  const oldAuthorizationParticipants = new Set<string>();
  const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  for (const row of attempts) {
    const dealId = String(row?.deal_id || "");
    const participantId = String(row?.participant_id || "");
    const type = String(row?.attempt_type || "");
    const result = String(row?.result_class || "");
    if (dealId && participantId && ["charge_start", "recovery"].includes(type) && result !== "success") {
      const key = `${dealId}:${participantId}`;
      failedByDealParticipant.set(key, (failedByDealParticipant.get(key) || 0) + 1);
    }
    if (participantId && type === "authorization" && result === "success") {
      const started = Date.parse(String(row?.started_at || row?.created_date || ""));
      if (Number.isFinite(started) && started < sevenDaysAgo) oldAuthorizationParticipants.add(participantId);
    }
  }
  return { failedByDealParticipant, oldAuthorizationParticipants };
}

function anomaliesForDeal(deal: any, attemptsBy: ReturnType<typeof buildAttemptMaps>) {
  const anomalies: string[] = [];
  const aggregate = aggregateDeal(deal);
  const state = String(deal?.state || "");
  const now = Date.now();
  if (state === DealState.CompletionWindow && deal?.completion_window_until) {
    const end = Date.parse(String(deal.completion_window_until));
    if (Number.isFinite(end) && end > now && end - now < 60 * 60 * 1000) anomalies.push("completion_window_lt_1h");
  }
  if (state === DealState.Completed && aggregate.final_units === 0) anomalies.push("completed_zero_charged");
  if (["synced", "closed"].includes(String(deal?.inventory_sync_status || "")) && num(deal?.inventory_committed_units) !== num(deal?.reserved_units)) {
    anomalies.push("inventory_projection_mismatch");
  }
  const activeAuthParticipantIds = new Set(
    asArray(deal?.join_reservations)
      .filter((r: any) => [MoneyState.AuthHeld, MoneyState.AuthLocked].includes(String(r?.money_state || "")))
      .map((r: any) => String(r?.participant_id || ""))
      .filter(Boolean)
  );
  if ([...activeAuthParticipantIds].some((id) => attemptsBy.oldAuthorizationParticipants.has(id))) anomalies.push("authorization_over_7d");
  const participantIds = asArray(deal?.join_reservations).map((r: any) => String(r?.participant_id || "")).filter(Boolean);
  if (participantIds.some((id: string) => (attemptsBy.failedByDealParticipant.get(`${deal.deal_id}:${id}`) || 0) >= 3)) anomalies.push("three_failed_attempts");
  return anomalies;
}

function listProjection(deal: any, attemptsBy: ReturnType<typeof buildAttemptMaps>) {
  const agg = aggregateDeal(deal);
  const anomalies = anomaliesForDeal(deal, attemptsBy);
  const images = asArray(deal?.images).slice().sort((a: any, b: any) => num(a?.sort_order) - num(b?.sort_order));
  return {
    deal_id: String(deal?.deal_id || ""),
    title: String(deal?.title || ""),
    seller_id: String(deal?.seller_id || ""),
    seller_display_name: String(deal?.seller_display_name || ""),
    state: String(deal?.state || ""),
    deal_type: String(deal?.deal_type || "physical_product"),
    reserved_units: num(deal?.reserved_units),
    threshold_units: num(deal?.threshold_units),
    max_units: num(deal?.max_units),
    deadline: iso(deal?.deadline),
    completion_window_until: iso(deal?.completion_window_until),
    updated_at: iso(deal?.updated_date || deal?.updated_at || deal?.created_date),
    primary_image_url: images?.[0]?.file_url ? String(images[0].file_url) : null,
    ...agg,
    anomalies
  };
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (String(user?.role || "") !== "admin") return fail(403, "admin required", ErrorCode.ForbiddenAction);

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const operation = String(body?.operation || "list");
  const admin = base44.asServiceRole;

  if (operation === "list") {
    const [deals, attempts] = await Promise.all([listAll(admin.entities.Deal), listAll(admin.entities.PaymentAttempt)]);
    const attemptsBy = buildAttemptMaps(attempts);
    const filter = String(body?.filter || "anomalies");
    const allowedFilters = new Set(["anomalies", "all", "completion_window_lt_1h", "completed_zero_charged", "inventory_projection_mismatch", "authorization_over_7d", "three_failed_attempts"]);
    if (!allowedFilters.has(filter)) return fail(400, "invalid filter", ErrorCode.InvalidInput);
    let rows = deals.map((deal: any) => listProjection(deal, attemptsBy));
    if (filter === "anomalies") rows = rows.filter((row: any) => row.anomalies.length > 0);
    else if (filter !== "all") rows = rows.filter((row: any) => row.anomalies.includes(filter));
    rows.sort((a: any, b: any) => Date.parse(String(b.updated_at || 0)) - Date.parse(String(a.updated_at || 0)));
    return Response.json({
      ok: true,
      filter,
      deals: rows.slice(0, 500),
      total: rows.length,
      available_filters: [...allowedFilters],
      generated_at: new Date().toISOString(),
      financial_amounts_proven: false
    });
  }

  if (operation === "detail") {
    const dealId = String(body?.deal_id || "").trim();
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(dealId)) return fail(400, "invalid deal_id", ErrorCode.InvalidInput);
    const deal = (await admin.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1))?.[0];
    if (!deal) return fail(404, "deal not found", ErrorCode.InvalidInput);
    const [attempts, outbox, audits, cases] = await Promise.all([
      admin.entities.PaymentAttempt.filter({ deal_id: dealId }, "-started_at", 500).catch(() => []),
      admin.entities.OutboxEvent.filter({ aggregate_id: dealId }, "-created_date", 500).catch(() => []),
      admin.entities.DealAudit.filter({ deal_id: dealId }, "-created_date", 100).catch(() => []),
      admin.entities.OperationalCase.filter({ deal_id: dealId }, "-created_date", 100).catch(() => [])
    ]);
    const attemptsBy = buildAttemptMaps(attempts || []);
    const base = listProjection(deal, attemptsBy);
    const moneyStates: Record<string, number> = {};
    const buyerStates: Record<string, number> = {};
    for (const row of asArray(deal.join_reservations)) {
      const m = String(row?.money_state || "unknown"), b = String(row?.buyer_state || "unknown"), q = Math.max(0, num(row?.qty));
      moneyStates[m] = (moneyStates[m] || 0) + q;
      buyerStates[b] = (buyerStates[b] || 0) + q;
    }
    const embeddedAudit = asArray(deal.transition_journal).map((row: any) => ({
      state_type: String(row?.state_type || ""), from_state: String(row?.from_state || ""), to_state: String(row?.to_state || ""),
      action_name: String(row?.action_name || ""), request_id: String(row?.request_id || ""), created_at: iso(row?.created_at)
    })).filter((row: any) => row.action_name);
    const projectedAudit = asArray(audits).map((row: any) => ({
      state_type: String(row?.state_type || ""), from_state: String(row?.from_state || ""), to_state: String(row?.to_state || ""),
      action_name: String(row?.action_name || ""), request_id: String(row?.request_id || ""), created_at: iso(row?.created_date)
    }));
    const auditMap = new Map<string, any>();
    for (const row of [...embeddedAudit, ...projectedAudit]) auditMap.set(`${row.action_name}:${row.request_id}:${row.from_state}:${row.to_state}`, row);
    const audit = [...auditMap.values()].sort((a: any, b: any) => Date.parse(String(b.created_at || 0)) - Date.parse(String(a.created_at || 0))).slice(0, 50);

    return Response.json({
      ok: true,
      deal: {
        ...base,
        price_per_unit: num(deal.price_per_unit),
        min_units: num(deal.min_units),
        published_at: iso(deal.published_at),
        inventory_sync_status: String(deal.inventory_sync_status || "not_configured"),
        inventory_reserved_units: num(deal.inventory_reserved_units),
        inventory_committed_units: num(deal.inventory_committed_units)
      },
      buyer_state_units: buyerStates,
      money_state_units: moneyStates,
      audit,
      payment_attempts: asArray(attempts).slice(0, 100).map((row: any) => ({
        attempt_id: String(row?.attempt_id || ""), participant_id: String(row?.participant_id || ""), attempt_type: String(row?.attempt_type || ""),
        result_class: String(row?.result_class || ""), error_code: String(row?.error_code || ""), correlation_id: String(row?.correlation_id || ""),
        started_at: iso(row?.started_at), completed_at: iso(row?.completed_at)
      })),
      outbox: asArray(outbox).slice(0, 100).map((row: any) => ({
        event_uuid: String(row?.event_uuid || ""), event_type: String(row?.event_type || ""), status: String(row?.status || ""),
        attempt_count: num(row?.attempt_count), max_attempts: num(row?.max_attempts), available_at: iso(row?.available_at),
        lease_expires_at: iso(row?.lease_expires_at), last_error: String(row?.last_error || "").slice(0, 300)
      })),
      support: asArray(cases).slice(0, 50).map((row: any) => ({ case_id: String(row?.case_id || ""), subject: String(row?.subject || ""), priority: String(row?.priority || ""), status: String(row?.status || ""), opened_at: iso(row?.opened_at || row?.created_date) })),
      safety: { read_only: true, refund: false, capture: false, void: false, money_edit: false },
      financial_amounts_proven: false
    });
  }

  return fail(400, "unsupported operation", ErrorCode.InvalidInput);
});