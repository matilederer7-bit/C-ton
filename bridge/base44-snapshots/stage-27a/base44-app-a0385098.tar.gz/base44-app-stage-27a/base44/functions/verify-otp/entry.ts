import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const OTP_TOKEN_TTL_MS = 15 * 60_000;
const encoder = new TextEncoder();

function error(status: number, message: string, code: string) {
  return Response.json({ ok: false, error: message, code }, { status });
}

function bytesToHex(bytes: ArrayBuffer) {
  return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function sha256Hex(value: string) {
  return bytesToHex(await crypto.subtle.digest("SHA-256", encoder.encode(value)));
}

async function hashOtpCode(code: string, challengeId: string, salt: string) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(code), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", iterations: 120_000, salt: encoder.encode(`${salt}:${challengeId}`) },
    key,
    256
  );
  return bytesToHex(bits);
}

function randomBase64Url(byteLength = 32) {
  const bytes = crypto.getRandomValues(new Uint8Array(byteLength));
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return error(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let body: any;
  try { body = await req.json(); } catch { return error(400, "invalid JSON body", ErrorCode.InvalidInput); }

  const challengeId = String(body.challenge_id || "").trim();
  const code = String(body.code || "").trim();
  if (!challengeId) return error(400, "challenge_id required", ErrorCode.InvalidInput);
  if (!/^\d{4,8}$/.test(code)) return error(400, "code must be 4-8 digits", ErrorCode.InvalidInput);

  const rows = await base44.asServiceRole.entities.OtpChallenge.filter({ challenge_id: challengeId }, "-created_date", 1);
  const challenge = rows?.[0];
  if (!challenge) return error(400, "challenge not found", ErrorCode.InvalidInput);

  const status = String(challenge.status || "");
  if (status === "consumed") return error(409, "otp challenge was already consumed", ErrorCode.IllegalStateTransition);
  if (status === "locked") return error(423, "too many attempts", ErrorCode.ForbiddenAction);
  if (status === "cancelled") return error(400, "challenge cancelled", ErrorCode.InvalidInput);
  if (status === "expired" || Date.parse(String(challenge.expires_at || "")) <= Date.now()) {
    await base44.asServiceRole.entities.OtpChallenge.updateMany(
      { challenge_id: challengeId, status: "pending" },
      { $set: { status: "expired", last_error: "otp_expired" } }
    );
    return error(410, "challenge expired", ErrorCode.NotInWindow);
  }

  const expectedHash = await hashOtpCode(code, challengeId, String(challenge.code_salt || ""));
  const codeMatches = expectedHash === String(challenge.code_hash || "");
  const testBypass = String(Deno.env.get("OTP_TEST_BYPASS_CODE") || "").trim();
  const bypassMatches = Boolean(testBypass && code === testBypass && Deno.env.get("OTP_TEST_BYPASS_ENABLED") === "true");

  if (codeMatches || bypassMatches) {
    const verifiedAt = new Date().toISOString();
    const proofExpiresAt = new Date(Date.now() + OTP_TOKEN_TTL_MS).toISOString();
    const otpToken = `v1.${challengeId}.${randomBase64Url(32)}`;
    const proofTokenHash = await sha256Hex(`otp-proof:${otpToken}`);
    const maxAttempts = Number(challenge.max_attempts || 3);

    const consumed = await base44.asServiceRole.entities.OtpChallenge.updateMany(
      {
        challenge_id: challengeId,
        status: "pending",
        expires_at: { $gt: verifiedAt },
        attempts_count: { $lt: maxAttempts },
        code_hash: String(challenge.code_hash || "")
      },
      {
        $set: {
          status: "consumed",
          verified_at: verifiedAt,
          consumed_at: verifiedAt,
          proof_token_hash: proofTokenHash,
          proof_expires_at: proofExpiresAt,
          last_error: ""
        },
        $inc: { attempts_count: 1 }
      }
    );

    if (Number(consumed?.updated || 0) === 1) {
      return Response.json({
        ok: true,
        challenge_id: challengeId,
        status: "verified",
        destination_hash: challenge.destination_hash,
        channel: challenge.channel,
        purpose: challenge.purpose,
        deal_id: challenge.deal_id || null,
        verified_at: verifiedAt,
        otp_token: otpToken
      });
    }

    const latest = (await base44.asServiceRole.entities.OtpChallenge.filter({ challenge_id: challengeId }, "-created_date", 1))?.[0];
    if (latest?.status === "consumed") return error(409, "otp challenge was already consumed", ErrorCode.IllegalStateTransition);
    if (latest?.status === "locked") return error(423, "too many attempts", ErrorCode.ForbiddenAction);
    if (!latest || Date.parse(String(latest.expires_at || "")) <= Date.now()) return error(410, "challenge expired", ErrorCode.NotInWindow);
    return error(409, "otp verification lost conditional update", ErrorCode.IllegalStateTransition);
  }

  const maxAttempts = Number(challenge.max_attempts || 3);
  const failed = await base44.asServiceRole.entities.OtpChallenge.updateMany(
    {
      challenge_id: challengeId,
      status: "pending",
      expires_at: { $gt: new Date().toISOString() },
      attempts_count: { $lt: maxAttempts }
    },
    { $inc: { attempts_count: 1 }, $set: { last_error: "otp_invalid" } }
  );

  if (Number(failed?.updated || 0) !== 1) {
    const latest = (await base44.asServiceRole.entities.OtpChallenge.filter({ challenge_id: challengeId }, "-created_date", 1))?.[0];
    if (latest?.status === "consumed") return error(409, "otp challenge was already consumed", ErrorCode.IllegalStateTransition);
    if (latest?.status === "locked") return error(423, "too many attempts", ErrorCode.ForbiddenAction);
    return error(400, "incorrect code", ErrorCode.InvalidInput);
  }

  const latest = (await base44.asServiceRole.entities.OtpChallenge.filter({ challenge_id: challengeId }, "-created_date", 1))?.[0];
  if (Number(latest?.attempts_count || 0) >= maxAttempts) {
    await base44.asServiceRole.entities.OtpChallenge.updateMany(
      { challenge_id: challengeId, status: "pending", attempts_count: { $gte: maxAttempts } },
      { $set: { status: "locked", last_error: "otp_locked" } }
    );
    return error(423, "too many attempts", ErrorCode.ForbiddenAction);
  }
  return error(400, "incorrect code", ErrorCode.InvalidInput);
});
