import { DealState, ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}
function cleanLabel(value: unknown) { return String(value || "").trim().slice(0, 120); }
function publicDealState(state: unknown) {
  return [DealState.PendingTarget, DealState.TargetReached, DealState.ClosedForJoining, DealState.ReadyForCharging, DealState.Charging, DealState.CompletionWindow, DealState.Completed, DealState.Failed].includes(String(state || ""));
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (!user?.id) return fail(401, "authentication required", ErrorCode.ForbiddenAction);
  const admin = base44.asServiceRole;
  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const operation = String(body?.operation || "list");
  const ownerUserId = String(user.id);

  if (operation === "create_link") {
    const accessId = String(body?.access_id || "").trim();
    if (!accessId) return fail(400, "access_id is required", ErrorCode.InvalidInput);
    const access = (await admin.entities.DistributorDealAccess.filter({ access_id: accessId, owner_user_id: ownerUserId, status: "active" }, "-created_at", 1))?.[0];
    if (!access) return fail(403, "active distributor access not found", ErrorCode.ForbiddenAction);
    const deal = (await admin.entities.Deal.filter({ deal_id: String(access.deal_id) }, "-created_date", 1))?.[0];
    if (!deal || !publicDealState(deal.state)) return fail(409, "deal is not available for distribution", ErrorCode.IllegalStateTransition);

    let sourceCode = "";
    for (let attempt = 0; attempt < 5; attempt += 1) {
      sourceCode = `dist-${String(accessId).slice(0, 8)}-${crypto.randomUUID().replace(/-/g, "").slice(0, 10)}`.toLowerCase();
      const exists = await admin.entities.DistributionSource.filter({ source_code: sourceCode }, "-created_date", 1);
      if (!exists?.[0]) break;
      sourceCode = "";
    }
    if (!sourceCode) return fail(503, "could not allocate unique distribution code", ErrorCode.TemporarilyUnavailable);
    const at = new Date().toISOString();
    const label = cleanLabel(body?.label) || String(deal.title || "Distributor link").slice(0, 120);
    const sourceId = crypto.randomUUID();
    const created = await admin.entities.DistributionSource.create({
      source_id: sourceId,
      source_code: sourceCode,
      display_name: label,
      source_type: "distributor",
      owner_user_id: ownerUserId,
      deal_id: String(access.deal_id),
      distributor_access_id: String(access.access_id),
      active: true,
      notes: "Distributor attribution only; no commission or payout entitlement.",
      created_by_user_id: ownerUserId,
      created_at: at,
      event_journal: [{ event_type: "distribution_source.distributor_link_created", created_at: at, actor_user_id: ownerUserId, payload: { access_id: accessId, deal_id: access.deal_id } }]
    });
    return Response.json({ ok: true, source: { source_id: created.source_id, source_code: created.source_code, display_name: created.display_name, deal_id: created.deal_id, active: created.active !== false }, financial_semantics: "attribution_only_no_distributor_commission" });
  }

  if (operation === "list") {
    const [accesses, sources, events, attributions, deals] = await Promise.all([
      admin.entities.DistributorDealAccess.filter({ owner_user_id: ownerUserId }, "-created_at", 500),
      admin.entities.DistributionSource.filter({ owner_user_id: ownerUserId, source_type: "distributor" }, "-created_at", 500),
      admin.entities.DistributionEvent.list("-created_at", 5000).catch(() => []),
      admin.entities.DistributionAttribution.list("-attributed_at", 5000).catch(() => []),
      admin.entities.Deal.list("-created_date", 1000)
    ]);
    const dealById = new Map((deals || []).map((row: any) => [String(row.deal_id || ""), row]));
    const accessById = new Map((accesses || []).map((row: any) => [String(row.access_id || ""), row]));
    const sourceRows = (sources || []).filter((source: any) => {
      const access = accessById.get(String(source.distributor_access_id || ""));
      return access && String(access.owner_user_id || "") === ownerUserId && String(access.deal_id || "") === String(source.deal_id || "");
    });
    const sourceIds = new Set(sourceRows.map((row: any) => String(row.source_id || "")));
    const metrics = new Map<string, { clicks: number; visits: number; joins: number; units: number }>();
    const ensure = (sourceId: string) => {
      const current = metrics.get(sourceId) || { clicks: 0, visits: 0, joins: 0, units: 0 };
      metrics.set(sourceId, current); return current;
    };
    for (const row of events || []) {
      const id = String(row.source_id || ""); if (!sourceIds.has(id)) continue;
      const m = ensure(id); if (row.event_type === "click") m.clicks += 1; if (row.event_type === "visit") m.visits += 1;
    }
    for (const row of attributions || []) {
      const id = String(row.source_id || ""); if (!sourceIds.has(id)) continue;
      const m = ensure(id); m.joins += 1; m.units += Number(row.qty || 0);
    }
    const sourceByAccess = new Map<string, any[]>();
    for (const source of sourceRows) {
      const key = String(source.distributor_access_id || "");
      const rows = sourceByAccess.get(key) || [];
      const m = ensure(String(source.source_id));
      rows.push({ source_id: source.source_id, source_code: source.source_code, display_name: source.display_name, active: source.active !== false, created_at: source.created_at || source.created_date || null, metrics: m });
      sourceByAccess.set(key, rows);
    }
    const items = (accesses || []).map((access: any) => {
      const deal = dealById.get(String(access.deal_id || ""));
      return {
        access_id: access.access_id,
        status: access.status,
        deal: deal ? { deal_id: deal.deal_id, title: deal.title, state: deal.state, deadline: deal.deadline || null, threshold_units: Number(deal.threshold_units || 0), reserved_units: Number(deal.reserved_units || 0), max_units: Number(deal.max_units || 0), public: publicDealState(deal.state) } : { deal_id: access.deal_id, title: "עסקה לא זמינה", state: null, public: false },
        sources: sourceByAccess.get(String(access.access_id)) || []
      };
    });
    return Response.json({ ok: true, accesses: items, financial_semantics: { distributor_commission: 0, payout_entitlement: false, attributed_activity_is_measurement_only: true } });
  }

  return fail(400, "unsupported distributor operation", ErrorCode.InvalidInput);
});
