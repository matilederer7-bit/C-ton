import { DealState, ErrorCode, MoneyState } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status:number,error:string,code?:string){return Response.json({ok:false,error,...(code?{code}:{})},{status});}
function asArray(v:unknown){return Array.isArray(v)?v:[];}
function parse(v:unknown){const t=Date.parse(String(v||""));return Number.isFinite(t)?t:null;}
async function list(entity:any,max=10000){try{return await entity.list("-created_date",max,0);}catch{return [];}}
function hourKey(ms:number){const d=new Date(ms);d.setMinutes(0,0,0);return d.toISOString();}

Deno.serve(async(req)=>{
 if(req.method!=="GET"&&req.method!=="POST")return fail(405,"method_not_allowed", ErrorCode.ForbiddenAction);
 const base44=createClientFromRequest(req);let user:any;try{user=await base44.auth.me();}catch{return fail(401,"authentication required",ErrorCode.ForbiddenAction);}
 if(String(user?.role||"")!=="admin")return fail(403,"admin required", ErrorCode.ForbiddenAction);
 const admin=base44.asServiceRole;
 const [deals,outbox,dlq,payments,notifications,cases]=await Promise.all([list(admin.entities.Deal,5000),list(admin.entities.OutboxEvent),list(admin.entities.OutboxDeadLetter),list(admin.entities.PaymentAttempt),list(admin.entities.NotificationEvent),list(admin.entities.OperationalCase,5000)]);
 const now=Date.now(),since=now-24*60*60*1000;
 const recent=(rows:any[],field:string)=>rows.filter(r=>{const t=parse(r?.[field]||r?.created_date);return t!==null&&t>=since;});
 const outbox24=recent(outbox,"created_date"),dlq24=recent(dlq,"dead_lettered_at"),payments24=recent(payments,"started_at"),notifications24=recent(notifications,"created_at");
 const staleProcessing=outbox.filter((r:any)=>String(r?.status||"")==="processing"&&parse(r?.lease_expires_at)!==null&&Number(parse(r?.lease_expires_at))<=now);
 const completionSoon=deals.filter((d:any)=>String(d?.state||"")===DealState.CompletionWindow&&parse(d?.completion_window_until)!==null&&Number(parse(d?.completion_window_until))>now&&Number(parse(d?.completion_window_until))-now<30*60*1000);
 const completedZero=deals.filter((d:any)=>{if(String(d?.state||"")!==DealState.Completed)return false;const reservations=asArray(d?.join_reservations);return !reservations.some((r:any)=>[MoneyState.ChargedSuccess,MoneyState.RecoveredCharge].includes(String(r?.money_state||""))&&Number(r?.qty||0)>0);});
 const supportOpen=cases.filter((c:any)=>!["Resolved","Closed"].includes(String(c?.status||"")));
 const supportOver72=supportOpen.filter((c:any)=>{const t=parse(c?.opened_at||c?.created_date);return t!==null&&now-t>72*60*60*1000;});
 const buckets=new Map<string,{outbox_failures:number;dlq:number;payment_uncertain_or_failed:number;notification_failures:number}>();
 for(let i=23;i>=0;i--){const key=hourKey(now-i*60*60*1000);buckets.set(key,{outbox_failures:0,dlq:0,payment_uncertain_or_failed:0,notification_failures:0});}
 const add=(rows:any[],dateField:string,field:keyof ReturnType<typeof Object.fromEntries>|string,pred:(r:any)=>boolean)=>{for(const r of rows){if(!pred(r))continue;const t=parse(r?.[dateField]||r?.created_date);if(t===null)continue;const key=hourKey(t);const bucket:any=buckets.get(key);if(bucket)bucket[field]=(bucket[field]||0)+1;}};
 add(outbox24,"created_date","outbox_failures",r=>["failed","dead_letter"].includes(String(r?.status||"")));
 add(dlq24,"dead_lettered_at","dlq",()=>true);
 add(payments24,"started_at","payment_uncertain_or_failed",r=>["unknown","permanent_fail"].includes(String(r?.result_class||"")));
 add(notifications24,"created_at","notification_failures",r=>String(r?.status||"")==="failed");
 const timeline=[...buckets.entries()].map(([hour,c])=>({hour,status:(c.outbox_failures||c.dlq||c.payment_uncertain_or_failed||c.notification_failures)?"red":"green",...c}));
 const queue={pending:outbox.filter((r:any)=>String(r?.status||"")==="pending").length,processing:outbox.filter((r:any)=>String(r?.status||"")==="processing").length,failed:outbox.filter((r:any)=>String(r?.status||"")==="failed").length,dead_letter:outbox.filter((r:any)=>String(r?.status||"")==="dead_letter").length,dlq:dlq.length,stale_processing:staleProcessing.length};
 const notificationStatus={pending:notifications.filter((r:any)=>String(r?.status||"")==="pending").length,processing:notifications.filter((r:any)=>String(r?.status||"")==="processing").length,sent:notifications.filter((r:any)=>String(r?.status||"")==="sent").length,failed:notifications.filter((r:any)=>String(r?.status||"")==="failed").length,skipped:notifications.filter((r:any)=>String(r?.status||"")==="skipped").length};
 const paymentStatus={attempts_24h:payments24.length,success_24h:payments24.filter((r:any)=>String(r?.result_class||"")==="success").length,temporary_fail_24h:payments24.filter((r:any)=>String(r?.result_class||"")==="temporary_fail").length,permanent_fail_24h:payments24.filter((r:any)=>String(r?.result_class||"")==="permanent_fail").length,unknown_24h:payments24.filter((r:any)=>String(r?.result_class||"")==="unknown").length};
 const critical=queue.dlq>0||completedZero.length>0;
 const warning=!critical&&(completionSoon.length>0||staleProcessing.length>0||supportOver72.length>0||paymentStatus.unknown_24h>0);
 const verdict=critical?"red":warning?"yellow":"green";
 return Response.json({ok:true,generated_at:new Date().toISOString(),verdict,queue,notifications:notificationStatus,payments:paymentStatus,anomalies:{completion_window_lt_30m:completionSoon.length,completed_zero_charged:completedZero.length,support_open_over_72h:supportOver72.length},workers:{processing_leases:queue.processing,stale_leases:queue.stale_processing,status:queue.stale_processing>0?"red":queue.processing>0?"active":"idle"},timeline_24h:timeline,rails:{reservation:{url_configured:Boolean(String(Deno.env.get("RESERVATION_SERVICE_URL")||"").trim()),secret_configured:Boolean(String(Deno.env.get("RESERVATION_SERVICE_SHARED_SECRET")||"").trim()),enforced:Deno.env.get("RESERVATION_SERVICE_ENFORCED")==="true",saga_proven:Deno.env.get("INVENTORY_SAGA_PROVEN")==="true"},otp:{external_delivery:false,mode:"log/migration"},payment:{external_provider:false,real_money_enabled:false},notifications:{external_provider:false},webhooks:{available_for_measurement:false,reason:"real payment webhook rail is not connected in Base44 migration"}},safety:{read_only:true,no_manual_money_actions:true}});
});