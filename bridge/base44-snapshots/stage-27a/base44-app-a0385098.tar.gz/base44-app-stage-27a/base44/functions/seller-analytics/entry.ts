import { BuyerState, DealState, ErrorCode, MoneyState } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const PERIODS = new Set(["all","30d","90d","year"]);
const ACTIVE = new Set([DealState.PendingTarget,DealState.TargetReached,DealState.ClosedForJoining,DealState.ReadyForCharging,DealState.Charging,DealState.CompletionWindow]);
const DAY_MS = 24 * 60 * 60_000;

function fail(status:number,error:string,code?:string){return Response.json({ok:false,error,...(code?{code}:{})},{status});}
function cutoff(period:string){const now=Date.now();if(period==="30d")return now-30*DAY_MS;if(period==="90d")return now-90*DAY_MS;if(period==="year")return now-365*DAY_MS;return null;}
function units(deal:any){const committed=Number(deal.inventory_committed_units||0);return committed>0?committed:Number(deal.reserved_units||0);}
function within24(value:any){const t=Date.parse(String(value||""));return Number.isFinite(t)&&t>=Date.now()&&t-Date.now()<=DAY_MS;}
function risk(deal:any){const state=String(deal.state||"");const current=units(deal);const threshold=Number(deal.threshold_units||0);const reasons:string[]=[];let level="low";
 if(state===DealState.Completed)return{risk_level:"completed",risk_reasons:[]};
 if(state===DealState.Failed||state===DealState.Cancelled)return{risk_level:"failed",risk_reasons:[]};
 if(state===DealState.CompletionWindow){level="high";reasons.push("חלון השלמה פתוח");}
 else if(state===DealState.Charging){level="medium";reasons.push("חיובים מתבצעים");}
 else if(state===DealState.PendingTarget&&within24(deal.deadline)&&current<threshold){level="high";reasons.push("פחות מ-24 שעות לדדליין ועדיין חסרות יחידות לסף");}
 else if(state===DealState.TargetReached&&within24(deal.deadline)){level="medium";reasons.push("פחות מ-24 שעות לדדליין");}
 if(Array.isArray(deal.pending_join_intents)&&deal.pending_join_intents.length){if(level==="low")level="medium";reasons.push("יש Join intents בהמתנה");}
 return{risk_level:level,risk_reasons:reasons};}
function countStates(deals:any[]){const out:Record<string,number>={};for(const deal of deals){const s=String(deal.state||"unknown");out[s]=(out[s]||0)+1;}return out;}

Deno.serve(async(req)=>{
 if(req.method!=="POST")return fail(405,"method_not_allowed", ErrorCode.ForbiddenAction);
 const base44=createClientFromRequest(req);let user:any;try{user=await base44.auth.me();}catch{return fail(401,"authentication required",ErrorCode.ForbiddenAction);}
 if(!user?.id)return fail(401,"authentication required", ErrorCode.ForbiddenAction);
 let body:any;try{body=await req.json();}catch{body={};}
 const period=PERIODS.has(String(body?.period||"all"))?String(body?.period||"all"):"all";const since=cutoff(period);const admin=base44.asServiceRole;
 const seller=(await admin.entities.SellerAccount.filter({owner_user_id:String(user.id)},"-created_date",1))?.[0];if(!seller)return fail(404,"seller account not found", ErrorCode.InvalidInput);
 let deals=await admin.entities.Deal.filter({owner_user_id:String(user.id)},"-created_date",1000).catch(()=>[]);
 if(since!==null)deals=(deals||[]).filter((deal:any)=>{const t=Date.parse(String(deal.created_date||deal.published_at||""));return Number.isFinite(t)&&t>=since;});
 const dealIds=new Set((deals||[]).map((deal:any)=>String(deal.deal_id||"")));
 const [deliveries,attributions,cases]=await Promise.all([
   admin.entities.DeliveryRecord.filter({deal_owner_user_id:String(user.id)},"-created_at",5000).catch(()=>[]),
   admin.entities.DistributionAttribution.list("-attributed_at",5000).catch(()=>[]),
   admin.entities.OperationalCase.filter({seller_id:String(seller.seller_id)},"-opened_at",1000).catch(()=>[])
 ]);
 const relevantAttributions=(attributions||[]).filter((row:any)=>dealIds.has(String(row.deal_id||"")));
 const sourceUnits:Record<string,number>={};for(const row of relevantAttributions){const code=String(row.source_code||"unknown");sourceUnits[code]=(sourceUnits[code]||0)+Number(row.qty||0);}
 const relevantDeliveries=(deliveries||[]).filter((row:any)=>dealIds.has(String(row.deal_id||"")));
 const relevantCases=(cases||[]).filter((row:any)=>!row.deal_id||dealIds.has(String(row.deal_id)));
 const allReservations=(deals||[]).flatMap((deal:any)=>Array.isArray(deal.join_reservations)?deal.join_reservations.map((row:any)=>({...row,deal_id:deal.deal_id})):[]);
 const successful=allReservations.filter((row:any)=>[MoneyState.ChargedSuccess,MoneyState.RecoveredCharge].includes(String(row.money_state||"")));
 const failed=allReservations.filter((row:any)=>[MoneyState.ChargeFailedRecovery,MoneyState.AuthReleased,MoneyState.Refunded].includes(String(row.money_state||""))||[BuyerState.Dropped,BuyerState.DealFailed].includes(String(row.buyer_state||"")));
 const compact=(deals||[]).map((deal:any)=>{const current=units(deal);const threshold=Math.max(1,Number(deal.threshold_units||1));return{deal_id:deal.deal_id,title:String(deal.title||""),deal_type:String(deal.deal_type||"physical_product"),state:String(deal.state||""),deadline:deal.deadline||null,current_units:current,threshold_units:Number(deal.threshold_units||0),max_units:Number(deal.max_units||0),progress_to_threshold_percent:Math.min(100,Math.round((current/threshold)*100)),pending_join_intents:Array.isArray(deal.pending_join_intents)?deal.pending_join_intents.length:0,...risk(deal)};});
 const weak=compact.filter((row:any)=>row.risk_level==="high"||row.risk_level==="failed"||(ACTIVE.has(row.state)&&row.current_units<row.threshold_units)).slice(0,8);
 const active=compact.filter((row:any)=>ACTIVE.has(row.state));
 const openCases=relevantCases.filter((row:any)=>!["Resolved","Closed"].includes(String(row.status||"")));
 return Response.json({ok:true,period,financial_metrics_enabled:false,financial_metrics_blocker:"authoritative VAT and proven financial snapshot are not connected",seller:{seller_id:seller.seller_id,display_name:seller.display_name,business_name:seller.business_name,seller_status:seller.seller_status,verification_status:seller.verification_status},summary:{total_deals:compact.length,active_deals:active.length,completed_deals:compact.filter((row:any)=>row.state===DealState.Completed).length,failed_deals:compact.filter((row:any)=>row.state===DealState.Failed).length,total_joined_units:allReservations.reduce((sum:number,row:any)=>sum+Number(row.qty||0),0),successful_units:successful.reduce((sum:number,row:any)=>sum+Number(row.qty||0),0),failed_or_dropped_units:failed.reduce((sum:number,row:any)=>sum+Number(row.qty||0),0),open_support_cases:openCases.length,delivery_records:relevantDeliveries.length,delivery_issues:relevantDeliveries.filter((row:any)=>row.status==="issue").length,distribution_attributions:relevantAttributions.length,distribution_units:relevantAttributions.reduce((sum:number,row:any)=>sum+Number(row.qty||0),0)},states:countStates(deals||[]),source_units:sourceUnits,delivery_statuses:countStates(relevantDeliveries.map((row:any)=>({state:row.status}))),weak_deals:weak,deals:compact.slice(0,200)});
});
