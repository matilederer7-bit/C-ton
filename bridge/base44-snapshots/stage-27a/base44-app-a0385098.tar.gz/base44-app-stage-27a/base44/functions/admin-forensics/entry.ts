import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}

const SENSITIVE_KEY = /(authorization|tracking.*hash|secret|password|card|payment_method|buyer_phone|buyer_email|delivery_address|destination_hash|proof_token)/i;
function scrub(value: any, depth = 0): any {
  if (depth > 4) return "[truncated]";
  if (Array.isArray(value)) return value.slice(0, 50).map((item) => scrub(item, depth + 1));
  if (value === null || typeof value !== "object") return value;
  const out: Record<string, unknown> = {};
  for (const [key, item] of Object.entries(value)) {
    if (SENSITIVE_KEY.test(key)) { out[key] = "[redacted]"; continue; }
    out[key] = scrub(item, depth + 1);
  }
  return out;
}

function text(value: unknown, max = 200) { return String(value ?? "").trim().slice(0, max); }
function matches(row: any, q: string, fields: string[]) {
  if (!q) return true;
  const needle = q.toLowerCase();
  return fields.some((field) => String(row?.[field] ?? "").toLowerCase().includes(needle));
}
async function safeList(entity: any, sort: string, limit = 1000) {
  try { return await entity.list(sort, limit); } catch { return []; }
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (String(user?.role || "") !== "admin") return fail(403, "admin required", ErrorCode.ForbiddenAction);
  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const q = text(body?.q, 200);
  const admin = base44.asServiceRole;

  const [deals, participants, outbox, payments, cases, deliveries, attributions] = await Promise.all([
    safeList(admin.entities.Deal, "-created_date", 1000),
    safeList(admin.entities.Participant, "-created_date", 2000),
    safeList(admin.entities.OutboxEvent, "-created_at", 2000),
    safeList(admin.entities.PaymentAttempt, "-created_date", 2000),
    safeList(admin.entities.OperationalCase, "-opened_at", 1000),
    safeList(admin.entities.DeliveryRecord, "-created_at", 2000),
    safeList(admin.entities.DistributionAttribution, "-attributed_at", 2000)
  ]);

  const dealRows = (deals || []).filter((row: any) => matches(row, q, ["deal_id","title","seller_id","seller_display_name","state"])).slice(0, 50).map((row: any) => ({
    deal_id: row.deal_id, title: row.title, seller_id: row.seller_id, state: row.state,
    min_units: Number(row.min_units || 0), max_units: Number(row.max_units || 0), threshold_units: Number(row.threshold_units || 0), reserved_units: Number(row.reserved_units || 0),
    inventory_sync_status: row.inventory_sync_status || null, inventory_reserved_units: Number(row.inventory_reserved_units || 0), inventory_committed_units: Number(row.inventory_committed_units || 0),
    pending_join_intents: Array.isArray(row.pending_join_intents) ? row.pending_join_intents.length : 0,
    completion_window_until: row.completion_window_until || null,
    transitions: (Array.isArray(row.transition_journal) ? row.transition_journal : []).slice(-20).map((event: any) => scrub({ state_type:event.state_type, from_state:event.from_state, to_state:event.to_state, action_name:event.action_name, request_id:event.request_id, idempotency_key:event.idempotency_key, created_at:event.created_at, payload:event.payload }))
  }));

  const participantRows = (participants || []).filter((row: any) => matches(row, q, ["participant_id","deal_id","buyer_id","buyer_state","money_state","affiliate_ref"])).slice(0, 100).map((row: any) => ({
    participant_id: row.participant_id, deal_id: row.deal_id, buyer_id: row.buyer_id ? "[redacted]" : null,
    qty: Number(row.qty || 0), buyer_state: row.buyer_state, money_state: row.money_state, affiliate_ref: row.affiliate_ref || null,
    delivery_method_type: row.delivery_method_type || null, hold_total: Number(row.hold_total || 0), created_date: row.created_date || null
  }));

  const outboxRows = (outbox || []).filter((row: any) => matches(row, q, ["event_uuid","event_type","aggregate_id","status","correlation_id","request_id"])).slice(0, 100).map((row: any) => ({
    event_uuid: row.event_uuid, event_type: row.event_type, aggregate_id: row.aggregate_id, status: row.status,
    attempt_count: Number(row.attempt_count || 0), max_attempts: Number(row.max_attempts || 0), available_at: row.available_at || null, processing_started_at: row.processing_started_at || null,
    last_error: row.last_error || null, correlation_id: row.correlation_id || null, request_id: row.request_id || null
  }));

  const paymentRows = (payments || []).filter((row: any) => matches(row, q, ["attempt_id","deal_id","participant_id","attempt_type","result_class","error_code","correlation_id"])).slice(0, 100).map((row: any) => ({
    attempt_id: row.attempt_id, deal_id: row.deal_id, participant_id: row.participant_id, attempt_type: row.attempt_type,
    result_class: row.result_class, error_code: row.error_code || null, started_at: row.started_at || null, completed_at: row.completed_at || null, correlation_id: row.correlation_id || null
  }));

  const caseRows = (cases || []).filter((row: any) => matches(row, q, ["case_id","subject","case_type","priority","status","deal_id","participant_id","seller_id","correlation_id"])).slice(0, 100).map((row: any) => ({
    case_id: row.case_id, subject: row.subject, case_type: row.case_type, priority: row.priority, status: row.status,
    deal_id: row.deal_id || null, participant_id: row.participant_id || null, seller_id: row.seller_id || null, opened_at: row.opened_at || null, resolution_note: row.resolution_note || null
  }));

  const deliveryRows = (deliveries || []).filter((row: any) => matches(row, q, ["delivery_id","deal_id","participant_id","seller_id","status","carrier","tracking_number"])).slice(0, 100).map((row: any) => ({
    delivery_id: row.delivery_id, deal_id: row.deal_id, participant_id: row.participant_id, status: row.status, qty: Number(row.qty || 0),
    money_state_at_eligibility: row.money_state_at_eligibility, carrier: row.carrier || null, tracking_number: row.tracking_number || null, created_at: row.created_at || null
  }));

  const attributionRows = (attributions || []).filter((row: any) => matches(row, q, ["attribution_id","source_code","deal_id","participant_id"])).slice(0, 100).map((row: any) => ({
    attribution_id: row.attribution_id, source_code: row.source_code, deal_id: row.deal_id, participant_id: row.participant_id, qty: Number(row.qty || 0), attributed_at: row.attributed_at
  }));

  const now = Date.now();
  const staleOutbox = outboxRows.filter((row: any) => row.status === "processing" && row.processing_started_at && now - Date.parse(row.processing_started_at) > 60_000).length;
  const deadOrFailed = outboxRows.filter((row: any) => ["failed","dead_letter"].includes(String(row.status))).length;
  const pendingIntents = dealRows.reduce((sum: number, row: any) => sum + Number(row.pending_join_intents || 0), 0);
  const anomalies = [
    ...(pendingIntents ? [{ severity:"warning", domain:"join", title:"Pending Join intents", count:pendingIntents }] : []),
    ...(staleOutbox ? [{ severity:"warning", domain:"worker", title:"Stale processing events", count:staleOutbox }] : []),
    ...(deadOrFailed ? [{ severity:"critical", domain:"worker", title:"Failed or dead-letter events", count:deadOrFailed }] : [])
  ];

  return Response.json({
    ok: true,
    q,
    generated_at: new Date().toISOString(),
    counts: { deals:dealRows.length, participants:participantRows.length, outbox:outboxRows.length, payment_attempts:paymentRows.length, support_cases:caseRows.length, deliveries:deliveryRows.length, attributions:attributionRows.length },
    anomalies,
    verdict: anomalies.some((row) => row.severity === "critical") ? "red" : anomalies.length ? "yellow" : "green",
    deals:dealRows,
    participants:participantRows,
    outbox:outboxRows,
    payment_attempts:paymentRows,
    support_cases:caseRows,
    deliveries:deliveryRows,
    attributions:attributionRows,
    redacted_fields:["buyer_id","authorization references","tracking hashes","secrets","payment method identifiers","delivery address"]
  });
});
