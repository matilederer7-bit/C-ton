import { BuyerState, DealState, ErrorCode, MoneyState } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status: number, message: string, code?: string) {
  return Response.json({ ok: false, error: message, ...(code ? { code } : {}) }, { status });
}

const SAFE_FIELDS = [
  "deal_id","seller_id","seller_display_name","state","deal_type","title","short_description","price_per_unit",
  "min_units","max_units","threshold_units","reserved_units","deadline","published_at","completion_window_until",
  "primary_image_url","final_units","pending_units","failed_units","volume_amount","failure_reason","created_date","updated_date"
];

function qty(rows: any[], predicate: (row: any) => boolean) {
  return rows.reduce((sum, row) => predicate(row) ? sum + Math.max(0, Number(row?.qty || 0)) : sum, 0);
}

function safeProjection(deal: any) {
  const reservations = Array.isArray(deal?.join_reservations) ? deal.join_reservations : [];
  const finalUnits = qty(reservations, (row) => [MoneyState.ChargedSuccess,MoneyState.RecoveredCharge].includes(String(row?.money_state || "")));
  const pendingUnits = qty(reservations, (row) => String(row?.buyer_state || "") === BuyerState.ChargeFailedCompletion || String(row?.money_state || "") === MoneyState.ChargeFailedRecovery);
  const totalUnits = qty(reservations, () => true);
  const authorizedVolume = reservations.reduce((sum:any,row:any) => sum + Math.max(0, Number(row?.hold_total || 0)), 0);
  const ledger = Array.isArray(deal?.money_ledger_events) ? deal.money_ledger_events : [];
  const ledgerGross = ledger.reduce((sum:number,row:any) => sum + Number(row?.gross_amount || 0), 0);
  const volumeAmount = String(deal?.state || "") === DealState.Completed ? Math.max(0, ledgerGross) : authorizedVolume;
  const failureReason = String(deal?.state || "") === DealState.Failed
    ? (finalUnits < Number(deal?.threshold_units || 0) ? "חיובים סופיים מתחת לסף ההצלחה" : "העסקה נכשלה")
    : null;
  const images = Array.isArray(deal?.images) ? deal.images.slice().sort((a: any,b: any) => Number(a?.sort_order || 0) - Number(b?.sort_order || 0)) : [];
  return {
    deal_id: String(deal?.deal_id || ""), seller_id: String(deal?.seller_id || ""), seller_display_name: String(deal?.seller_display_name || ""),
    state: String(deal?.state || ""), deal_type: String(deal?.deal_type || "physical_product"), title: String(deal?.title || ""),
    short_description: String(deal?.short_description || ""), price_per_unit: Number(deal?.price_per_unit || 0), min_units: Number(deal?.min_units || 0),
    max_units: Number(deal?.max_units || 0), threshold_units: Number(deal?.threshold_units || 0), reserved_units: Number(deal?.reserved_units || 0),
    deadline: deal?.deadline || null, published_at: deal?.published_at || null, completion_window_until: deal?.completion_window_until || null,
    primary_image_url: images?.[0]?.file_url ? String(images[0].file_url) : null,
    final_units: finalUnits, pending_units: pendingUnits, failed_units: Math.max(0, totalUnits - finalUnits - pendingUnits),
    volume_amount: Number(volumeAmount || 0), failure_reason: failureReason,
    created_date: deal?.created_date || null, updated_date: deal?.updated_date || null
  };
}

Deno.serve(async (req) => {
  if (req.method !== "GET" && req.method !== "POST") {
    return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  }

  const base44 = createClientFromRequest(req);
  let user: any;
  try {
    user = await base44.auth.me();
  } catch {
    return fail(401, "authentication required", ErrorCode.ForbiddenAction);
  }

  const ownerUserId = String(user?.id || "");
  if (!ownerUserId) return fail(401, "authentication required", ErrorCode.ForbiddenAction);

  const rows = await base44.asServiceRole.entities.Deal.filter(
    { owner_user_id: ownerUserId },
    "-created_date",
    200
  );
  const deals = Array.isArray(rows) ? rows.map(safeProjection) : [];

  return Response.json({
    ok: true,
    deals,
    fields: SAFE_FIELDS,
    sensitive_fields_excluded: [
      "owner_user_id",
      "join_reservations",
      "join_idempotency_keys",
      "transition_journal",
      "pending_events",
      "outbox_events",
      "legal_acceptances",
      "last_transition_key"
    ]
  });
});
