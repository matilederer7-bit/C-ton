import { DealState, ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function responseError(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return responseError(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let body: any;
  try { body = await req.json(); } catch { return responseError(400, "invalid JSON body", ErrorCode.InvalidInput); }

  const dealId = String(body?.deal_id || "").trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(dealId)) {
    return responseError(400, "deal_id must be a valid UUID", ErrorCode.InvalidInput);
  }

  const rows = await base44.asServiceRole.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1);
  const deal = rows?.[0];
  if (!deal) return responseError(404, "deal not found", ErrorCode.InvalidInput);
  const seller = (await base44.asServiceRole.entities.SellerAccount.filter({ seller_id: String(deal.seller_id || "") }, "-created_date", 1).catch(() => []))?.[0];

  const state = String(deal.state || "");
  const publicStates = [DealState.PendingTarget, DealState.TargetReached, DealState.ClosedForJoining, DealState.ReadyForCharging, DealState.Charging, DealState.CompletionWindow, DealState.Completed];
  if (!publicStates.includes(state)) return responseError(404, "deal not found", ErrorCode.InvalidInput);

  const maxUnits = Math.max(0, Number(deal.max_units || 0));
  const reservedUnits = Math.max(0, Number(deal.reserved_units || 0));
  const thresholdUnits = Math.max(0, Number(deal.threshold_units || 0));
  const reservations = Array.isArray(deal.join_reservations) ? deal.join_reservations : [];
  const participantCount = new Set(reservations.map((row: any) => String(row?.buyer_id || "").trim()).filter(Boolean)).size;
  const purchaseCount = reservations.length;
  const joinOpen = [DealState.PendingTarget, DealState.TargetReached].includes(state) && Date.parse(String(deal.deadline || "")) > Date.now() && reservedUnits < maxUnits;

  return Response.json({
    ok: true,
    deal: {
      deal_id: String(deal.deal_id),
      title: String(deal.title || ""),
      deal_type: String(deal.deal_type || "physical_product"),
      state,
      seller_display_name: String(deal.seller_display_name || ""),
      short_description: String(deal.short_description || ""),
      what_you_get: String(deal.what_you_get || ""),
      seller_contact: seller ? {
        business_name: String(seller.business_name || seller.display_name || deal.seller_display_name || ""),
        support_phone: String(seller.support_phone || ""),
        support_email: String(seller.support_email || "")
      } : null,
      price_per_unit: Number(deal.price_per_unit || 0),
      min_units: Number(deal.min_units || 0),
      max_units: maxUnits,
      threshold_units: thresholdUnits,
      reserved_units: reservedUnits,
      remaining_units: Math.max(0, maxUnits - reservedUnits),
      remaining_to_minimum: Math.max(0, Number(deal.min_units || 0) - reservedUnits),
      progress_percent: Math.min(100, Math.round((reservedUnits / Math.max(1, Number(deal.min_units || 0))) * 100)),
      deadline: deal.deadline || null,
      published_at: deal.published_at || null,
      updated_at: deal.updated_date || deal.updated_at || null,
      participant_count: participantCount,
      purchase_count: purchaseCount,
      join_open: joinOpen,
      images: Array.isArray(deal.images)
        ? deal.images
            .slice()
            .sort((a: any, b: any) => Number(a?.sort_order || 0) - Number(b?.sort_order || 0))
            .map((image: any) => ({
              image_id: String(image?.image_id || ""),
              file_url: String(image?.file_url || ""),
              sort_order: Number(image?.sort_order || 0)
            }))
            .filter((image: any) => image.image_id && image.file_url)
        : [],
      delivery_options: Array.isArray(deal.delivery_options)
        ? deal.delivery_options.map((option: any) => ({
            option_id: String(option?.option_id || ""),
            option_type: String(option?.option_type || "pickup"),
            label: String(option?.label || ""),
            cost: Math.max(0, Number(option?.cost || 0)),
            sort_order: Number(option?.sort_order || 0)
          }))
        : [],
      voucher_terms: deal.deal_type === "voucher" && deal.voucher_terms
        ? {
            face_value_amount: Number(deal.voucher_terms.face_value_amount || 0),
            currency: String(deal.voucher_terms.currency || "ILS"),
            valid_from: deal.voucher_terms.valid_from || null,
            valid_until: deal.voucher_terms.valid_until || null,
            redemption_location: String(deal.voucher_terms.redemption_location || ""),
            redemption_instructions: String(deal.voucher_terms.redemption_instructions || ""),
            terms: String(deal.voucher_terms.terms || ""),
            is_single_use: deal.voucher_terms.is_single_use !== false,
            allow_partial_redemption: deal.voucher_terms.allow_partial_redemption === true
          }
        : null,
      ticket_terms: deal.deal_type === "ticket" && deal.ticket_terms
        ? {
            event_name: String(deal.ticket_terms.event_name || ""),
            event_starts_at: deal.ticket_terms.event_starts_at || null,
            event_ends_at: deal.ticket_terms.event_ends_at || null,
            venue_name: String(deal.ticket_terms.venue_name || ""),
            venue_address: String(deal.ticket_terms.venue_address || ""),
            venue_city: String(deal.ticket_terms.venue_city || ""),
            entry_instructions: String(deal.ticket_terms.entry_instructions || ""),
            ticket_type: String(deal.ticket_terms.ticket_type || "general_admission")
          }
        : null
    }
  });
});
