import { BuyerState, DealState, ErrorCode, MoneyState } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";
import { enqueueBuyerNotifications } from "../../shared/notifications.ts";
import { assertCriticalTermsIntegrity } from "../../shared/deal-integrity.ts";

const PAYMENT_DISCLOSURE_VERSION = "2026-04-26";
const TRACKING_TOKEN_TTL_MS = 30 * 24 * 60 * 60_000;
const encoder = new TextEncoder();

function err(status: number, message: string, code?: string) {
  return Response.json({ ok: false, error: message, ...(code ? { code } : {}) }, { status });
}

function accepted(value: unknown) {
  return value === true || value === "true" || value === "on" || value === "1";
}

function parseQty(value: unknown) {
  const n = Number(value ?? 1);
  if (!Number.isInteger(n) || n <= 0 || n > 1000) {
    throw Object.assign(new Error("qty must be an integer between 1 and 1000"), { status: 400, code: ErrorCode.InvalidInput });
  }
  return n;
}

function normalizeDestination(channel: string, destination: string) {
  const raw = String(destination || "").trim();
  return channel === "sms" ? raw.replace(/\D/g, "") : raw.toLowerCase();
}

function bytesToHex(bytes: ArrayBuffer) {
  return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function sha256Hex(value: string) {
  return bytesToHex(await crypto.subtle.digest("SHA-256", encoder.encode(value)));
}

async function hmacHex(secret: string, value: string) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return bytesToHex(await crypto.subtle.sign("HMAC", key, encoder.encode(value)));
}

function stable(value: any): any {
  if (Array.isArray(value)) return value.map(stable);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, stable(value[key])]));
}

async function requestHash(value: any) {
  return sha256Hex(JSON.stringify(stable(value)));
}

async function controlEventValid(row: any) {
  if (!row?.signature) return false;
  const secret = String(Deno.env.get("ADMIN_CONTROL_INTEGRITY_SECRET") || "");
  if (secret.length < 32) throw Object.assign(new Error("admin control integrity secret unavailable"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
  const canonical = {
    event_id: String(row.event_id), flag_id: String(row.flag_id), event_type: String(row.event_type), flag_type: String(row.flag_type),
    scope_type: String(row.scope_type), scope_id: row.scope_id ? String(row.scope_id) : null,
    requested_by_user_id: String(row.requested_by_user_id), approved_by_user_id: String(row.approved_by_user_id),
    created_at: String(row.created_at), expires_at: row.expires_at ? String(row.expires_at) : null, reason: row.reason ? String(row.reason) : null,
    activation_event_id: row.activation_event_id ? String(row.activation_event_id) : null,
    activation_signature: row.activation_signature ? String(row.activation_signature) : null,
    signature_version: String(row.signature_version || "hmac-sha256-v1")
  };
  return (await hmacHex(secret, JSON.stringify(stable(canonical)))) === String(row.signature);
}
function controlScopeMatches(event: any, deal: any) {
  const scope = String(event.scope_type || "global");
  const id = String(event.scope_id || "");
  return scope === "global" || (scope === "deal" && id === String(deal.deal_id)) || (scope === "seller" && id === String(deal.seller_id || ""));
}
async function activeEmergencyPause(base44: any, flagType: string, deal: any) {
  const events = await base44.asServiceRole.entities.AdminControlAudit.filter({ flag_type: flagType }, "-created_at", 1000).catch(() => []);
  for (const activation of events || []) {
    if (String(activation.event_type) !== "activation_approved") continue;
    if (String(activation.requested_by_user_id) === String(activation.approved_by_user_id)) continue;
    if (!controlScopeMatches(activation, deal)) continue;
    const expiry = Date.parse(String(activation.expires_at || ""));
    if (!Number.isFinite(expiry) || expiry <= Date.now()) continue;
    if (!(await controlEventValid(activation))) continue;
    let released = false;
    for (const release of events || []) {
      if (String(release.event_type) !== "release_approved" || String(release.flag_id) !== String(activation.flag_id)) continue;
      if (String(release.requested_by_user_id) === String(release.approved_by_user_id)) continue;
      if (String(release.activation_event_id || "") !== String(activation.event_id)) continue;
      if (String(release.activation_signature || "") !== String(activation.signature)) continue;
      if (await controlEventValid(release)) { released = true; break; }
    }
    if (!released) return activation;
  }
  return null;
}

function challengeIdFromToken(token: string) {
  const parts = String(token || "").split(".");
  return parts.length === 3 && parts[0] === "v1" ? parts[1] : "";
}

async function verifyOtpProof(base44: any, body: any, dealId: string, buyerId: string) {
  const token = String(body.otp_token || "").trim();
  if (!token) throw Object.assign(new Error("otp_token is required for a new join"), { status: 400, code: ErrorCode.InvalidInput });
  const challengeId = challengeIdFromToken(token);
  if (!challengeId) throw Object.assign(new Error("invalid otp_token"), { status: 400, code: ErrorCode.InvalidInput });

  const rows = await base44.asServiceRole.entities.OtpChallenge.filter({ challenge_id: challengeId }, "-created_date", 1);
  const challenge = rows?.[0];
  if (!challenge) throw Object.assign(new Error("challenge not found"), { status: 400, code: ErrorCode.InvalidInput });
  if (String(challenge.purpose) !== "buyer_join" || String(challenge.status) !== "consumed") {
    throw Object.assign(new Error("challenge not verified for buyer_join"), { status: 400, code: ErrorCode.InvalidInput });
  }
  if (!challenge.proof_expires_at || Date.parse(String(challenge.proof_expires_at)) <= Date.now()) {
    throw Object.assign(new Error("verification expired"), { status: 400, code: ErrorCode.NotInWindow });
  }
  if (challenge.deal_id && String(challenge.deal_id) !== dealId) {
    throw Object.assign(new Error("challenge bound to a different deal"), { status: 400, code: ErrorCode.InvalidInput });
  }
  const tokenHash = await sha256Hex(`otp-proof:${token}`);
  if (tokenHash !== String(challenge.proof_token_hash || "")) {
    throw Object.assign(new Error("otp proof does not match challenge"), { status: 400, code: ErrorCode.InvalidInput });
  }
  const expectedDestinationHash = await sha256Hex(`${challenge.channel}:${normalizeDestination(String(challenge.channel), buyerId)}`);
  if (expectedDestinationHash !== String(challenge.destination_hash || "")) {
    throw Object.assign(new Error("destination does not match verified challenge"), { status: 400, code: ErrorCode.InvalidInput });
  }
  return { challenge_id: challengeId, channel: String(challenge.channel), destination_hash: String(challenge.destination_hash) };
}

function chooseDelivery(deal: any, deliveryOptionId: string) {
  const options = Array.isArray(deal.delivery_options) ? [...deal.delivery_options] : [];
  options.sort((a, b) => Number(a?.sort_order || 0) - Number(b?.sort_order || 0));
  if (deliveryOptionId) return options.find((option) => String(option?.option_id || "") === deliveryOptionId) || null;
  return options[0] || null;
}

function replayFromDeal(deal: any, key: string) {
  const reservations = Array.isArray(deal?.join_reservations) ? deal.join_reservations : [];
  return reservations.find((reservation: any) => String(reservation?.idempotency_key || "") === key) || null;
}

function pendingIntentFromDeal(deal: any, key: string) {
  const intents = Array.isArray(deal?.pending_join_intents) ? deal.pending_join_intents : [];
  return intents.find((intent: any) => String(intent?.idempotency_key || "") === key) || null;
}

async function inventory(base44: any, operation: string, payload: any) {
  const raw = await base44.asServiceRole.functions.invoke("inventory-bridge", { operation, ...payload });
  const body = raw?.data || raw;
  if (!body?.ok || !body?.result) {
    throw Object.assign(new Error(String(body?.error || `inventory ${operation} failed`)), { status: 503, code: String(body?.code || `inventory_${operation}_failed`) });
  }
  return body.result;
}

async function buildProjection(intent: any, status: any, trackingSecret: string) {
  const participantId = String(status.reservation_id);
  const joinedAt = String(status.committed_at || status.created_at || new Date().toISOString());
  const trackingSignature = await hmacHex(trackingSecret, `tracking:v2:${participantId}:${intent.request_hash}`);
  const trackingToken = `trk.v2.${participantId}.${trackingSignature}`;
  const trackingTokenHash = await sha256Hex(`tracking:${trackingToken}`);
  const trackingExpiresAt = new Date(Date.parse(joinedAt) + TRACKING_TOKEN_TTL_MS).toISOString();
  const authorizationEvidence = intent.authorization_evidence || {};

  const response = {
    ok: true,
    participant_id: participantId,
    tracking_access_token: trackingToken,
    tracking_url: `/app/track/${encodeURIComponent(participantId)}?t=${encodeURIComponent(trackingToken)}`,
    delivery_option_id: intent.delivery_option_id || null,
    delivery_method_type: intent.delivery_method_type || null,
    delivery_method_label: intent.delivery_method_label || null,
    delivery_cost: Number(intent.delivery_cost || 0),
    hold_total: Number(intent.hold_total || 0),
    replay: false
  };

  const buyerTransition = { state_type: "buyer_state", from_state: BuyerState.NotJoined, to_state: BuyerState.JoinedAuthorized, action_name: "participant.join_authorize", request_id: intent.request_id, idempotency_key: intent.idempotency_key, created_at: joinedAt, payload: authorizationEvidence };
  const moneyTransition = { state_type: "money_state", from_state: MoneyState.NoFinancial, to_state: MoneyState.AuthHeld, action_name: "participant.join_authorize", request_id: intent.request_id, idempotency_key: intent.idempotency_key, created_at: joinedAt, payload: authorizationEvidence };
  const legalAcceptance = { acceptance_type: "buyer_payment_disclosure", actor_type: "buyer", actor_ref: intent.buyer_id, policy_version: PAYMENT_DISCLOSURE_VERSION, accepted_at: joinedAt, metadata: { no_charge_before_successful_close: true } };

  const reservation = {
    reservation_id: participantId,
    participant_id: participantId,
    buyer_id: intent.buyer_id,
    qty: Number(intent.qty),
    buyer_state: BuyerState.JoinedAuthorized,
    money_state: MoneyState.AuthHeld,
    delivery_option_id: intent.delivery_option_id || null,
    delivery_method_type: intent.delivery_method_type || null,
    delivery_method_label: intent.delivery_method_label || null,
    delivery_cost: Number(intent.delivery_cost || 0),
    buyer_name: intent.buyer_name || null,
    buyer_phone: intent.buyer_id,
    buyer_email: intent.buyer_email || null,
    delivery_address: intent.delivery_address || null,
    delivery_city: intent.delivery_city || null,
    delivery_notes: intent.delivery_notes || null,
    affiliate_ref: intent.affiliate_ref || null,
    authorization_id: intent.authorization_id || null,
    authorization_provider: intent.authorization_provider || null,
    authorization_correlation_id: intent.authorization_correlation_id || null,
    authorization_evidence: authorizationEvidence,
    hold_total: Number(intent.hold_total || 0),
    idempotency_key: intent.idempotency_key,
    request_hash: intent.request_hash,
    tracking_token_hash: trackingTokenHash,
    tracking_token_expires_at: trackingExpiresAt,
    transition_journal: [buyerTransition, moneyTransition],
    legal_acceptances: [legalAcceptance],
    response,
    joined_at: joinedAt
  };
  return { participantId, joinedAt, trackingToken, trackingTokenHash, trackingExpiresAt, buyerTransition, moneyTransition, legalAcceptance, reservation, response };
}

async function ensureParticipantFromReservation(admin: any, deal: any, reservation: any) {
  const participantId = String(reservation?.participant_id || "");
  if (!participantId) return;
  const existing = await admin.entities.Participant.filter({ participant_id: participantId }, "-created_date", 1).catch(() => []);
  if (existing?.[0]) return;
  await admin.entities.Participant.create({
    participant_id: participantId,
    reservation_id: String(reservation.reservation_id || participantId),
    deal_id: String(deal.deal_id),
    deal_owner_user_id: String(deal.owner_user_id || ""),
    buyer_id: String(reservation.buyer_id || ""),
    qty: Number(reservation.qty || 0),
    buyer_state: String(reservation.buyer_state || BuyerState.JoinedAuthorized),
    money_state: String(reservation.money_state || MoneyState.AuthHeld),
    delivery_option_id: reservation.delivery_option_id || null,
    delivery_method_type: reservation.delivery_method_type || null,
    delivery_method_label: reservation.delivery_method_label || null,
    delivery_cost: Number(reservation.delivery_cost || 0),
    buyer_name: reservation.buyer_name || null,
    buyer_phone: reservation.buyer_phone || reservation.buyer_id || null,
    buyer_email: reservation.buyer_email || null,
    delivery_address: reservation.delivery_address || null,
    delivery_city: reservation.delivery_city || null,
    delivery_notes: reservation.delivery_notes || null,
    affiliate_ref: reservation.affiliate_ref || null,
    authorization_id: reservation.authorization_id || null,
    authorization_provider: reservation.authorization_provider || null,
    authorization_correlation_id: reservation.authorization_correlation_id || null,
    authorization_evidence: reservation.authorization_evidence || {},
    hold_total: Number(reservation.hold_total || 0),
    idempotency_key: String(reservation.idempotency_key || ""),
    request_hash: String(reservation.request_hash || ""),
    tracking_token_hash: reservation.tracking_token_hash || null,
    tracking_token_expires_at: reservation.tracking_token_expires_at || null,
    payment_retry_attempt_count: 0,
    payment_retry_slot_keys: [],
    transition_journal: Array.isArray(reservation.transition_journal) ? reservation.transition_journal : [],
    legal_acceptances: Array.isArray(reservation.legal_acceptances) ? reservation.legal_acceptances : []
  }).catch(() => undefined);
  const verified = await admin.entities.Participant.filter({ participant_id: participantId }, "-created_date", 1).catch(() => []);
  if (!verified?.[0]) throw Object.assign(new Error("participant projection could not be created"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
}

async function ensureJoinIdempotency(admin: any, deal: any, reservation: any) {
  const participantId = String(reservation?.participant_id || "");
  const key = String(reservation?.idempotency_key || "");
  if (!participantId || !key) return;
  const rows = await admin.entities.IdempotencyRecord.filter({ entity_id: participantId, action_name: "participant.join_authorize", idempotency_key: key }, "-created_date", 1).catch(() => []);
  if (rows?.[0]) return;
  await admin.entities.IdempotencyRecord.create({
    owner_user_id: String(deal.owner_user_id || ""),
    entity_type: "participant",
    entity_id: participantId,
    action_name: "participant.join_authorize",
    idempotency_key: key,
    request_hash: String(reservation.request_hash || ""),
    response_json: reservation.response || {}
  }).catch(() => undefined);
  const verified = await admin.entities.IdempotencyRecord.filter({ entity_id: participantId, action_name: "participant.join_authorize", idempotency_key: key }, "-created_date", 1).catch(() => []);
  if (!verified?.[0]) throw Object.assign(new Error("join idempotency projection could not be created"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
}

async function ensureJoinAttribution(admin: any, dealId: string, reservation: any) {
  const sourceCode = String(reservation?.affiliate_ref || "").trim().toLowerCase();
  const participantId = String(reservation?.participant_id || "");
  if (!sourceCode || !participantId) return;
  const source = (await admin.entities.DistributionSource.filter({ source_code: sourceCode, active: true }, "-created_date", 1).catch(() => []))?.[0];
  if (!source) return;
  let sourceAllowed = true;
  if (String(source.source_type || "admin") === "distributor") {
    sourceAllowed = String(source.deal_id || "") === dealId && Boolean(source.distributor_access_id) && Boolean(source.owner_user_id);
    if (sourceAllowed) {
      const access = (await admin.entities.DistributorDealAccess.filter({ access_id: String(source.distributor_access_id), owner_user_id: String(source.owner_user_id), deal_id: dealId, status: "active" }, "-created_at", 1).catch(() => []))?.[0];
      sourceAllowed = Boolean(access);
    }
  }
  if (!sourceAllowed) return;
  const prior = await admin.entities.DistributionAttribution.filter({ participant_id: participantId, source_id: String(source.source_id) }, "-attributed_at", 1).catch(() => []);
  if (prior?.[0]) return;
  await admin.entities.DistributionAttribution.create({ attribution_id: crypto.randomUUID(), source_id: String(source.source_id), source_code: String(source.source_code), deal_id: dealId, participant_id: participantId, qty: Number(reservation.qty || 1), attributed_at: String(reservation.joined_at || new Date().toISOString()) }).catch(() => undefined);
}

async function finishJoinDerived(admin: any, deal: any, reservation: any, intent: any) {
  await ensureParticipantFromReservation(admin, deal, reservation);
  await ensureJoinAttribution(admin, String(deal.deal_id), reservation);
  await ensureJoinIdempotency(admin, deal, reservation);
  await enqueueBuyerNotifications(admin, deal, reservation, "buyer_joined", "buyer_joined_he", { deal_title: String(deal.title || ""), qty: Number(reservation.qty || 0), hold_total: Number(reservation.hold_total || 0) }, String(reservation.idempotency_key || ""));
  if (intent) {
    const key = String(reservation.idempotency_key || "");
    await admin.entities.Deal.updateMany(
      { deal_id: String(deal.deal_id), pending_join_keys: { $in: [key] } },
      { $pull: { pending_join_keys: key, pending_join_intents: intent } }
    );
    const verifiedDeal = (await admin.entities.Deal.filter({ deal_id: String(deal.deal_id) }, "-created_date", 1).catch(() => []))?.[0];
    const stillPending = Array.isArray(verifiedDeal?.pending_join_keys) && verifiedDeal.pending_join_keys.map(String).includes(key);
    if (stillPending) throw Object.assign(new Error("join derived projections exist but pending intent could not be cleared"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
  }
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return err(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  if (Deno.env.get("RESERVATION_SERVICE_ENFORCED") !== "true" || Deno.env.get("JOIN_EXTERNAL_RESERVATION_PROVEN") !== "true") {
    return err(503, "Join is disabled until the external reservation path is explicitly proven and enabled", ErrorCode.TemporarilyUnavailable);
  }
  const trackingSecret = String(Deno.env.get("TRACKING_TOKEN_SECRET") || "");
  if (trackingSecret.length < 32) return err(503, "tracking token secret is not configured", ErrorCode.TemporarilyUnavailable);

  const base44 = createClientFromRequest(req);
  let body: any;
  try { body = await req.json(); } catch { return err(400, "invalid JSON body", ErrorCode.InvalidInput); }

  const dealId = String(body.deal_id || "").trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(dealId)) return err(400, "deal_id must be a valid UUID", ErrorCode.InvalidInput);
  const buyerId = String(body.buyer_id || "").trim();
  if (!buyerId) return err(400, "buyer_id required", ErrorCode.InvalidInput);
  if (!accepted(body.payment_disclosure_accepted)) return err(400, "payment_disclosure_required", ErrorCode.InvalidInput);

  let qty: number;
  try { qty = parseQty(body.qty); } catch (e: any) { return err(Number(e.status || 400), e.message, e.code); }
  const buyerName = String(body.buyer_name || "").trim().slice(0, 160) || null;
  const buyerEmail = String(body.buyer_email || "").trim().slice(0, 254) || null;
  const deliveryOptionId = String(body.delivery_option_id || "").trim();
  const deliveryAddress = String(body.delivery_address || "").trim().slice(0, 500) || null;
  const deliveryCity = String(body.delivery_city || "").trim().slice(0, 160) || null;
  const deliveryNotes = String(body.delivery_notes || "").trim();
  if (deliveryNotes.length > 200) return err(400, "delivery_notes must be 200 characters or less", ErrorCode.InvalidInput);
  const affiliateRef = String(body.affiliate_ref || "").trim().slice(0, 120);
  const authorizationId = String(body.authorization_id || "").trim();
  const authorizationProvider = String(body.authorization_provider || "").trim();
  const authorizationCorrelationId = String(body.authorization_correlation_id || "").trim();
  const allowMigrationMock = Deno.env.get("MIGRATION_MOCK_AUTH_ENABLED") === "true";
  if (!authorizationId && !allowMigrationMock) return err(409, "authorization reference required before join", ErrorCode.IllegalStateTransition);

  const otpToken = String(body.otp_token || "").trim();
  const challengeId = challengeIdFromToken(otpToken) || String(body.otp_challenge_id || "").trim();
  if (!challengeId) return err(400, "otp_token or otp_challenge_id is required", ErrorCode.InvalidInput);
  const idempotencyKey = String(body.idempotency_key || `join:${dealId}:${buyerId}:${challengeId}`);
  const requestId = `join:${idempotencyKey}`;

  try {
    let deal = (await base44.asServiceRole.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1))?.[0];
    if (!deal) return err(404, "deal not found", ErrorCode.InvalidInput);
    await assertCriticalTermsIntegrity(deal);

    const selectedDelivery = chooseDelivery(deal, deliveryOptionId);
    if (deliveryOptionId && !selectedDelivery) return err(400, "invalid_delivery_option", ErrorCode.InvalidInput);
    if (selectedDelivery?.option_type === "delivery" && !deliveryAddress) return err(400, "delivery_address is required for delivery shipments", ErrorCode.InvalidInput);

    const normalizedRequest = {
      deal_id: dealId,
      buyer_id: buyerId,
      qty,
      authorization_id: authorizationId || null,
      authorization_provider: authorizationProvider || (allowMigrationMock ? "migration_mock" : null),
      authorization_correlation_id: authorizationCorrelationId || null,
      delivery_option_id: selectedDelivery?.option_id || null,
      buyer_name: buyerName,
      buyer_email: buyerEmail,
      delivery_address: deliveryAddress,
      delivery_city: deliveryCity,
      delivery_notes: deliveryNotes || null,
      affiliate_ref: affiliateRef || null,
      payment_disclosure_accepted: true,
      otp_challenge_id: challengeId
    };
    const joinRequestHash = await requestHash(normalizedRequest);

    const existing = replayFromDeal(deal, idempotencyKey);
    if (existing) {
      if (String(existing.request_hash || "") !== joinRequestHash) return err(409, "idempotency key was already used with a different Join payload", ErrorCode.IllegalStateTransition);
      const recoveryIntent = pendingIntentFromDeal(deal, idempotencyKey);
      if (recoveryIntent) await finishJoinDerived(base44.asServiceRole, deal, existing, recoveryIntent);
      return Response.json({ ...(existing.response || {}), replay: true });
    }

    let intent = pendingIntentFromDeal(deal, idempotencyKey);
    if (intent && String(intent.request_hash || "") !== joinRequestHash) {
      return err(409, "idempotency key is pending with a different Join payload", ErrorCode.IllegalStateTransition);
    }

    const emergencyPause = await activeEmergencyPause(base44, "pause_joining_emergency", deal);
    if (emergencyPause) {
      if (intent) {
        try { await base44.asServiceRole.functions.invoke("reconcile-join-intents", { deal_id: dealId }); } catch { /* fail closed below */ }
        deal = (await base44.asServiceRole.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1))?.[0];
        const recovered = replayFromDeal(deal, idempotencyKey);
        if (recovered) {
          if (String(recovered.request_hash || "") !== joinRequestHash) return err(409, "idempotency key was already used with a different Join payload", ErrorCode.IllegalStateTransition);
          return Response.json({ ...(recovered.response || {}), replay: true });
        }
      }
      return err(403, "joining is paused by two-admin emergency control", ErrorCode.ForbiddenAction);
    }

    if (!intent) {
      if (![DealState.PendingTarget, DealState.TargetReached].includes(String(deal.state || ""))) return err(409, "deal is not open for joining", ErrorCode.IllegalStateTransition);
      if (!deal.deadline || Date.parse(String(deal.deadline)) <= Date.now()) return err(409, "deal deadline has passed", ErrorCode.IllegalStateTransition);
      const otp = await verifyOtpProof(base44, body, dealId, buyerId);
      const deliveryCost = Number(selectedDelivery?.cost || 0);
      const holdTotal = qty * Number(deal.price_per_unit || 0) + deliveryCost;
      const authorizationEvidence = authorizationId
        ? { authorization: "provider_authorized", authorization_id: authorizationId, authorization_provider: authorizationProvider || "unknown", authorization_correlation_id: authorizationCorrelationId || null }
        : { authorization: "migration_mock_success" };
      intent = {
        idempotency_key: idempotencyKey,
        request_hash: joinRequestHash,
        request_id: requestId,
        deal_id: dealId,
        deal_owner_user_id: String(deal.owner_user_id || ""),
        buyer_id: buyerId,
        qty,
        buyer_name: buyerName,
        buyer_email: buyerEmail,
        delivery_option_id: selectedDelivery?.option_id || null,
        delivery_method_type: selectedDelivery?.option_type || null,
        delivery_method_label: selectedDelivery?.label || null,
        delivery_cost: deliveryCost,
        delivery_address: deliveryAddress,
        delivery_city: deliveryCity,
        delivery_notes: deliveryNotes || null,
        affiliate_ref: affiliateRef || null,
        authorization_id: authorizationId || null,
        authorization_provider: authorizationProvider || (allowMigrationMock ? "migration_mock" : null),
        authorization_correlation_id: authorizationCorrelationId || null,
        authorization_evidence: authorizationEvidence,
        hold_total: holdTotal,
        otp_challenge_id: otp.challenge_id,
        otp_channel: otp.channel,
        otp_destination_hash: otp.destination_hash,
        payment_disclosure_version: PAYMENT_DISCLOSURE_VERSION
      };

      const staged = await base44.asServiceRole.entities.Deal.updateMany(
        { deal_id: dealId, state: { $in: [DealState.PendingTarget, DealState.TargetReached] }, pending_join_keys: { $nin: [idempotencyKey] } },
        { $addToSet: { pending_join_keys: idempotencyKey, pending_join_intents: intent } }
      );
      if (Number(staged?.updated || 0) !== 1) {
        deal = (await base44.asServiceRole.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1))?.[0];
        if (!deal) return err(404, "deal not found", ErrorCode.InvalidInput);
        const raced = pendingIntentFromDeal(deal, idempotencyKey);
        if (!raced) return err(409, "deal stopped accepting joins before reservation staging", ErrorCode.IllegalStateTransition);
        if (String(raced.request_hash || "") !== joinRequestHash) return err(409, "idempotency key is pending with a different Join payload", ErrorCode.IllegalStateTransition);
        intent = raced;
      }
    }

    const held = await inventory(base44, "hold", { deal_id: dealId, qty, idempotency_key: idempotencyKey, request_hash: joinRequestHash });
    const reservationId = String(held.reservation_id || "");
    if (!reservationId) throw Object.assign(new Error("inventory hold returned no reservation id"), { status: 503, code: ErrorCode.TemporarilyUnavailable });

    let committed: any;
    try {
      committed = await inventory(base44, "commit", { reservation_id: reservationId });
    } catch (commitError: any) {
      try {
        const status = await inventory(base44, "reservation_status", { reservation_id: reservationId });
        if (String(status.status) === "committed") committed = status;
        else if (String(status.status) === "held") committed = await inventory(base44, "commit", { reservation_id: reservationId });
        else throw commitError;
      } catch {
        throw Object.assign(new Error("Join reservation outcome is pending recovery"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
      }
    }

    const reservationStatus = String(committed?.committed_at || "")
      ? committed
      : await inventory(base44, "reservation_status", { reservation_id: reservationId });
    if (String(reservationStatus.status) !== "committed") {
      throw Object.assign(new Error("reservation is not committed"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
    }

    const projection = await buildProjection(intent, reservationStatus, trackingSecret);
    const projected = await base44.asServiceRole.entities.Deal.updateMany(
      { deal_id: dealId },
      {
        $addToSet: { join_reservations: projection.reservation, join_idempotency_keys: idempotencyKey },
        $max: { reserved_units: Number(reservationStatus.committed_units || qty), inventory_committed_units: Number(reservationStatus.committed_units || qty) },
        $set: {
          inventory_sync_status: "synced",
          inventory_reserved_units: Number(reservationStatus.reserved_units || reservationStatus.committed_units || qty),
          inventory_synced_at: new Date().toISOString()
        }
      }
    );
    if (Number(projected?.updated || 0) !== 1) {
      throw Object.assign(new Error("committed Join could not be projected into Base44"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
    }

    await finishJoinDerived(base44.asServiceRole, deal, projection.reservation, intent);

    const after = (await base44.asServiceRole.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1))?.[0];
    if (after && String(after.state) === DealState.PendingTarget && Number(after.reserved_units || 0) >= Number(after.threshold_units || 0)) {
      const targetTransition = { state_type: "deal_state", from_state: DealState.PendingTarget, to_state: DealState.TargetReached, action_name: "deal.target_reached", request_id: requestId, idempotency_key: `target-reached:${dealId}`, created_at: projection.joinedAt, payload: { committed_units: Number(after.reserved_units || 0) } };
      await base44.asServiceRole.entities.Deal.updateMany(
        { deal_id: dealId, state: DealState.PendingTarget, reserved_units: { $gte: Number(after.threshold_units || 0) } },
        { $set: { state: DealState.TargetReached, last_transition_key: `target-reached:${dealId}` }, $push: { transition_journal: targetTransition } }
      );
    }

    return Response.json(projection.response);
  } catch (e: any) {
    return err(Number(e?.status || e?.statusCode || 500), String(e?.message || "internal_error"), e?.code ? String(e.code) : undefined);
  }
});