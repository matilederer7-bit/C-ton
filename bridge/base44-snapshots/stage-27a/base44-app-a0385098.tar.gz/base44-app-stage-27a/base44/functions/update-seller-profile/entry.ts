import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status: number, message: string, code?: string) {
  return Response.json({ ok: false, error: message, ...(code ? { code } : {}) }, { status });
}

function clean(value: unknown, max: number) {
  return String(value ?? "").trim().slice(0, max);
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }

  const rows = await base44.asServiceRole.entities.SellerAccount.filter({ owner_user_id: String(user.id) }, "-created_date", 1);
  const seller = rows?.[0];
  if (!seller) return fail(404, "seller account not found", ErrorCode.InvalidInput);

  const displayName = clean(body.display_name ?? seller.display_name, 160);
  const businessName = clean(body.business_name ?? seller.business_name, 200);
  const supportPhone = clean(body.support_phone ?? seller.support_phone, 40);
  const supportEmail = clean(body.support_email ?? seller.support_email, 254).toLowerCase();

  if (!displayName) return fail(400, "display_name is required", ErrorCode.InvalidInput);
  if (!businessName) return fail(400, "business_name is required", ErrorCode.InvalidInput);
  if (supportEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(supportEmail)) return fail(400, "support_email is invalid", ErrorCode.InvalidInput);

  const updated = await base44.asServiceRole.entities.SellerAccount.update(seller.id, {
    display_name: displayName,
    business_name: businessName,
    support_phone: supportPhone || null,
    support_email: supportEmail || null
  });

  return Response.json({
    ok: true,
    seller: {
      seller_id: String(updated?.seller_id || seller.seller_id),
      display_name: String(updated?.display_name || displayName),
      business_name: String(updated?.business_name || businessName),
      support_phone: String(updated?.support_phone || supportPhone || ""),
      support_email: String(updated?.support_email || supportEmail || ""),
      seller_status: String(updated?.seller_status || seller.seller_status || "Active"),
      verification_status: String(updated?.verification_status || seller.verification_status || "pending")
    },
    immutable_fields: ["seller_id", "seller_status", "verification_status", "owner_user_id"]
  });
});