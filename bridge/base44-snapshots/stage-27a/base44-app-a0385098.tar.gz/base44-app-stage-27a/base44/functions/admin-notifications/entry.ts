import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const STATUSES = new Set(["pending","processing","sent","failed","skipped"]);
const CHANNELS = new Set(["sms","email","whatsapp_link","internal"]);
const STUCK_MS = 5 * 60_000;

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}
function text(value: unknown, max = 400) { return String(value ?? "").trim().slice(0, max); }
function ageSeconds(value: unknown, now: number) {
  const ms = Date.parse(String(value || ""));
  return Number.isFinite(ms) ? Math.max(0, (now - ms) / 1000) : null;
}
function safeRow(row: any) {
  return {
    notification_id: row.notification_id,
    event_type: row.event_type,
    recipient_type: row.recipient_type,
    recipient_ref: row.recipient_ref ? "[redacted]" : null,
    deal_id: row.deal_id || null,
    participant_id: row.participant_id || null,
    seller_id: row.seller_id || null,
    channel: row.channel,
    template_key: row.template_key,
    locale: row.locale || "he-IL",
    status: row.status,
    attempt_count: Number(row.attempt_count || 0),
    max_attempts: Number(row.max_attempts || 3),
    scheduled_for: row.scheduled_for || null,
    provider_code: row.provider_code || null,
    provider_message_id: row.provider_message_id ? "[redacted]" : null,
    sent_at: row.sent_at || null,
    last_error: row.last_error || null,
    created_at: row.created_at || row.created_date || null,
    updated_at: row.updated_at || row.updated_date || null,
    event_count: Array.isArray(row.event_journal) ? row.event_journal.length : 0
  };
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (String(user?.role || "") !== "admin") return fail(403, "admin required", ErrorCode.ForbiddenAction);
  const admin = base44.asServiceRole;

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const operation = String(body?.operation || "status");

  if (operation === "status") {
    const query: Record<string, unknown> = {};
    if (body.status && STATUSES.has(String(body.status))) query.status = String(body.status);
    if (body.channel && CHANNELS.has(String(body.channel))) query.channel = String(body.channel);
    const rows = await admin.entities.NotificationEvent.filter(query, "-created_at", 5000).catch(() => []);
    const now = Date.now();
    const all = rows || [];
    const counts: Record<string, number> = { pending:0, processing:0, sent:0, failed:0, skipped:0 };
    const byChannel: Record<string, Record<string, number>> = {};
    let retryable = 0;
    let oldestPendingAge: number | null = null;
    let oldestFailedAge: number | null = null;
    let stuckProcessing = 0;
    for (const row of all) {
      const status = String(row.status || "");
      counts[status] = (counts[status] || 0) + 1;
      const channel = String(row.channel || "unknown");
      byChannel[channel] ||= { pending:0, processing:0, sent:0, failed:0, skipped:0 };
      byChannel[channel][status] = (byChannel[channel][status] || 0) + 1;
      if (status === "pending" && Number(row.attempt_count || 0) > 0) retryable += 1;
      const pendingAge = status === "pending" ? ageSeconds(row.created_at || row.created_date, now) : null;
      if (pendingAge !== null) oldestPendingAge = oldestPendingAge === null ? pendingAge : Math.max(oldestPendingAge, pendingAge);
      const failedAge = status === "failed" ? ageSeconds(row.updated_at || row.updated_date || row.created_at, now) : null;
      if (failedAge !== null) oldestFailedAge = oldestFailedAge === null ? failedAge : Math.max(oldestFailedAge, failedAge);
      const processingAge = status === "processing" ? ageSeconds(row.updated_at || row.updated_date || row.created_at, now) : null;
      if (processingAge !== null && processingAge * 1000 > STUCK_MS) stuckProcessing += 1;
    }
    const verdict = counts.failed > 0 || stuckProcessing > 0 ? "blocked" : counts.pending > 0 || retryable > 0 ? "warning" : "ready";
    return Response.json({
      ok: true,
      notifications: { ...counts, retryable, unique_event_keys: new Set(all.map((row: any) => String(row.idempotency_key || ""))).size, oldest_pending_age_s: oldestPendingAge, oldest_failed_age_s: oldestFailedAge, stuck_processing: stuckProcessing },
      by_channel: Object.entries(byChannel).map(([channel, value]) => ({ channel, ...value })),
      recent: all.slice(0, 100).map(safeRow),
      provider: { connected: false, external_delivery: false, blocker: "real notification provider and Worker Automation are not connected" },
      retry_schedule_seconds: [30,90,270],
      verdict
    });
  }

  if (operation === "reset_stuck") {
    const reason = text(body.reason, 1000);
    if (!reason) return fail(400, "reason is required", ErrorCode.InvalidInput);
    const rows = await admin.entities.NotificationEvent.filter({ status:"processing" }, "updated_at", 1000).catch(() => []);
    const now = Date.now();
    let reset = 0;
    for (const row of rows || []) {
      const age = ageSeconds(row.updated_at || row.updated_date || row.created_at, now);
      if (age === null || age * 1000 <= STUCK_MS) continue;
      const event = { event_type:"notification.reset_stuck", from_status:"processing", to_status:"pending", reason, actor_user_id:String(user.id), created_at:new Date().toISOString() };
      await admin.entities.NotificationEvent.update(row.id, {
        status:"pending",
        scheduled_for:new Date().toISOString(),
        updated_at:new Date().toISOString(),
        last_error:`manual reset: ${reason}`,
        event_journal:[...(Array.isArray(row.event_journal)?row.event_journal:[]),event]
      });
      reset += 1;
    }
    return Response.json({ ok:true, reset });
  }

  return fail(400, "unsupported notification operation", ErrorCode.InvalidInput);
});
