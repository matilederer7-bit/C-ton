import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status: number, message: string, code?: string) {
  return Response.json({ ok: false, error: message, ...(code ? { code } : {}) }, { status });
}

Deno.serve(async (req) => {
  if (req.method !== "GET" && req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (String(user?.role || "") !== "admin") return fail(403, "admin role required", ErrorCode.ForbiddenAction);

  if (req.method === "POST") {
    let body: any;
    try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
    if (String(body?.operation || "") === "set_settlement_status") {
      const sellerId = String(body?.seller_id || "").trim();
      const settlementStatus = String(body?.settlement_status || "").trim();
      const reason = String(body?.reason || "").trim().slice(0, 1000);
      if (!sellerId) return fail(400, "seller_id required", ErrorCode.InvalidInput);
      if (!["active", "review", "hold"].includes(settlementStatus)) return fail(400, "invalid settlement_status", ErrorCode.InvalidInput);
      if (!reason) return fail(400, "reason required", ErrorCode.InvalidInput);
      const seller = (await base44.asServiceRole.entities.SellerAccount.filter({ seller_id: sellerId }, "-created_date", 1))?.[0];
      if (!seller) return fail(404, "seller not found", ErrorCode.InvalidInput);
      const previous = String(seller.settlement_status || "active");
      if (previous !== settlementStatus) {
        const journal = Array.isArray(seller.operation_journal) ? seller.operation_journal : [];
        await base44.asServiceRole.entities.SellerAccount.updateMany(
          { seller_id: sellerId, settlement_status: seller.settlement_status || previous },
          { $set: { settlement_status: settlementStatus, operation_journal: [...journal, { event_type: "seller.settlement_status_changed", created_at: new Date().toISOString(), actor_user_id: String(user.id), payload: { from: previous, to: settlementStatus, reason } }] } }
        );
      }
    }
  }

  const rows = await base44.asServiceRole.entities.SellerAccount.list("-created_date", 500);
  const sellers = (Array.isArray(rows) ? rows : []).map((seller: any) => {
    const history = Array.isArray(seller.review_history) ? seller.review_history : [];
    const latest = history.length ? history[history.length - 1] : null;
    const effectiveApproved =
      String(seller.verification_status || "pending") === "approved" &&
      Boolean(seller.verification_reviewed_at) &&
      Boolean(seller.verification_reviewed_by);

    return {
      seller_id: String(seller.seller_id || ""),
      display_name: String(seller.display_name || ""),
      business_name: String(seller.business_name || ""),
      support_phone: String(seller.support_phone || ""),
      support_email: String(seller.support_email || ""),
      seller_status: String(seller.seller_status || "Active"),
      settlement_status: String(seller.settlement_status || "active"),
      verification_status: String(seller.verification_status || "pending"),
      verification_reviewed_at: seller.verification_reviewed_at || null,
      kyc_effective_approved: effectiveApproved,
      review_count: history.length,
      latest_review: latest ? {
        created_at: latest.created_at || null,
        previous_verification_status: latest.previous_verification_status || null,
        verification_status: latest.verification_status || null,
        previous_seller_status: latest.previous_seller_status || null,
        seller_status: latest.seller_status || null,
        note: String(latest.note || "").slice(0, 500)
      } : null,
      created_date: seller.created_date || null,
      updated_date: seller.updated_date || null
    };
  });

  return Response.json({ ok: true, sellers });
});
