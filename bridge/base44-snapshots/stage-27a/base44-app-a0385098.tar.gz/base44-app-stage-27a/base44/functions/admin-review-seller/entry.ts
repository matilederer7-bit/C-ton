import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const SELLER_STATUSES = ["Active", "UnderReview", "Restricted", "Suspended", "Banned"];
const VERIFICATION_STATUSES = ["pending", "approved", "rejected"];

function fail(status: number, message: string, code?: string) {
  return Response.json({ ok: false, error: message, ...(code ? { code } : {}) }, { status });
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (String(user?.role || "") !== "admin") return fail(403, "admin role required", ErrorCode.ForbiddenAction);

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }

  const sellerId = String(body?.seller_id || "").trim();
  if (!sellerId) return fail(400, "seller_id required", ErrorCode.InvalidInput);

  const hasVerification = body?.verification_status !== undefined && body?.verification_status !== null && String(body.verification_status) !== "";
  const hasSellerStatus = body?.seller_status !== undefined && body?.seller_status !== null && String(body.seller_status) !== "";
  if (!hasVerification && !hasSellerStatus) return fail(400, "verification_status or seller_status required", ErrorCode.InvalidInput);

  const verificationStatus = hasVerification ? String(body.verification_status) : null;
  const sellerStatus = hasSellerStatus ? String(body.seller_status) : null;
  if (verificationStatus && !VERIFICATION_STATUSES.includes(verificationStatus)) return fail(400, "invalid verification_status", ErrorCode.InvalidInput);
  if (sellerStatus && !SELLER_STATUSES.includes(sellerStatus)) return fail(400, "invalid seller_status", ErrorCode.InvalidInput);

  const note = String(body?.note || "").trim().slice(0, 500);
  const rows = await base44.asServiceRole.entities.SellerAccount.filter({ seller_id: sellerId }, "-created_date", 2);
  if (!rows?.length) return fail(404, "seller not found", ErrorCode.InvalidInput);
  if (rows.length > 1) return fail(409, "seller_id is not unique", ErrorCode.IllegalStateTransition);
  const seller = rows[0];

  const reviewedAt = new Date().toISOString();
  const reviewEntry = {
    review_id: crypto.randomUUID(),
    reviewed_by: String(user.id),
    created_at: reviewedAt,
    previous_verification_status: String(seller.verification_status || "pending"),
    verification_status: verificationStatus || String(seller.verification_status || "pending"),
    previous_seller_status: String(seller.seller_status || "Active"),
    seller_status: sellerStatus || String(seller.seller_status || "Active"),
    note: note || null
  };

  const update: Record<string, any> = {
    review_history: [...(Array.isArray(seller.review_history) ? seller.review_history : []), reviewEntry]
  };
  if (verificationStatus) {
    update.verification_status = verificationStatus;
    update.verification_reviewed_at = reviewedAt;
    update.verification_reviewed_by = String(user.id);
  }
  if (sellerStatus) update.seller_status = sellerStatus;

  const updated = await base44.asServiceRole.entities.SellerAccount.update(seller.id, update);
  const effectiveApproved =
    String(updated?.verification_status || seller.verification_status || "pending") === "approved" &&
    Boolean(updated?.verification_reviewed_at || update.verification_reviewed_at || seller.verification_reviewed_at) &&
    Boolean(updated?.verification_reviewed_by || update.verification_reviewed_by || seller.verification_reviewed_by);

  return Response.json({
    ok: true,
    seller: {
      seller_id: sellerId,
      seller_status: String(updated?.seller_status || update.seller_status || seller.seller_status || "Active"),
      verification_status: String(updated?.verification_status || update.verification_status || seller.verification_status || "pending"),
      verification_reviewed_at: updated?.verification_reviewed_at || update.verification_reviewed_at || seller.verification_reviewed_at || null,
      kyc_effective_approved: effectiveApproved,
      review_count: Array.isArray(updated?.review_history) ? updated.review_history.length : update.review_history.length
    },
    review: reviewEntry
  });
});
