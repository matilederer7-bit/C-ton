const DEFAULT_TIMEOUT_MS = 20000;
const DEFAULT_CORE_URL = "https://siton-demo-preview.onrender.com";

Deno.serve(async () => {
  const coreUrl = String(Deno.env.get("SITON_CORE_URL") || DEFAULT_CORE_URL).trim().replace(/\/$/, "");
  const startedAt = Date.now();

  if (!coreUrl) {
    return Response.json({
      ok: false,
      bridge: "siton-base44-migration",
      mode: "read-only",
      canonical_core_untouched: true,
      core_url_configured: false,
      core_reachable: false,
      error: "SITON_CORE_URL_NOT_CONFIGURED",
      checked_at: new Date().toISOString()
    });
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), DEFAULT_TIMEOUT_MS);

  try {
    const response = await fetch(`${coreUrl}/health`, {
      method: "GET",
      headers: { Accept: "application/json" },
      signal: controller.signal
    });

    let body = null;
    const contentType = response.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      body = await response.json().catch(() => null);
    } else {
      body = await response.text().catch(() => null);
    }

    return Response.json({
      ok: response.ok,
      bridge: "siton-base44-migration",
      mode: "read-only",
      canonical_core_untouched: true,
      core_url_configured: true,
      core_reachable: true,
      core_status: response.status,
      latency_ms: Date.now() - startedAt,
      health: body,
      checked_at: new Date().toISOString()
    });
  } catch (error) {
    const isAbort = error instanceof DOMException && error.name === "AbortError";
    return Response.json({
      ok: false,
      bridge: "siton-base44-migration",
      mode: "read-only",
      canonical_core_untouched: true,
      core_url_configured: true,
      core_reachable: false,
      latency_ms: Date.now() - startedAt,
      error: isAbort ? "SITON_CORE_TIMEOUT" : "SITON_CORE_UNREACHABLE",
      detail: error instanceof Error ? error.message : String(error),
      checked_at: new Date().toISOString()
    });
  } finally {
    clearTimeout(timer);
  }
});
