import { BuyerState, DealState, ErrorCode, MoneyState } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status: number, message: string, code?: string) {
  return Response.json({ ok: false, error: message, ...(code ? { code } : {}) }, { status });
}

function countBy(rows: any[], field: string) {
  const out: Record<string, number> = {};
  for (const row of rows) {
    const key = String(row?.[field] || "unknown");
    out[key] = (out[key] || 0) + 1;
  }
  return out;
}

function countQtyBy(rows: any[], field: string) {
  const out: Record<string, number> = {};
  for (const row of rows) {
    const key = String(row?.[field] || "unknown");
    out[key] = (out[key] || 0) + Number(row?.qty || 0);
  }
  return out;
}

function roundMoney(value: number) {
  return Math.round((Number(value) || 0) * 100) / 100;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);

  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const dealId = String(body?.deal_id || "").trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(dealId)) {
    return fail(400, "deal_id must be a valid UUID", ErrorCode.InvalidInput);
  }

  const rows = await base44.asServiceRole.entities.Deal.filter(
    { deal_id: dealId, owner_user_id: String(user.id) },
    "-created_date",
    1
  );
  const deal = rows?.[0];
  if (!deal) return fail(404, "deal not found", ErrorCode.InvalidInput);

  const reservations = Array.isArray(deal.join_reservations) ? deal.join_reservations : [];
  const transitions = Array.isArray(deal.transition_journal) ? deal.transition_journal : [];
  const totalQty = reservations.reduce((sum: number, row: any) => sum + Number(row?.qty || 0), 0);
  const totalHold = reservations.reduce((sum: number, row: any) => sum + Number(row?.hold_total || 0), 0);
  const finalUnits = reservations.reduce((sum: number, row: any) => [MoneyState.ChargedSuccess, MoneyState.RecoveredCharge].includes(String(row?.money_state || "")) ? sum + Number(row?.qty || 0) : sum, 0);
  const pendingUnits = reservations.reduce((sum: number, row: any) => String(row?.buyer_state || "") === BuyerState.ChargeFailedCompletion || String(row?.money_state || "") === MoneyState.ChargeFailedRecovery ? sum + Number(row?.qty || 0) : sum, 0);
  const failedUnits = Math.max(0, totalQty - finalUnits - pendingUnits);
  const ledger = Array.isArray(deal.money_ledger_events) ? deal.money_ledger_events : [];
  const ledgerGross = ledger.reduce((sum: number, row: any) => sum + Number(row?.gross_amount || 0), 0);
  const platformFeeTotal = ledger.reduce((sum: number, row: any) => sum + Number(row?.platform_fee_total_amount || 0), 0);
  const sellerNetPayable = ledger.reduce((sum: number, row: any) => sum + Number(row?.seller_net_amount || 0), 0);
  const refundsTotal = ledger.filter((row: any) => Number(row?.gross_amount || 0) < 0).reduce((sum: number, row: any) => sum + Math.abs(Number(row?.gross_amount || 0)), 0);
  const initiallyChargedUnits = reservations.reduce((sum: number, row: any) => String(row?.money_state || "") === MoneyState.ChargedSuccess ? sum + Number(row?.qty || 0) : sum, 0);
  const recoveredUnits = reservations.reduce((sum: number, row: any) => String(row?.money_state || "") === MoneyState.RecoveredCharge ? sum + Number(row?.qty || 0) : sum, 0);
  const excludedUnits = Math.max(0, totalQty - finalUnits);
  const volumeAmount = String(deal.state || "") === DealState.Completed ? Math.max(0, ledgerGross) : totalHold;
  const terminalStates = new Set([DealState.Completed, DealState.Failed, DealState.Cancelled]);
  const closedTransition = [...transitions].reverse().find((entry: any) => terminalStates.has(String(entry?.to_state || "") as any));
  const failureReason = String(deal.state || "") === DealState.Failed
    ? (Number(deal.reserved_units || 0) < Number(deal.min_units || 0) && finalUnits === 0
      ? "העסקה לא הגיעה למינימום"
      : finalUnits < Number(deal.threshold_units || 0)
        ? "החיובים הסופיים היו מתחת לסף ההצלחה"
        : "העסקה לא הושלמה")
    : null;
  const images = Array.isArray(deal.images) ? [...deal.images].sort((a: any, b: any) => Number(a?.sort_order || 0) - Number(b?.sort_order || 0)) : [];

  return Response.json({
    ok: true,
    deal: {
      deal_id: deal.deal_id,
      seller_id: deal.seller_id,
      seller_display_name: deal.seller_display_name,
      state: deal.state,
      deal_type: deal.deal_type,
      title: deal.title,
      short_description: deal.short_description || null,
      what_you_get: deal.what_you_get || null,
      price_per_unit: Number(deal.price_per_unit || 0),
      min_units: Number(deal.min_units || 0),
      max_units: Number(deal.max_units || 0),
      threshold_units: Number(deal.threshold_units || 0),
      reserved_units: Number(deal.reserved_units || 0),
      deadline: deal.deadline || null,
      published_at: deal.published_at || null,
      completion_window_until: deal.completion_window_until || null,
      delivery_options: Array.isArray(deal.delivery_options) ? deal.delivery_options : [],
      voucher_terms: deal.voucher_terms || null,
      ticket_terms: deal.ticket_terms || null,
      created_date: deal.created_date || null,
      updated_date: deal.updated_date || null,
      primary_image_url: images?.[0]?.file_url ? String(images[0].file_url) : null,
      closed_at: closedTransition?.created_at || (terminalStates.has(String(deal.state || "") as any) ? deal.updated_date || null : null)
    },
    summary: {
      final_units: finalUnits,
      initially_charged_units: initiallyChargedUnits,
      recovered_units: recoveredUnits,
      excluded_units: excludedUnits,
      pending_units: pendingUnits,
      failed_units: failedUnits,
      volume_amount: Number(volumeAmount || 0),
      gross_collected: roundMoney(ledgerGross),
      platform_fee_total: roundMoney(platformFeeTotal),
      seller_net_payable: roundMoney(sellerNetPayable),
      refunds_total: roundMoney(refundsTotal),
      money_event_count: ledger.length,
      financial_snapshot_ready: finalUnits === 0 || ledger.some((row: any) => Number(row?.gross_amount || 0) > 0),
      threshold_units: Number(deal.threshold_units || 0),
      min_units: Number(deal.min_units || 0),
      would_meet_financial_threshold_now: finalUnits >= Number(deal.threshold_units || 0),
      failure_reason: failureReason
    },
    aggregates: {
      reservation_records: reservations.length,
      reserved_quantity_from_reservations: totalQty,
      hold_total_snapshot: totalHold,
      buyer_state_records: countBy(reservations, "buyer_state"),
      buyer_state_quantity: countQtyBy(reservations, "buyer_state"),
      money_state_records: countBy(reservations, "money_state"),
      money_state_quantity: countQtyBy(reservations, "money_state"),
      delivery_method_quantity: countQtyBy(reservations, "delivery_method_type"),
      distribution_source_quantity: countQtyBy(reservations.filter((row: any) => String(row?.affiliate_ref || "").trim()), "affiliate_ref")
    },
    transitions: transitions.slice(-30).reverse().map((entry: any) => ({
      state_type: entry?.state_type || null,
      from_state: entry?.from_state || null,
      to_state: entry?.to_state || null,
      action_name: entry?.action_name || null,
      created_at: entry?.created_at || null
    })),
    sensitive_fields_excluded: [
      "buyer_id",
      "buyer_name",
      "buyer_phone",
      "buyer_email",
      "delivery_address",
      "delivery_notes",
      "authorization_id",
      "authorization_correlation_id",
      "tracking_token_hash",
      "request_hash",
      "idempotency_key",
      "transition_payload"
    ]
  });
});
