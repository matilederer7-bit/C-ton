import { DealState, ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";
import { assertCriticalTermsIntegrity } from "../../shared/deal-integrity.ts";

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}

async function inventory(base44: any, operation: string, payload: Record<string, unknown>) {
  try {
    const response = await base44.asServiceRole.functions.invoke("inventory-bridge", { operation, ...payload });
    const body = response?.data || response;
    if (!body?.ok || !body?.result) {
      throw Object.assign(new Error(body?.error || "inventory bridge returned no result"), {
        status: 503,
        code: body?.code || "inventory_bridge_failed",
      });
    }
    return body.result;
  } catch (error: any) {
    const data = error?.response?.data || error?.data || {};
    throw Object.assign(new Error(String(data?.error || error?.message || "inventory bridge failed")), {
      status: Number(error?.response?.status || error?.status || 503),
      code: String(data?.code || error?.code || "inventory_bridge_failed"),
    });
  }
}

async function clearPending(base44: any, dealId: string, key: string, intent: any) {
  await base44.asServiceRole.entities.Deal.updateMany(
    { deal_id: dealId },
    { $pull: { pending_join_keys: key, pending_join_intents: intent } },
  );
}

async function ensureDistributionAttribution(base44: any, dealId: string, reservation: any) {
  const participantId = String(reservation?.participant_id || "");
  const sourceCode = String(reservation?.affiliate_ref || "").trim().toLowerCase();
  if (!participantId || !sourceCode) return;
  const source = (await base44.asServiceRole.entities.DistributionSource.filter({ source_code: sourceCode, active: true }, "-created_date", 1))?.[0];
  if (!source) return;
  if (String(source.source_type || "admin") === "distributor") {
    if (String(source.deal_id || "") !== dealId || !source.distributor_access_id || !source.owner_user_id) return;
    const access = (await base44.asServiceRole.entities.DistributorDealAccess.filter({ access_id: String(source.distributor_access_id), owner_user_id: String(source.owner_user_id), deal_id: dealId, status: "active" }, "-created_at", 1))?.[0];
    if (!access) return;
  }
  const prior = await base44.asServiceRole.entities.DistributionAttribution.filter({ participant_id: participantId, source_id: String(source.source_id) }, "-attributed_at", 1);
  if (prior?.[0]) return;
  await base44.asServiceRole.entities.DistributionAttribution.create({
    attribution_id: crypto.randomUUID(),
    source_id: String(source.source_id),
    source_code: String(source.source_code),
    deal_id: dealId,
    participant_id: participantId,
    qty: Math.max(1, Number(reservation?.qty || 1)),
    attributed_at: String(reservation?.joined_at || new Date().toISOString()),
  }).catch(() => undefined);
}

function replayBody(intent: any, dealId: string, key: string) {
  return {
    deal_id: dealId,
    buyer_id: String(intent.buyer_id || ""),
    qty: Number(intent.qty || 0),
    buyer_name: intent.buyer_name || null,
    buyer_email: intent.buyer_email || null,
    delivery_option_id: intent.delivery_option_id || null,
    delivery_address: intent.delivery_address || null,
    delivery_city: intent.delivery_city || null,
    delivery_notes: intent.delivery_notes || null,
    affiliate_ref: intent.affiliate_ref || null,
    authorization_id: intent.authorization_id || null,
    authorization_provider: intent.authorization_provider || null,
    authorization_correlation_id: intent.authorization_correlation_id || null,
    payment_disclosure_accepted: true,
    otp_challenge_id: intent.otp_challenge_id || null,
    idempotency_key: key,
  };
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);

  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (!user?.id) return fail(401, "authentication required", ErrorCode.ForbiddenAction);

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const dealId = String(body?.deal_id || "").trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(dealId)) {
    return fail(400, "deal_id must be a valid UUID", ErrorCode.InvalidInput);
  }

  try {
    let deal = (await base44.asServiceRole.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1))?.[0];
    if (!deal) return fail(404, "deal not found", ErrorCode.InvalidInput);
    await assertCriticalTermsIntegrity(deal);
    const isAdmin = String(user.role || "") === "admin";
    const isOwner = String(deal.owner_user_id || "") === String(user.id);
    if (!isAdmin && !isOwner) return fail(403, "deal owner or admin required", ErrorCode.ForbiddenAction);

    const intents = Array.isArray(deal.pending_join_intents) ? [...deal.pending_join_intents] : [];
    const keys = Array.isArray(deal.pending_join_keys)
      ? [...new Set(deal.pending_join_keys.map((value: any) => String(value || "")).filter(Boolean))]
      : [...new Set(intents.map((intent: any) => String(intent?.idempotency_key || "")).filter(Boolean))];
    const summary = { found: keys.length, committed: 0, released: 0, removed: 0, blocked: 0 };

    for (const key of keys) {
      const intent = intents.find((candidate: any) => String(candidate?.idempotency_key || "") === key);
      if (!intent) {
        throw Object.assign(new Error(`pending Join key ${key} has no recovery intent`), { status: 500, code: ErrorCode.TemporarilyUnavailable });
      }

      const lookup = await inventory(base44, "lookup", { deal_id: dealId, idempotency_key: key });
      if (!lookup?.found) {
        await clearPending(base44, dealId, key, intent);
        summary.removed += 1;
        continue;
      }
      if (String(lookup.request_hash || "") !== String(intent.request_hash || "")) {
        throw Object.assign(new Error("reservation request hash does not match pending Join intent"), { status: 500, code: ErrorCode.TemporarilyUnavailable });
      }

      const status = String(lookup.status || "");
      if (status === "committed") {
        const joinResponse = await base44.asServiceRole.functions.invoke("join-deal", replayBody(intent, dealId, key));
        const joined = joinResponse?.data || joinResponse;
        if (!joined?.ok) throw Object.assign(new Error("committed Join could not be projected"), { status: 503, code: ErrorCode.TemporarilyUnavailable });

        deal = (await base44.asServiceRole.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1))?.[0];
        const reservation = (Array.isArray(deal?.join_reservations) ? deal.join_reservations : []).find((candidate: any) => String(candidate?.idempotency_key || "") === key);
        const stillPending = Array.isArray(deal?.pending_join_keys) && deal.pending_join_keys.map(String).includes(key);
        if (!reservation || stillPending) {
          throw Object.assign(new Error("committed Join remains pending after recovery"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
        }
        await ensureDistributionAttribution(base44, dealId, reservation);
        summary.committed += 1;
        continue;
      }

      if (status === "held") {
        await inventory(base44, "release", { reservation_id: String(lookup.reservation_id) });
        await clearPending(base44, dealId, key, intent);
        summary.released += 1;
        continue;
      }

      if (status === "expired" || status === "released") {
        await clearPending(base44, dealId, key, intent);
        summary.removed += 1;
        continue;
      }

      summary.blocked += 1;
    }

    deal = (await base44.asServiceRole.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1))?.[0];
    if (deal && String(deal.state) === DealState.PendingTarget && Number(deal.reserved_units || 0) >= Number(deal.threshold_units || 0)) {
      const transitionKey = `target-reached:${dealId}`;
      await base44.asServiceRole.entities.Deal.updateMany(
        { deal_id: dealId, state: DealState.PendingTarget, reserved_units: { $gte: Number(deal.threshold_units || 0) } },
        {
          $set: { state: DealState.TargetReached, last_transition_key: transitionKey },
          $addToSet: {
            transition_journal: {
              state_type: "deal_state",
              from_state: DealState.PendingTarget,
              to_state: DealState.TargetReached,
              action_name: "deal.target_reached",
              idempotency_key: transitionKey,
              payload: { committed_units: Number(deal.reserved_units || 0) },
            },
          },
        },
      );
    }

    const latest = (await base44.asServiceRole.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1))?.[0];
    const pendingKeys = Array.isArray(latest?.pending_join_keys) ? latest.pending_join_keys.filter(Boolean).length : 0;
    return Response.json({
      ok: pendingKeys === 0 && summary.blocked === 0,
      deal_id: dealId,
      summary,
      pending: pendingKeys,
      committed_units: Number(latest?.reserved_units || 0),
    }, { status: pendingKeys === 0 && summary.blocked === 0 ? 200 : 409 });
  } catch (error: any) {
    const status = Number(error?.status || error?.statusCode || 500);
    return fail(status >= 400 && status < 600 ? status : 500, String(error?.message || "reconciliation failed"), String(error?.code || "join_reconciliation_failed"));
  }
});