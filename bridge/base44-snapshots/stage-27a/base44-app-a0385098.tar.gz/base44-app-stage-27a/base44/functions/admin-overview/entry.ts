import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status: number, message: string, code?: string) {
  return Response.json({ ok: false, error: message, ...(code ? { code } : {}) }, { status });
}

async function listAll(entity: any, fields: string[], maxRecords = 50000) {
  const pageSize = 5000;
  const rows: any[] = [];
  let skip = 0;
  while (rows.length < maxRecords) {
    const remaining = Math.min(pageSize, maxRecords - rows.length);
    const page = await entity.list("-created_date", remaining, skip, fields);
    if (!Array.isArray(page) || page.length === 0) break;
    rows.push(...page);
    if (page.length < remaining) break;
    skip += page.length;
  }
  return { rows, truncated: rows.length >= maxRecords };
}

function countBy(rows: any[], field: string) {
  const out: Record<string, number> = {};
  for (const row of rows) {
    const key = String(row?.[field] ?? "unknown");
    out[key] = (out[key] || 0) + 1;
  }
  return out;
}

Deno.serve(async (req) => {
  if (req.method !== "GET" && req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (String(user?.role || "") !== "admin") return fail(403, "admin role required", ErrorCode.ForbiddenAction);

  const admin = base44.asServiceRole;
  const [dealResult, sellerResult, outboxResult, dlqResult, paymentResult, supportResult] = await Promise.all([
    listAll(admin.entities.Deal, ["deal_id", "title", "state", "seller_id", "seller_display_name", "reserved_units", "max_units", "threshold_units", "deadline", "created_date", "updated_date"]),
    listAll(admin.entities.SellerAccount, ["seller_id", "display_name", "seller_status", "verification_status", "created_date"]),
    listAll(admin.entities.OutboxEvent, ["event_uuid", "event_type", "status", "attempt_count", "max_attempts", "available_at", "lease_expires_at", "last_error", "created_date"]),
    listAll(admin.entities.OutboxDeadLetter, ["event_uuid", "event_type", "attempt_count", "last_error", "dead_lettered_at", "created_date"]),
    listAll(admin.entities.PaymentAttempt, ["attempt_id", "deal_id", "participant_id", "attempt_type", "result_class", "error_code", "started_at", "completed_at", "created_date"]),
    listAll(admin.entities.OperationalCase, ["case_id", "subject", "case_type", "priority", "status", "opened_at", "created_date"])
  ]);

  const deals = dealResult.rows;
  const sellers = sellerResult.rows;
  const outbox = outboxResult.rows;
  const dlq = dlqResult.rows;
  const payments = paymentResult.rows;
  const supportCases = supportResult.rows;
  const now = Date.now();
  const supportClosed = new Set(["Resolved", "Closed"]);
  const supportSlaMs: Record<string, number> = { Urgent: 4 * 60 * 60_000, High: 24 * 60 * 60_000, Normal: 72 * 60 * 60_000, Low: 7 * 24 * 60 * 60_000 };
  const supportOverdue = supportCases.filter((row) => {
    if (supportClosed.has(String(row.status || ""))) return false;
    const opened = Date.parse(String(row.opened_at || row.created_date || ""));
    if (!Number.isFinite(opened)) return false;
    return now > opened + (supportSlaMs[String(row.priority || "Normal")] || supportSlaMs.Normal);
  });
  const supportSla: Record<string, number> = { Urgent: 0, High: 0, Normal: 0, Low: 0 };
  for (const row of supportOverdue) supportSla[String(row.priority || "Normal")] = (supportSla[String(row.priority || "Normal")] || 0) + 1;
  const supportReadiness = {
    open: supportCases.filter((row) => !supportClosed.has(String(row.status || ""))).length,
    urgent_open: supportCases.filter((row) => !supportClosed.has(String(row.status || "")) && row.priority === "Urgent").length,
    high_open: supportCases.filter((row) => !supportClosed.has(String(row.status || "")) && row.priority === "High").length,
    overdue_count: supportOverdue.length,
    sla: supportSla,
    sla_breached_cases: supportOverdue.slice(0, 10).map((row) => ({ case_id: row.case_id, subject: row.subject, priority: row.priority, status: row.status })),
    verdict: supportOverdue.some((row) => row.priority === "Urgent") ? "blocked" : supportOverdue.length > 0 ? "warning" : "ready"
  };

  const queue = {
    pending: outbox.filter((row) => row.status === "pending").length,
    processing: outbox.filter((row) => row.status === "processing").length,
    failed: outbox.filter((row) => row.status === "failed").length,
    dead_letter_projection: outbox.filter((row) => row.status === "dead_letter").length,
    stale_processing: outbox.filter((row) => row.status === "processing" && row.lease_expires_at && Date.parse(String(row.lease_expires_at)) <= now).length,
    dlq: dlq.length
  };

  const recentDeals = deals
    .slice()
    .sort((a, b) => Date.parse(String(b.updated_date || b.created_date || 0)) - Date.parse(String(a.updated_date || a.created_date || 0)))
    .slice(0, 20)
    .map((deal) => ({
      deal_id: deal.deal_id,
      title: deal.title,
      state: deal.state,
      seller_id: deal.seller_id,
      seller_display_name: deal.seller_display_name,
      reserved_units: Number(deal.reserved_units || 0),
      max_units: Number(deal.max_units || 0),
      threshold_units: Number(deal.threshold_units || 0),
      deadline: deal.deadline,
      updated_date: deal.updated_date || deal.created_date
    }));

  const recentDlq = dlq
    .slice()
    .sort((a, b) => Date.parse(String(b.dead_lettered_at || b.created_date || 0)) - Date.parse(String(a.dead_lettered_at || a.created_date || 0)))
    .slice(0, 10)
    .map((row) => ({
      event_uuid: row.event_uuid,
      event_type: row.event_type,
      attempt_count: Number(row.attempt_count || 0),
      last_error: String(row.last_error || "").slice(0, 300),
      dead_lettered_at: row.dead_lettered_at || row.created_date
    }));

  return Response.json({
    ok: true,
    generated_at: new Date().toISOString(),
    counts: {
      deals: deals.length,
      sellers: sellers.length,
      outbox: outbox.length,
      payment_attempts: payments.length,
      support_cases: supportCases.length
    },
    deal_states: countBy(deals, "state"),
    seller_statuses: countBy(sellers, "seller_status"),
    seller_verification: countBy(sellers, "verification_status"),
    payment_results: countBy(payments, "result_class"),
    payment_attempt_types: countBy(payments, "attempt_type"),
    queue,
    support_readiness: supportReadiness,
    recent_deals: recentDeals,
    recent_dlq: recentDlq,
    truncated: {
      deals: dealResult.truncated,
      sellers: sellerResult.truncated,
      outbox: outboxResult.truncated,
      dlq: dlqResult.truncated,
      payment_attempts: paymentResult.truncated,
      support_cases: supportResult.truncated
    },
    safety: {
      join_enabled: false,
      join_block_reason: "inventory_concurrency_gate_not_proven",
      real_money_enabled: false
    }
  });
});
