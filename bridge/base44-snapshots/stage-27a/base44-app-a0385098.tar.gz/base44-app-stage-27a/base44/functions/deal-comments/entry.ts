import { DealState, ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const encoder = new TextEncoder();
const PUBLIC_COMMENT_STATES = new Set([
  DealState.PendingTarget,
  DealState.TargetReached,
  DealState.ClosedForJoining,
  DealState.ReadyForCharging,
  DealState.Charging,
  DealState.CompletionWindow,
  DealState.Completed,
]);

function fail(status:number,error:string,code?:string){return Response.json({ok:false,error,...(code?{code}:{})},{status});}
function clean(value:unknown,max:number){return String(value??"").replace(/\s+/g," ").trim().slice(0,max);}
async function sha256(value:string){const b=await crypto.subtle.digest("SHA-256",encoder.encode(value));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("");}
function safe(row:any){return{comment_id:String(row.comment_id||""),display_name:String(row.display_name||""),message:String(row.message||""),created_at:row.created_at||row.created_date||null};}

Deno.serve(async(req)=>{
  if(req.method!=="POST")return fail(405,"method_not_allowed",ErrorCode.ForbiddenAction);
  const base44=createClientFromRequest(req);let body:any;try{body=await req.json();}catch{return fail(400,"invalid JSON body",ErrorCode.InvalidInput);}
  const operation=String(body?.operation||"list");
  const dealId=String(body?.deal_id||"").trim();
  if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(dealId))return fail(400,"deal_id must be a valid UUID",ErrorCode.InvalidInput);
  const admin=base44.asServiceRole;
  const deal=(await admin.entities.Deal.filter({deal_id:dealId},"-created_date",1).catch(()=>[]))?.[0];
  if(!deal||!PUBLIC_COMMENT_STATES.has(String(deal.state||"")))return fail(404,"deal unavailable",ErrorCode.InvalidInput);

  if(operation==="list"){
    const rows=await admin.entities.DealComment.filter({deal_id:dealId,status:"visible"},"-created_at",50).catch(()=>[]);
    return Response.json({ok:true,comments:(rows||[]).slice().reverse().map(safe)});
  }
  if(operation!=="post")return fail(400,"unsupported operation",ErrorCode.InvalidInput);

  const displayName=clean(body?.display_name,80),message=clean(body?.message,500),sessionToken=clean(body?.session_token,200),idempotencyKey=clean(body?.idempotency_key,300);
  if(displayName.length<2||message.length<1||sessionToken.length<16||idempotencyKey.length<12)return fail(400,"comment fields are invalid",ErrorCode.InvalidInput);
  const sessionHash=await sha256(`deal-comment:${dealId}:${sessionToken}`);
  const prior=(await admin.entities.DealComment.filter({deal_id:dealId,idempotency_key:idempotencyKey},"-created_at",1).catch(()=>[]))?.[0];
  if(prior)return Response.json({ok:true,comment:safe(prior),replay:true});

  const windowStart=new Date(Date.now()-10*60_000).toISOString();
  const recent=await admin.entities.DealComment.filter({deal_id:dealId,session_hash:sessionHash,created_at:{$gte:windowStart}},"-created_at",6).catch(()=>[]);
  if((recent||[]).length>=5)return fail(429,"too many comments; try again later",ErrorCode.ForbiddenAction);

  const row=await admin.entities.DealComment.create({comment_id:crypto.randomUUID(),deal_id:dealId,display_name:displayName,message,session_hash:sessionHash,idempotency_key:idempotencyKey,status:"visible",created_at:new Date().toISOString()});
  return Response.json({ok:true,comment:safe(row),replay:false});
});
