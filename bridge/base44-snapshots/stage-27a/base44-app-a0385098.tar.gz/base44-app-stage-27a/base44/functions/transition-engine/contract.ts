export * from "../../shared/constitution.ts";
