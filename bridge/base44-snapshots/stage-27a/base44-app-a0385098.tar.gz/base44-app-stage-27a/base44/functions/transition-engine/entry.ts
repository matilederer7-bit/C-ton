import { createClientFromRequest } from "npm:@base44/sdk";
import { Action, BuyerState, DealState, ErrorCode, MoneyState, assertBuyerTransition, assertChargingStartAllowed, assertDealTransition, assertFinalizeAllowed, assertMoneyTransition, assertRecoveryAllowed, resolveFinalDealState, thresholdUnits } from "./contract.ts";
import { appendCanonicalMoneyEvents, buildFinalMoneyEvent, projectMoneyEvents } from "./money-ledger.ts";
import { enqueueBuyerNotifications, enqueueSellerNotifications } from "../../shared/notifications.ts";
import { SITON_CRITICAL_TERMS, assertCompletionWindowIntegrity, assertCriticalTermsIntegrity, signCompletionWindow, signCriticalTerms } from "../../shared/deal-integrity.ts";

const TERMS_VERSION = "2026-04-26";
const SELLER_TERMS_VERSION = "2026-04-26";

function fail(status: number, error: string, code: string) {
  return Response.json({ ok: false, error, code }, { status });
}

function accepted(value: unknown) {
  return value === true || value === "true" || value === "on" || value === "1";
}

function validUuid(value: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
}

async function readOwnedDeal(admin: any, user: any, dealId: string) {
  const deal = (await admin.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1))?.[0];
  if (!deal) return null;
  const isAdmin = String(user?.role || "") === "admin";
  if (!isAdmin && String(deal.owner_user_id || "") !== String(user.id || "")) return null;
  return deal;
}

async function replayRecord(admin: any, deal: any, action: string, idempotencyKey: string) {
  const ownerUserId = String(deal.owner_user_id || "");
  const prior = await admin.entities.IdempotencyRecord.filter({
    owner_user_id: ownerUserId,
    entity_id: String(deal.deal_id),
    action_name: action,
    idempotency_key: idempotencyKey,
  }, "-created_date", 1).catch(() => []);
  return prior?.[0]?.response_json || null;
}

async function writeDerivedEvidence(admin: any, deal: any, transition: any, response: any) {
  await admin.entities.DealAudit.create({
    audit_id: transition.audit_id,
    owner_user_id: String(deal.owner_user_id || ""),
    deal_id: String(deal.deal_id),
    state_type: "deal_state",
    from_state: transition.from_state,
    to_state: transition.to_state,
    action_name: transition.action_name,
    request_id: transition.request_id,
    idempotency_key: transition.idempotency_key,
    payload: transition.payload || {},
    created_at: transition.created_at,
  }).catch(() => undefined);
  await admin.entities.IdempotencyRecord.create({
    owner_user_id: String(deal.owner_user_id || ""),
    entity_type: "deal",
    entity_id: String(deal.deal_id),
    action_name: transition.action_name,
    idempotency_key: transition.idempotency_key,
    response_json: response,
  }).catch(() => undefined);
}

async function transitionDealDocument(args: {
  admin: any;
  deal: any;
  fromState: string;
  toState: string;
  action: string;
  requestId: string;
  idempotencyKey: string;
  payload?: Record<string, unknown>;
  extraSet?: Record<string, unknown>;
  extraPush?: Record<string, unknown>;
}) {
  assertDealTransition(args.fromState, args.toState);
  const now = new Date().toISOString();
  const transition = {
    audit_id: crypto.randomUUID(),
    state_type: "deal_state",
    from_state: args.fromState,
    to_state: args.toState,
    action_name: args.action,
    request_id: args.requestId,
    idempotency_key: args.idempotencyKey,
    created_at: now,
    payload: args.payload || {},
  };
  const update: any = {
    $set: {
      ...(args.extraSet || {}),
      state: args.toState,
      last_transition_key: args.idempotencyKey,
    },
    $push: {
      ...(args.extraPush || {}),
      transition_journal: transition,
    },
  };
  const result = await args.admin.entities.Deal.updateMany(
    { deal_id: String(args.deal.deal_id), state: args.fromState },
    update,
  );
  if (Number(result?.updated || 0) !== 1) {
    const latest = (await args.admin.entities.Deal.filter({ deal_id: String(args.deal.deal_id) }, "-created_date", 1))?.[0];
    if (String(latest?.state || "") === args.toState && String(latest?.last_transition_key || "") === args.idempotencyKey) {
      return { replay: true, deal: latest, transition };
    }
    const error: any = new Error(`conditional transition lost ${args.fromState} -> ${args.toState}`);
    error.status = 409;
    error.code = ErrorCode.IllegalStateTransition;
    throw error;
  }
  const latest = (await args.admin.entities.Deal.filter({ deal_id: String(args.deal.deal_id) }, "-created_date", 1))?.[0];
  return { replay: false, deal: latest, transition };
}

async function publish(base44: any, user: any, deal: any, body: any, requestId: string, idempotencyKey: string) {
  if (String(deal.state || "") !== DealState.Draft) {
    if (String(deal.state || "") === DealState.PendingTarget && String(deal.last_transition_key || "") === idempotencyKey) {
      return { ok: true, deal_id: deal.deal_id, state: DealState.PendingTarget, replay: true };
    }
    throw Object.assign(new Error("deal is not Draft"), { status: 409, code: ErrorCode.IllegalStateTransition });
  }
  if (!accepted(body.seller_terms_accepted) || !accepted(body.seller_critical_terms_accepted) || !accepted(body.seller_threshold_90_accepted)) {
    throw Object.assign(new Error("seller publish terms are required"), { status: 400, code: ErrorCode.InvalidInput });
  }
  const seller = (await base44.asServiceRole.entities.SellerAccount.filter({ seller_id: String(deal.seller_id || "") }, "-created_date", 1))?.[0];
  if (!seller) throw Object.assign(new Error("seller account missing"), { status: 403, code: ErrorCode.ForbiddenAction });
  if (String(user?.role || "") !== "admin" && String(seller.owner_user_id || "") !== String(user.id || "")) {
    throw Object.assign(new Error("seller ownership mismatch"), { status: 403, code: ErrorCode.ForbiddenAction });
  }
  const status = String(seller.seller_status || "Active");
  const profileReady = Boolean(String(seller.business_name || "").trim() && (String(seller.support_phone || "").trim() || String(seller.support_email || "").trim()));
  const kycReady = String(seller.verification_status || "pending") === "approved" && seller.verification_reviewed_at && seller.verification_reviewed_by;
  if (["UnderReview", "Restricted", "Suspended", "Banned"].includes(status) || !profileReady || !kycReady) {
    throw Object.assign(new Error("seller is not eligible to publish"), { status: 403, code: ErrorCode.ForbiddenAction });
  }
  const price = Number(deal.price_per_unit || 0);
  const minimum = Number(deal.min_units || 0);
  const maximum = Number(deal.max_units || 0);
  const deadlineMs = Date.parse(String(deal.deadline || ""));
  const nowMs = Date.now();
  if (!(price > 0) || !Number.isInteger(minimum) || minimum < 1 || !Number.isInteger(maximum) || maximum < minimum || !Number.isFinite(deadlineMs) || deadlineMs <= nowMs || deadlineMs > nowMs + 7 * 24 * 60 * 60 * 1000) {
    throw Object.assign(new Error("deal critical terms are invalid"), { status: 400, code: ErrorCode.InvalidInput });
  }

  const inventoryEnforced = Deno.env.get("RESERVATION_SERVICE_ENFORCED") === "true";
  let inventorySync: any = null;
  if (inventoryEnforced) {
    try {
      const response = await base44.asServiceRole.functions.invoke("inventory-bridge", { operation: "sync", deal_id: String(deal.deal_id), max_units: maximum, status: "open", idempotency_key: idempotencyKey });
      const bridge = response?.data || response;
      if (!bridge?.ok || !bridge?.result) throw new Error("inventory sync missing result");
      inventorySync = bridge.result;
    } catch (error: any) {
      throw Object.assign(new Error(String(error?.message || "inventory unavailable")), { status: 503, code: ErrorCode.TemporarilyUnavailable });
    }
  }

  const publishedAt = new Date().toISOString();
  const canonicalThreshold = thresholdUnits(minimum);
  const criticalTermsSignature = await signCriticalTerms(deal, {
    published_at: publishedAt,
    threshold_units: canonicalThreshold,
    commission_rate: SITON_CRITICAL_TERMS.commission_rate,
    completion_window_hours: SITON_CRITICAL_TERMS.completion_window_hours,
  });
  const deadlineEvent = {
    event_id: crypto.randomUUID(),
    event_type: "deadline_check",
    aggregate_type: "deal",
    aggregate_id: String(deal.deal_id),
    status: "pending",
    available_at: publishedAt,
    payload: { deal_id: String(deal.deal_id) },
  };
  const legalAcceptance = {
    acceptance_type: "seller_publish_terms",
    actor_type: "seller",
    actor_ref: String(deal.seller_id),
    policy_version: SELLER_TERMS_VERSION,
    terms_version: TERMS_VERSION,
    accepted_at: publishedAt,
  };
  const result = await transitionDealDocument({
    admin: base44.asServiceRole,
    deal,
    fromState: DealState.Draft,
    toState: DealState.PendingTarget,
    action: Action.DealPublish,
    requestId,
    idempotencyKey,
    extraSet: {
      threshold_units: canonicalThreshold,
      commission_rate: SITON_CRITICAL_TERMS.commission_rate,
      completion_window_hours: SITON_CRITICAL_TERMS.completion_window_hours,
      critical_terms_signature: criticalTermsSignature,
      critical_terms_signed_at: publishedAt,
      reserved_units: Number.isFinite(Number(inventorySync?.committed_units)) ? Number(inventorySync.committed_units) : 0,
      inventory_sync_status: inventoryEnforced ? "synced" : "not_configured",
      inventory_reserved_units: Number.isFinite(Number(inventorySync?.reserved_units)) ? Number(inventorySync.reserved_units) : 0,
      inventory_committed_units: Number.isFinite(Number(inventorySync?.committed_units)) ? Number(inventorySync.committed_units) : 0,
      inventory_synced_at: inventoryEnforced ? publishedAt : null,
      published_at: publishedAt,
    },
    extraPush: { pending_events: deadlineEvent, legal_acceptances: legalAcceptance },
  });
  const response = { ok: true, deal_id: String(deal.deal_id), state: DealState.PendingTarget, replay: result.replay };
  if (!result.replay) await writeDerivedEvidence(base44.asServiceRole, deal, result.transition, response);
  return response;
}

async function closeJoining(base44: any, deal: any, requestId: string, idempotencyKey: string) {
  await assertCriticalTermsIntegrity(deal);
  if (String(deal.state || "") !== DealState.TargetReached) {
    if (String(deal.state || "") === DealState.ClosedForJoining && String(deal.last_transition_key || "") === idempotencyKey) {
      return { ok: true, deal_id: deal.deal_id, state: DealState.ClosedForJoining, replay: true };
    }
    throw Object.assign(new Error("deal is not TargetReached"), { status: 409, code: ErrorCode.IllegalStateTransition });
  }

  const inventoryEnforced = Deno.env.get("RESERVATION_SERVICE_ENFORCED") === "true";
  let current = deal;
  let inventoryClose: any = null;
  if (inventoryEnforced) {
    try {
      const reconcileResponse = await base44.functions.invoke("reconcile-join-intents", { deal_id: String(deal.deal_id) });
      const reconciled = reconcileResponse?.data || reconcileResponse;
      if (!reconciled?.ok) throw new Error("join reconciliation failed");
      current = (await base44.asServiceRole.entities.Deal.filter({ deal_id: String(deal.deal_id) }, "-created_date", 1))?.[0];
      if (!current) throw new Error("deal disappeared during join reconciliation");
      await assertCriticalTermsIntegrity(current);
      const pendingKeys = Array.isArray(current?.pending_join_keys) ? current.pending_join_keys.filter(Boolean) : [];
      if (!current || pendingKeys.length > 0) throw new Error("join intents remain in flight");
      const closeResponse = await base44.asServiceRole.functions.invoke("inventory-bridge", { operation: "close", deal_id: String(deal.deal_id), max_units: Number(current.max_units), idempotency_key: idempotencyKey });
      const bridge = closeResponse?.data || closeResponse;
      if (!bridge?.ok || !bridge?.result) throw new Error("inventory close missing result");
      inventoryClose = bridge.result;
    } catch (error: any) {
      throw Object.assign(new Error(String(error?.message || "inventory unavailable")), { status: 503, code: ErrorCode.TemporarilyUnavailable });
    }
  }

  const result = await transitionDealDocument({
    admin: base44.asServiceRole,
    deal: current,
    fromState: DealState.TargetReached,
    toState: DealState.ClosedForJoining,
    action: Action.DealCloseJoining,
    requestId,
    idempotencyKey,
    extraSet: {
      inventory_sync_status: inventoryEnforced ? "closed" : String(current.inventory_sync_status || "not_configured"),
      inventory_reserved_units: inventoryEnforced ? Number(inventoryClose?.reserved_units || 0) : Number(current.inventory_reserved_units || 0),
      inventory_committed_units: inventoryEnforced ? Number(inventoryClose?.committed_units || 0) : Number(current.inventory_committed_units || 0),
      reserved_units: inventoryEnforced ? Number(inventoryClose?.committed_units || 0) : Number(current.reserved_units || 0),
      inventory_synced_at: inventoryEnforced ? new Date().toISOString() : current.inventory_synced_at,
    },
  });
  const response = { ok: true, deal_id: String(deal.deal_id), state: DealState.ClosedForJoining, replay: result.replay };
  if (!result.replay) await writeDerivedEvidence(base44.asServiceRole, current, result.transition, response);
  return response;
}

function controlStable(value: any): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(controlStable).join(",")}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${controlStable(value[key])}`).join(",")}}`;
}
function controlHex(bytes: ArrayBuffer) { return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join(""); }
async function controlEventValid(row: any) {
  if (!row?.signature) return false;
  const secret = String(Deno.env.get("ADMIN_CONTROL_INTEGRITY_SECRET") || "");
  if (secret.length < 32) throw Object.assign(new Error("admin control integrity secret unavailable"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
  const canonical = {
    event_id: String(row.event_id), flag_id: String(row.flag_id), event_type: String(row.event_type), flag_type: String(row.flag_type),
    scope_type: String(row.scope_type), scope_id: row.scope_id ? String(row.scope_id) : null,
    requested_by_user_id: String(row.requested_by_user_id), approved_by_user_id: String(row.approved_by_user_id),
    created_at: String(row.created_at), expires_at: row.expires_at ? String(row.expires_at) : null, reason: row.reason ? String(row.reason) : null,
    activation_event_id: row.activation_event_id ? String(row.activation_event_id) : null,
    activation_signature: row.activation_signature ? String(row.activation_signature) : null,
    signature_version: String(row.signature_version || "hmac-sha256-v1")
  };
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const expected = controlHex(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(controlStable(canonical))));
  return expected === String(row.signature);
}
function controlScopeMatches(event: any, deal: any) {
  const scope = String(event.scope_type || "global");
  const id = String(event.scope_id || "");
  return scope === "global" || (scope === "deal" && id === String(deal.deal_id)) || (scope === "seller" && id === String(deal.seller_id || ""));
}
async function activeControlFlag(base44: any, flagType: string, deal: any) {
  const events = await base44.asServiceRole.entities.AdminControlAudit.filter({ flag_type: flagType }, "-created_at", 1000).catch(() => []);
  const now = Date.now();
  for (const activation of events || []) {
    if (String(activation.event_type) !== "activation_approved") continue;
    if (String(activation.requested_by_user_id) === String(activation.approved_by_user_id)) continue;
    if (!controlScopeMatches(activation, deal)) continue;
    const expiry = Date.parse(String(activation.expires_at || ""));
    if (!Number.isFinite(expiry) || expiry <= now) continue;
    if (!(await controlEventValid(activation))) continue;
    let released = false;
    for (const release of events || []) {
      if (String(release.event_type) !== "release_approved" || String(release.flag_id) !== String(activation.flag_id)) continue;
      if (String(release.requested_by_user_id) === String(release.approved_by_user_id)) continue;
      if (String(release.activation_event_id || "") !== String(activation.event_id)) continue;
      if (String(release.activation_signature || "") !== String(activation.signature)) continue;
      if (await controlEventValid(release)) { released = true; break; }
    }
    if (!released) return activation;
  }
  return null;
}

async function syncParticipantProjection(admin: any, dealId: string, reservation: any, fromBuyer: string, toBuyer: string, fromMoney: string, toMoney: string, action: string, requestId: string, idempotencyKey: string, createdAt: string) {
  const participantId = String(reservation.participant_id || "");
  if (!participantId) return;
  const participant = (await admin.entities.Participant.filter({ participant_id: participantId, deal_id: dealId }, "-created_date", 1).catch(() => []))?.[0];
  if (!participant) return;
  const journal = Array.isArray(participant.transition_journal) ? participant.transition_journal : [];
  const buyerTransition = { state_type: "buyer_state", from_state: fromBuyer, to_state: toBuyer, action_name: action, request_id: requestId, idempotency_key: idempotencyKey, created_at: createdAt, payload: {} };
  const moneyTransition = { state_type: "money_state", from_state: fromMoney, to_state: toMoney, action_name: action, request_id: requestId, idempotency_key: idempotencyKey, created_at: createdAt, payload: {} };
  await admin.entities.Participant.updateMany(
    { participant_id: participantId, deal_id: dealId, buyer_state: fromBuyer, money_state: fromMoney },
    { $set: { buyer_state: toBuyer, money_state: toMoney, transition_journal: [...journal, buyerTransition, moneyTransition] } },
  ).catch(() => undefined);
}

async function recordUnresolvedPaymentAttempts(admin: any, deal: any, sourceEventUuid: string, phase: "charge" | "recovery", resultMap: Map<string, any>, recordedAt: string) {
  const attemptType = phase === "charge" ? "charge_start" : "recovery";
  const batchHasUnknown = [...resultMap.values()].some((result) => String(result?.result_class || "") === "unknown");
  for (const [participantId, result] of resultMap.entries()) {
    if (!batchHasUnknown && !["unknown", "temporary_fail"].includes(String(result?.result_class || ""))) continue;
    const key = `${phase}-attempt:${sourceEventUuid}:${participantId}`;
    const prior = await admin.entities.PaymentAttempt.filter({ deal_id: String(deal.deal_id), participant_id: participantId, idempotency_key: key }, "-started_at", 1).catch(() => []);
    if (prior?.[0]) continue;
    await admin.entities.PaymentAttempt.create({
      attempt_id: crypto.randomUUID(),
      participant_id: participantId,
      deal_id: String(deal.deal_id),
      attempt_type: attemptType,
      idempotency_key: key,
      correlation_id: result?.correlation_id || `${phase}:${participantId}`,
      result_class: String(result?.result_class || "unknown"),
      provider_reference: result?.provider_reference || null,
      provider_event_type: result?.provider_event_type || null,
      error_code: result?.error_code || null,
      error_message: result?.error_message || null,
      started_at: recordedAt,
      completed_at: recordedAt,
    }).catch(() => undefined);
  }
}

async function scheduleUnknownPaymentReconcile(base44: any, deal: any, sourceEventUuid: string, phase: "charge" | "recovery", resultMap: Map<string, any>, recordedAt: string) {
  const hasUnknown = [...resultMap.values()].some((result) => String(result?.result_class || "") === "unknown");
  if (!hasUnknown) return null;
  const unknownParticipantIds = [...resultMap.entries()].filter(([, result]) => ["unknown", "temporary_fail"].includes(String(result?.result_class || ""))).map(([participantId]) => participantId);
  const jobKey = `payment-reconcile:${phase}:${sourceEventUuid}`;
  const embedded = Array.isArray(deal.payment_reconcile_jobs) ? [...deal.payment_reconcile_jobs] : [];
  let job = embedded.find((candidate: any) => String(candidate?.job_key || "") === jobKey) || null;
  if (!job) {
    const deadlineAt = String(deal.completion_window_until || "");
    if (!deadlineAt || !Number.isFinite(Date.parse(deadlineAt))) throw Object.assign(new Error("completion deadline missing for UNKNOWN reconciliation"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
    job = {
      job_id: crypto.randomUUID(),
      job_key: jobKey,
      deal_id: String(deal.deal_id),
      source_event_uuid: sourceEventUuid,
      phase,
      status: "pending",
      unknown_participant_ids: unknownParticipantIds,
      known_results: [...resultMap.entries()].filter(([, result]) => ["success", "permanent_fail"].includes(String(result?.result_class || ""))).map(([participant_id, result]) => ({ participant_id, ...result })),
      available_at: new Date(Date.now() + 30_000).toISOString(),
      deadline_at: deadlineAt,
      attempt_count: 0,
      max_attempts: 3,
      last_error: "provider_outcome_unknown",
      created_at: recordedAt,
      updated_at: recordedAt,
    };
    const nextOutbox = Array.isArray(deal.outbox_events) ? [...deal.outbox_events] : [];
    const sourceIndex = nextOutbox.findIndex((event: any) => String(event?.event_uuid || "") === sourceEventUuid);
    if (sourceIndex >= 0) nextOutbox[sourceIndex] = { ...nextOutbox[sourceIndex], status: "sent", processed_at: recordedAt, last_error: "provider_outcome_unknown_reconcile_required" };
    const updated = await base44.asServiceRole.entities.Deal.updateMany(
      { deal_id: String(deal.deal_id), state: String(deal.state || "") },
      { $set: { outbox_events: nextOutbox }, $addToSet: { payment_reconcile_jobs: job } },
    );
    if (Number(updated?.updated || 0) !== 1) {
      const latest = (await base44.asServiceRole.entities.Deal.filter({ deal_id: String(deal.deal_id) }, "-created_date", 1).catch(() => []))?.[0];
      job = (Array.isArray(latest?.payment_reconcile_jobs) ? latest.payment_reconcile_jobs : []).find((candidate: any) => String(candidate?.job_key || "") === jobKey) || null;
      if (!job) throw Object.assign(new Error("UNKNOWN reconcile job could not be persisted"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
    }
    await base44.asServiceRole.entities.OutboxEvent.updateMany({ event_uuid: sourceEventUuid }, { $set: { status: "sent", processed_at: recordedAt, last_error: "provider_outcome_unknown_reconcile_required" } }).catch(() => undefined);
  }
  const prior = await base44.asServiceRole.entities.PaymentReconcileJob.filter({ job_key: jobKey }, "-created_at", 1).catch(() => []);
  if (!prior?.[0]) await base44.asServiceRole.entities.PaymentReconcileJob.create(job).catch(() => undefined);
  return job;
}

function parseProviderResults(rawResults: any[]) {
  const resultMap = new Map<string, any>();
  for (const raw of rawResults) {
    const participantId = String(raw?.participant_id || "").trim();
    if (!validUuid(participantId)) throw Object.assign(new Error("participant_id must be a valid UUID"), { status: 400, code: ErrorCode.InvalidInput });
    if (resultMap.has(participantId)) throw Object.assign(new Error(`duplicate result for participant ${participantId}`), { status: 400, code: ErrorCode.InvalidInput });
    const resultClass = String(raw?.result_class || "").trim();
    if (!["success", "permanent_fail", "temporary_fail", "unknown"].includes(resultClass)) throw Object.assign(new Error(`invalid result_class for participant ${participantId}`), { status: 400, code: ErrorCode.InvalidInput });
    resultMap.set(participantId, {
      result_class: resultClass,
      provider_reference: raw?.provider_reference ? String(raw.provider_reference).slice(0, 500) : null,
      provider_event_type: raw?.provider_event_type ? String(raw.provider_event_type).slice(0, 160) : null,
      error_code: raw?.error_code ? String(raw.error_code).slice(0, 160) : null,
      error_message: raw?.error_message ? String(raw.error_message).slice(0, 1000) : null,
      correlation_id: raw?.correlation_id ? String(raw.correlation_id).slice(0, 300) : null,
      attempt_guard_key: raw?.attempt_guard_key ? String(raw.attempt_guard_key).slice(0, 300) : null,
    });
  }
  return resultMap;
}

async function applyChargeResults(base44: any, user: any, deal: any, body: any, requestId: string, idempotencyKey: string) {
  await assertCompletionWindowIntegrity(deal);
  if (String(user?.role || "") !== "admin") throw Object.assign(new Error("admin worker authority required"), { status: 403, code: ErrorCode.ForbiddenAction });
  if (String(deal.state || "") !== DealState.Charging) {
    if (String(deal.state || "") === DealState.CompletionWindow && String(deal.last_transition_key || "") === idempotencyKey) {
      return { ok: true, deal_id: deal.deal_id, state: DealState.CompletionWindow, completion_window_until: deal.completion_window_until || null, replay: true };
    }
    throw Object.assign(new Error("deal is not Charging"), { status: 409, code: ErrorCode.IllegalStateTransition });
  }
  const completionWindowUntil = String(deal.completion_window_until || "");
  const completionMs = Date.parse(completionWindowUntil);
  if (!Number.isFinite(completionMs)) throw Object.assign(new Error("charging.start did not establish completion_window_until"), { status: 409, code: ErrorCode.IllegalStateTransition });
  const sourceEventUuid = String(body?.source_event_uuid || "").trim();
  if (!validUuid(sourceEventUuid)) throw Object.assign(new Error("source_event_uuid must be a valid UUID"), { status: 400, code: ErrorCode.InvalidInput });
  const reconcileTimeoutResolution = body?.reconcile_timeout_resolution === true;
  if (reconcileTimeoutResolution) {
    const jobs = Array.isArray(deal.payment_reconcile_jobs) ? deal.payment_reconcile_jobs : [];
    const reconcileJob = jobs.find((job: any) => String(job?.source_event_uuid || "") === sourceEventUuid && String(job?.phase || "") === "charge" && String(job?.status || "") === "pending");
    if (!reconcileJob || Date.now() < Date.parse(String(reconcileJob.deadline_at || ""))) throw Object.assign(new Error("charge timeout reconciliation is not authorized"), { status: 403, code: ErrorCode.ForbiddenAction });
  }
  const resultMap = parseProviderResults(Array.isArray(body?.results) ? body.results : []);
  const embeddedEvents = Array.isArray(deal.outbox_events) ? [...deal.outbox_events] : [];
  const sourceIndex = embeddedEvents.findIndex((event: any) => String(event?.event_uuid || "") === sourceEventUuid && String(event?.event_type || "") === "charge_deal");
  if (sourceIndex < 0) throw Object.assign(new Error("source charge event missing"), { status: 409, code: ErrorCode.IllegalStateTransition });
  const reservations = Array.isArray(deal.join_reservations) ? deal.join_reservations : [];
  if (!reservations.length || resultMap.size !== reservations.length) throw Object.assign(new Error("charge results must cover every participant exactly once"), { status: 400, code: ErrorCode.InvalidInput });
  const nowIso = new Date().toISOString();
  for (const reservation of reservations) {
    const participantId = String(reservation?.participant_id || "");
    if (String(reservation?.buyer_state || "") !== BuyerState.ChargingAttempt || String(reservation?.money_state || "") !== MoneyState.ChargeAttempt) throw Object.assign(new Error(`participant ${participantId} is not charging`), { status: 409, code: ErrorCode.IllegalStateTransition });
    const result = resultMap.get(participantId);
    if (!result) throw Object.assign(new Error(`missing result for ${participantId}`), { status: 400, code: ErrorCode.InvalidInput });
    if (!reconcileTimeoutResolution) {
      const guardKey = String(result.attempt_guard_key || "");
      const participant = (await base44.asServiceRole.entities.Participant.filter({ participant_id: participantId, deal_id: String(deal.deal_id) }, "-created_date", 1).catch(() => []))?.[0];
      const guardKeys = Array.isArray(participant?.payment_retry_slot_keys) ? participant.payment_retry_slot_keys.map(String) : [];
      if (!guardKey || !guardKeys.includes(guardKey)) throw Object.assign(new Error(`payment attempt guard evidence missing for ${participantId}`), { status: 403, code: ErrorCode.ForbiddenAction });
    }
  }
  await recordUnresolvedPaymentAttempts(base44.asServiceRole, deal, sourceEventUuid, "charge", resultMap, nowIso);
  if ([...resultMap.values()].some((result) => String(result?.result_class || "") === "unknown")) {
    await scheduleUnknownPaymentReconcile(base44, deal, sourceEventUuid, "charge", resultMap, nowIso);
    throw Object.assign(new Error("provider outcome UNKNOWN; reconcile job scheduled without visible State change"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
  }
  if ([...resultMap.values()].some((result) => String(result?.result_class || "") === "temporary_fail")) {
    throw Object.assign(new Error("provider temporarily unavailable; source job remains retryable"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
  }
  const chargeMoneyEvents = reservations.flatMap((reservation: any) => {
    const providerResult = resultMap.get(String(reservation?.participant_id || ""));
    if (providerResult?.result_class !== "success") return [];
    return [buildFinalMoneyEvent({ deal, reservation, eventType: "charge_captured", sourceEventUuid, providerResult, providerCode: body?.provider_code || reservation?.authorization_provider || null, recordedAt: nowIso })];
  });
  const canonicalMoneyLedger = appendCanonicalMoneyEvents(deal.money_ledger_events, chargeMoneyEvents);
  let recoveryRequired = false;
  const attemptRows: any[] = [];
  const nextReservations = reservations.map((reservation: any) => {
    const participantId = String(reservation.participant_id);
    const providerResult = resultMap.get(participantId);
    const success = providerResult.result_class === "success";
    if (!success) recoveryRequired = true;
    const buyerTo = success ? BuyerState.ChargedSuccess : BuyerState.ChargeFailedCompletion;
    const moneyTo = success ? MoneyState.ChargedSuccess : MoneyState.ChargeFailedRecovery;
    assertBuyerTransition(BuyerState.ChargingAttempt, buyerTo);
    assertMoneyTransition(MoneyState.ChargeAttempt, moneyTo);
    const attempt = {
      attempt_id: crypto.randomUUID(), participant_id: participantId, deal_id: String(deal.deal_id), attempt_type: reconcileTimeoutResolution ? "reconcile" : "charge_start",
      idempotency_key: reconcileTimeoutResolution ? `reconcile-timeout:${sourceEventUuid}:${participantId}` : `charge-attempt:${sourceEventUuid}:${participantId}`, correlation_id: providerResult.correlation_id || `charge:${participantId}`,
      result_class: providerResult.result_class, provider_reference: providerResult.provider_reference, provider_event_type: providerResult.provider_event_type,
      error_code: providerResult.error_code, error_message: providerResult.error_message, started_at: nowIso, completed_at: nowIso,
    };
    attemptRows.push(attempt);
    const buyerTransition = { state_type: "buyer_state", from_state: BuyerState.ChargingAttempt, to_state: buyerTo, action_name: Action.ChargingStart, request_id: requestId, idempotency_key: attempt.idempotency_key, created_at: nowIso, payload: { result_class: providerResult.result_class, provider_reference: providerResult.provider_reference } };
    const moneyTransition = { state_type: "money_state", from_state: MoneyState.ChargeAttempt, to_state: moneyTo, action_name: Action.ChargingStart, request_id: requestId, idempotency_key: attempt.idempotency_key, created_at: nowIso, payload: { result_class: providerResult.result_class, provider_reference: providerResult.provider_reference } };
    return { ...reservation, buyer_state: buyerTo, money_state: moneyTo, payment_attempts: [...(Array.isArray(reservation?.payment_attempts) ? reservation.payment_attempts : []), attempt], transition_journal: [...(Array.isArray(reservation?.transition_journal) ? reservation.transition_journal : []), buyerTransition, moneyTransition] };
  });

  embeddedEvents[sourceIndex] = { ...embeddedEvents[sourceIndex], status: "sent", processed_at: nowIso, last_error: null };
  const finalizeEvent = { event_uuid: crypto.randomUUID(), aggregate_type: "deal", aggregate_id: String(deal.deal_id), event_type: "finalize_deal", status: "pending", payload: { deal_id: String(deal.deal_id) }, idempotency_key: `finalize-deal:${deal.deal_id}`, available_at: completionWindowUntil, attempt_count: 0, max_attempts: 4, created_at: nowIso };
  embeddedEvents.push(finalizeEvent);
  let recoveryEvent: any = null;
  if (recoveryRequired) {
    recoveryEvent = { event_uuid: crypto.randomUUID(), aggregate_type: "deal", aggregate_id: String(deal.deal_id), event_type: "recovery_deal", status: "pending", payload: { deal_id: String(deal.deal_id) }, idempotency_key: `recovery-deal:${deal.deal_id}`, available_at: nowIso, attempt_count: 0, max_attempts: 4, created_at: nowIso };
    embeddedEvents.push(recoveryEvent);
  }
  const result = await transitionDealDocument({ admin: base44.asServiceRole, deal, fromState: DealState.Charging, toState: DealState.CompletionWindow, action: Action.ChargingStart, requestId, idempotencyKey, payload: { source_event_uuid: sourceEventUuid, recovery_required: recoveryRequired }, extraSet: { join_reservations: nextReservations, outbox_events: embeddedEvents, money_ledger_events: canonicalMoneyLedger } });
  const response = { ok: true, deal_id: String(deal.deal_id), state: DealState.CompletionWindow, completion_window_until: completionWindowUntil, recovery_required: recoveryRequired, finalize_event_uuid: finalizeEvent.event_uuid, recovery_event_uuid: recoveryEvent?.event_uuid || null, replay: result.replay };
  if (!result.replay) {
    await writeDerivedEvidence(base44.asServiceRole, deal, result.transition, response);
    await base44.asServiceRole.entities.OutboxEvent.updateMany({ event_uuid: sourceEventUuid, event_type: "charge_deal" }, { $set: { status: "sent", processed_at: nowIso, last_error: "" } }).catch(() => undefined);
    await base44.asServiceRole.entities.OutboxEvent.create(finalizeEvent).catch(() => undefined);
    if (recoveryEvent) await base44.asServiceRole.entities.OutboxEvent.create(recoveryEvent).catch(() => undefined);
    for (const attempt of attemptRows) await base44.asServiceRole.entities.PaymentAttempt.create(attempt).catch(() => undefined);
    await projectMoneyEvents(base44.asServiceRole, chargeMoneyEvents);
    for (const reservation of nextReservations) {
      await syncParticipantProjection(base44.asServiceRole, String(deal.deal_id), reservation, BuyerState.ChargingAttempt, String(reservation.buyer_state), MoneyState.ChargeAttempt, String(reservation.money_state), Action.ChargingStart, requestId, String(reservation.payment_attempts?.at(-1)?.idempotency_key || idempotencyKey), nowIso);
      if (String(reservation.money_state) === MoneyState.ChargedSuccess) {
        await enqueueBuyerNotifications(base44.asServiceRole, deal, reservation, "buyer_charged", "buyer_charged_he", { deal_title: String(deal.title || ""), hold_total: Number(reservation.hold_total || 0), completion_window_until: completionWindowUntil }, `${sourceEventUuid}:charged`);
      }
    }
  }
  return response;
}

async function applyRecoveryResults(base44: any, user: any, deal: any, body: any, requestId: string, idempotencyKey: string) {
  await assertCompletionWindowIntegrity(deal);
  if (String(user?.role || "") !== "admin") throw Object.assign(new Error("admin worker authority required"), { status: 403, code: ErrorCode.ForbiddenAction });
  const reconcileTimeoutResolution = body?.reconcile_timeout_resolution === true;
  const sourceEventUuid = String(body?.source_event_uuid || "").trim();
  if (!validUuid(sourceEventUuid)) throw Object.assign(new Error("source_event_uuid must be a valid UUID"), { status: 400, code: ErrorCode.InvalidInput });
  if (reconcileTimeoutResolution) {
    const jobs = Array.isArray(deal.payment_reconcile_jobs) ? deal.payment_reconcile_jobs : [];
    const reconcileJob = jobs.find((job: any) => String(job?.source_event_uuid || "") === sourceEventUuid && String(job?.phase || "") === "recovery" && String(job?.status || "") === "pending");
    if (!reconcileJob || Date.now() < Date.parse(String(reconcileJob.deadline_at || ""))) throw Object.assign(new Error("recovery timeout reconciliation is not authorized"), { status: 403, code: ErrorCode.ForbiddenAction });
  }
  const resultMap = parseProviderResults(Array.isArray(body?.results) ? body.results : []);
  const outboxEvents = Array.isArray(deal.outbox_events) ? [...deal.outbox_events] : [];
  const sourceIndex = outboxEvents.findIndex((event: any) => String(event?.event_uuid || "") === sourceEventUuid && String(event?.event_type || "") === "recovery_deal");
  if (sourceIndex < 0) throw Object.assign(new Error("source recovery event missing"), { status: 409, code: ErrorCode.IllegalStateTransition });
  const reservations = Array.isArray(deal.join_reservations) ? deal.join_reservations : [];
  const eligible = reservations.filter((reservation: any) => String(reservation?.buyer_state || "") === BuyerState.ChargeFailedCompletion && String(reservation?.money_state || "") === MoneyState.ChargeFailedRecovery);
  assertRecoveryAllowed(String(deal.state || ""), deal.completion_window_until, eligible.length, Date.now(), reconcileTimeoutResolution);
  const nowIso = new Date().toISOString();
  if (resultMap.size !== eligible.length) throw Object.assign(new Error("recovery results must cover every eligible participant exactly once"), { status: 400, code: ErrorCode.InvalidInput });
  for (const reservation of eligible) {
    const participantId = String(reservation.participant_id || "");
    const providerResult = resultMap.get(participantId);
    if (!providerResult) throw Object.assign(new Error(`missing recovery result for ${participantId}`), { status: 400, code: ErrorCode.InvalidInput });
    if (!reconcileTimeoutResolution) {
      const guardKey = String(providerResult.attempt_guard_key || "");
      const participant = (await base44.asServiceRole.entities.Participant.filter({ participant_id: participantId, deal_id: String(deal.deal_id) }, "-created_date", 1).catch(() => []))?.[0];
      const guardKeys = Array.isArray(participant?.payment_retry_slot_keys) ? participant.payment_retry_slot_keys.map(String) : [];
      if (!guardKey || !guardKeys.includes(guardKey)) throw Object.assign(new Error(`payment attempt guard evidence missing for recovery participant ${participantId}`), { status: 403, code: ErrorCode.ForbiddenAction });
    }
  }
  await recordUnresolvedPaymentAttempts(base44.asServiceRole, deal, sourceEventUuid, "recovery", resultMap, nowIso);
  if ([...resultMap.values()].some((result) => String(result?.result_class || "") === "unknown")) {
    await scheduleUnknownPaymentReconcile(base44, deal, sourceEventUuid, "recovery", resultMap, nowIso);
    throw Object.assign(new Error("recovery provider outcome UNKNOWN; reconcile job scheduled without visible State change"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
  }
  if ([...resultMap.values()].some((result) => String(result?.result_class || "") === "temporary_fail")) {
    throw Object.assign(new Error("recovery provider temporarily unavailable; source job remains retryable"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
  }

  const recoveryMoneyEvents = eligible.flatMap((reservation: any) => {
    const providerResult = resultMap.get(String(reservation?.participant_id || ""));
    if (providerResult?.result_class !== "success") return [];
    return [buildFinalMoneyEvent({ deal, reservation, eventType: "recovery_captured", sourceEventUuid, providerResult, providerCode: body?.provider_code || reservation?.authorization_provider || null, recordedAt: nowIso })];
  });
  const canonicalMoneyLedger = appendCanonicalMoneyEvents(deal.money_ledger_events, recoveryMoneyEvents);
  const attemptRows: any[] = [];
  const nextReservations = reservations.map((reservation: any) => {
    const participantId = String(reservation?.participant_id || "");
    const providerResult = resultMap.get(participantId);
    if (!providerResult) return reservation;
    const success = providerResult.result_class === "success";
    const buyerTo = success ? BuyerState.Recovered : BuyerState.Dropped;
    const moneyTo = success ? MoneyState.RecoveredCharge : MoneyState.AuthReleased;
    assertBuyerTransition(BuyerState.ChargeFailedCompletion, buyerTo);
    assertMoneyTransition(MoneyState.ChargeFailedRecovery, moneyTo);
    const attempt = { attempt_id: crypto.randomUUID(), participant_id: participantId, deal_id: String(deal.deal_id), attempt_type: reconcileTimeoutResolution ? "reconcile" : "recovery", idempotency_key: reconcileTimeoutResolution ? `reconcile-timeout:${sourceEventUuid}:${participantId}` : `recovery-attempt:${sourceEventUuid}:${participantId}`, correlation_id: providerResult.correlation_id || `recovery:${participantId}`, result_class: providerResult.result_class, provider_reference: providerResult.provider_reference, provider_event_type: providerResult.provider_event_type, error_code: providerResult.error_code, error_message: providerResult.error_message, started_at: nowIso, completed_at: nowIso };
    attemptRows.push(attempt);
    const buyerTransition = { state_type: "buyer_state", from_state: BuyerState.ChargeFailedCompletion, to_state: buyerTo, action_name: Action.ChargingRecovery, request_id: requestId, idempotency_key: attempt.idempotency_key, created_at: nowIso, payload: { result_class: providerResult.result_class, provider_reference: providerResult.provider_reference } };
    const moneyTransition = { state_type: "money_state", from_state: MoneyState.ChargeFailedRecovery, to_state: moneyTo, action_name: Action.ChargingRecovery, request_id: requestId, idempotency_key: attempt.idempotency_key, created_at: nowIso, payload: { result_class: providerResult.result_class, provider_reference: providerResult.provider_reference } };
    return { ...reservation, buyer_state: buyerTo, money_state: moneyTo, payment_attempts: [...(Array.isArray(reservation?.payment_attempts) ? reservation.payment_attempts : []), attempt], transition_journal: [...(Array.isArray(reservation?.transition_journal) ? reservation.transition_journal : []), buyerTransition, moneyTransition] };
  });
  outboxEvents[sourceIndex] = { ...outboxEvents[sourceIndex], status: "sent", processed_at: nowIso, last_error: null };
  const updated = await base44.asServiceRole.entities.Deal.updateMany({ deal_id: String(deal.deal_id), state: DealState.CompletionWindow, completion_window_until: String(deal.completion_window_until) }, { $set: { join_reservations: nextReservations, outbox_events: outboxEvents, money_ledger_events: canonicalMoneyLedger, last_transition_key: idempotencyKey } });
  if (Number(updated?.updated || 0) !== 1) throw Object.assign(new Error("recovery conditional update lost"), { status: 409, code: ErrorCode.IllegalStateTransition });
  const response = { ok: true, deal_id: String(deal.deal_id), state: DealState.CompletionWindow, recovered: nextReservations.filter((reservation: any) => reservation.buyer_state === BuyerState.Recovered).length, dropped: nextReservations.filter((reservation: any) => reservation.buyer_state === BuyerState.Dropped).length, replay: false };
  await base44.asServiceRole.entities.IdempotencyRecord.create({ owner_user_id: String(deal.owner_user_id || ""), entity_type: "deal", entity_id: String(deal.deal_id), action_name: Action.ChargingRecovery, idempotency_key: idempotencyKey, response_json: response }).catch(() => undefined);
  await base44.asServiceRole.entities.OutboxEvent.updateMany({ event_uuid: sourceEventUuid, event_type: "recovery_deal" }, { $set: { status: "sent", processed_at: nowIso, last_error: "" } }).catch(() => undefined);
  for (const attempt of attemptRows) await base44.asServiceRole.entities.PaymentAttempt.create(attempt).catch(() => undefined);
  await projectMoneyEvents(base44.asServiceRole, recoveryMoneyEvents);
  for (const reservation of nextReservations) {
    if (!resultMap.has(String(reservation.participant_id))) continue;
    await syncParticipantProjection(base44.asServiceRole, String(deal.deal_id), reservation, BuyerState.ChargeFailedCompletion, String(reservation.buyer_state), MoneyState.ChargeFailedRecovery, String(reservation.money_state), Action.ChargingRecovery, requestId, String(reservation.payment_attempts?.at(-1)?.idempotency_key || idempotencyKey), nowIso);
    if (String(reservation.money_state) === MoneyState.RecoveredCharge) {
      await enqueueBuyerNotifications(base44.asServiceRole, deal, reservation, "buyer_charge_recovered", "buyer_charge_recovered_he", { deal_title: String(deal.title || ""), hold_total: Number(reservation.hold_total || 0), completion_window_until: deal.completion_window_until || null }, `${sourceEventUuid}:recovered`);
    }
  }
  return response;
}

async function syncParticipantToReservation(admin: any, dealId: string, before: any, after: any) {
  const participantId = String(after?.participant_id || before?.participant_id || "");
  if (!participantId) return;
  const participant = (await admin.entities.Participant.filter({ participant_id: participantId, deal_id: dealId }, "-created_date", 1).catch(() => []))?.[0];
  if (!participant) return;
  const beforeJournal = Array.isArray(before?.transition_journal) ? before.transition_journal : [];
  const afterJournal = Array.isArray(after?.transition_journal) ? after.transition_journal : [];
  const appended = afterJournal.slice(beforeJournal.length);
  const currentJournal = Array.isArray(participant.transition_journal) ? participant.transition_journal : [];
  await admin.entities.Participant.updateMany(
    { participant_id: participantId, deal_id: dealId, buyer_state: String(before?.buyer_state || ""), money_state: String(before?.money_state || "") },
    { $set: { buyer_state: String(after?.buyer_state || ""), money_state: String(after?.money_state || ""), transition_journal: [...currentJournal, ...appended] } },
  ).catch(() => undefined);
}

async function finalizeCharging(base44: any, user: any, deal: any, body: any, requestId: string, idempotencyKey: string) {
  await assertCompletionWindowIntegrity(deal);
  if (String(user?.role || "") !== "admin") throw Object.assign(new Error("admin worker authority required"), { status: 403, code: ErrorCode.ForbiddenAction });
  if ([DealState.Completed, DealState.Failed].includes(String(deal.state || "") as any)) {
    if (String(deal.last_transition_key || "") === idempotencyKey) return { ok: true, deal_id: deal.deal_id, state: deal.state, replay: true };
    throw Object.assign(new Error("deal is already terminal"), { status: 409, code: ErrorCode.IllegalStateTransition });
  }
  assertFinalizeAllowed(String(deal.state || ""), deal.completion_window_until);
  const sourceEventUuid = String(body?.source_event_uuid || "").trim();
  if (!validUuid(sourceEventUuid)) throw Object.assign(new Error("source_event_uuid must be a valid UUID"), { status: 400, code: ErrorCode.InvalidInput });
  const reservations = Array.isArray(deal.join_reservations) ? deal.join_reservations : [];
  const capturedUnits = reservations.reduce((sum: number, reservation: any) => [MoneyState.ChargedSuccess, MoneyState.RecoveredCharge].includes(String(reservation?.money_state || "") as any) ? sum + Math.max(0, Number(reservation?.qty || 0)) : sum, 0);
  const threshold = Math.max(0, Number(deal.threshold_units || 0));
  const finalState = resolveFinalDealState(capturedUnits, threshold);
  const succeeded = finalState === DealState.Completed;
  const nowIso = new Date().toISOString();

  const nextReservations = reservations.map((reservation: any) => {
    const buyerFrom = String(reservation?.buyer_state || "");
    const moneyFrom = String(reservation?.money_state || "");
    const financiallySettled = [MoneyState.ChargedSuccess, MoneyState.RecoveredCharge].includes(moneyFrom as any);
    let buyerTo = buyerFrom;
    let moneyTo = moneyFrom;
    if (succeeded) {
      if (financiallySettled && [BuyerState.ChargedSuccess, BuyerState.Recovered].includes(buyerFrom as any)) buyerTo = BuyerState.DealCompleted;
      else if (buyerFrom === BuyerState.ChargeFailedCompletion && moneyFrom === MoneyState.ChargeFailedRecovery) {
        buyerTo = BuyerState.Dropped;
        moneyTo = MoneyState.AuthReleased;
      }
    } else {
      if (buyerFrom !== BuyerState.DealFailed && buyerFrom !== BuyerState.DealCompleted) buyerTo = BuyerState.DealFailed;
      if (moneyFrom === MoneyState.ChargeFailedRecovery) moneyTo = MoneyState.AuthReleased;
    }
    if (buyerTo === buyerFrom && moneyTo === moneyFrom) return reservation;
    const nextJournal = [...(Array.isArray(reservation?.transition_journal) ? reservation.transition_journal : [])];
    const transitionPayload = { captured_units: capturedUnits, threshold_units: threshold };
    if (buyerTo !== buyerFrom) {
      assertBuyerTransition(buyerFrom, buyerTo);
      nextJournal.push({ state_type: "buyer_state", from_state: buyerFrom, to_state: buyerTo, action_name: Action.ChargingFinalize, request_id: requestId, idempotency_key: `finalize-buyer:${deal.deal_id}:${reservation.participant_id}`, created_at: nowIso, payload: transitionPayload });
    }
    if (moneyTo !== moneyFrom) {
      assertMoneyTransition(moneyFrom, moneyTo);
      nextJournal.push({ state_type: "money_state", from_state: moneyFrom, to_state: moneyTo, action_name: Action.ChargingFinalize, request_id: requestId, idempotency_key: `finalize-money:${deal.deal_id}:${reservation.participant_id}`, created_at: nowIso, payload: transitionPayload });
    }
    return { ...reservation, buyer_state: buyerTo, money_state: moneyTo, transition_journal: nextJournal };
  });

  const outboxEvents = Array.isArray(deal.outbox_events) ? [...deal.outbox_events] : [];
  const sourceIndex = outboxEvents.findIndex((event: any) => String(event?.event_uuid || "") === sourceEventUuid && String(event?.event_type || "") === "finalize_deal");
  if (sourceIndex < 0) throw Object.assign(new Error("source finalize event missing"), { status: 409, code: ErrorCode.IllegalStateTransition });
  outboxEvents[sourceIndex] = { ...outboxEvents[sourceIndex], status: "sent", processed_at: nowIso, last_error: null };
  let refundEvent: any = null;
  if (!succeeded) {
    refundEvent = { event_uuid: crypto.randomUUID(), aggregate_type: "deal", aggregate_id: String(deal.deal_id), event_type: "refund_issue", status: "pending", payload: { deal_id: String(deal.deal_id) }, idempotency_key: `refund-issue:${deal.deal_id}`, available_at: nowIso, attempt_count: 0, max_attempts: 4, created_at: nowIso };
    outboxEvents.push(refundEvent);
  }
  const result = await transitionDealDocument({ admin: base44.asServiceRole, deal, fromState: DealState.CompletionWindow, toState: finalState, action: Action.ChargingFinalize, requestId, idempotencyKey, payload: { captured_units: capturedUnits, threshold_units: threshold }, extraSet: { join_reservations: nextReservations, outbox_events: outboxEvents } });
  const response = { ok: true, deal_id: String(deal.deal_id), state: finalState, captured_units: capturedUnits, threshold_units: threshold, refund_event_uuid: refundEvent?.event_uuid || null, replay: result.replay };
  if (!result.replay) {
    await writeDerivedEvidence(base44.asServiceRole, deal, result.transition, response);
    await base44.asServiceRole.entities.OutboxEvent.updateMany({ event_uuid: sourceEventUuid, event_type: "finalize_deal" }, { $set: { status: "sent", processed_at: nowIso, last_error: "" } }).catch(() => undefined);
    if (refundEvent) await base44.asServiceRole.entities.OutboxEvent.create(refundEvent).catch(() => undefined);
    for (let index = 0; index < reservations.length; index += 1) {
      const before = reservations[index];
      const after = nextReservations[index];
      if (before !== after) await syncParticipantToReservation(base44.asServiceRole, String(deal.deal_id), before, after);
      const buyerEvent = succeeded ? "buyer_deal_completed" : "buyer_deal_failed";
      const buyerTemplate = succeeded ? "buyer_deal_completed_he" : "buyer_deal_failed_he";
      await enqueueBuyerNotifications(base44.asServiceRole, deal, after, buyerEvent, buyerTemplate, { deal_title: String(deal.title || ""), final_state: finalState, captured_units: capturedUnits, threshold_units: threshold }, `${sourceEventUuid}:final`);
    }
    await enqueueSellerNotifications(base44.asServiceRole, deal, succeeded ? "seller_deal_completed" : "seller_deal_failed", succeeded ? "seller_deal_completed_he" : "seller_deal_failed_he", { deal_title: String(deal.title || ""), final_state: finalState, captured_units: capturedUnits, threshold_units: threshold }, `${sourceEventUuid}:seller-final`);
  }
  return response;
}

async function prepareCharging(base44: any, deal: any, requestId: string, idempotencyKey: string) {
  await assertCriticalTermsIntegrity(deal);
  if (String(deal.state || "") !== DealState.ClosedForJoining) {
    if (String(deal.state || "") === DealState.ReadyForCharging && String(deal.last_transition_key || "") === idempotencyKey) {
      return { ok: true, deal_id: deal.deal_id, state: DealState.ReadyForCharging, replay: true };
    }
    throw Object.assign(new Error("deal is not ClosedForJoining"), { status: 409, code: ErrorCode.IllegalStateTransition });
  }
  if (await activeControlFlag(base44, "pause_charging_emergency", deal)) {
    throw Object.assign(new Error("charging preparation is paused by admin control"), { status: 403, code: ErrorCode.ForbiddenAction });
  }
  const reservations = Array.isArray(deal.join_reservations) ? deal.join_reservations : [];
  const now = new Date().toISOString();
  const prepared = reservations.map((reservation: any) => {
    const fromBuyer = String(reservation?.buyer_state || "");
    const fromMoney = String(reservation?.money_state || "");
    assertBuyerTransition(fromBuyer, BuyerState.LockedIn);
    assertMoneyTransition(fromMoney, MoneyState.AuthLocked);
    const buyerTransition = { state_type: "buyer_state", from_state: fromBuyer, to_state: BuyerState.LockedIn, action_name: Action.DealPrepareCharging, request_id: requestId, idempotency_key: idempotencyKey, created_at: now, payload: {} };
    const moneyTransition = { state_type: "money_state", from_state: fromMoney, to_state: MoneyState.AuthLocked, action_name: Action.DealPrepareCharging, request_id: requestId, idempotency_key: idempotencyKey, created_at: now, payload: {} };
    return { ...reservation, buyer_state: BuyerState.LockedIn, money_state: MoneyState.AuthLocked, transition_journal: [...(Array.isArray(reservation?.transition_journal) ? reservation.transition_journal : []), buyerTransition, moneyTransition] };
  });
  const result = await transitionDealDocument({
    admin: base44.asServiceRole,
    deal,
    fromState: DealState.ClosedForJoining,
    toState: DealState.ReadyForCharging,
    action: Action.DealPrepareCharging,
    requestId,
    idempotencyKey,
    payload: { participants_locked: prepared.length },
    extraSet: { join_reservations: prepared },
  });
  const response = { ok: true, deal_id: String(deal.deal_id), state: DealState.ReadyForCharging, participants_locked: prepared.length, replay: result.replay };
  if (!result.replay) {
    await writeDerivedEvidence(base44.asServiceRole, deal, result.transition, response);
    for (const reservation of prepared) await syncParticipantProjection(base44.asServiceRole, String(deal.deal_id), reservation, BuyerState.JoinedAuthorized, BuyerState.LockedIn, MoneyState.AuthHeld, MoneyState.AuthLocked, Action.DealPrepareCharging, requestId, idempotencyKey, now);
  }
  return response;
}

async function startCharging(base44: any, deal: any, requestId: string, idempotencyKey: string) {
  await assertCriticalTermsIntegrity(deal);
  if (String(deal.state || "") === DealState.Charging && String(deal.last_transition_key || "") === idempotencyKey) {
    const existingEvent = (Array.isArray(deal.outbox_events) ? deal.outbox_events : []).find((event: any) => String(event?.idempotency_key || "") === `charge-deal:${deal.deal_id}`);
    return { ok: true, deal_id: deal.deal_id, state: DealState.Charging, event_uuid: existingEvent?.event_uuid || null, completion_window_until: deal.completion_window_until || null, replay: true };
  }
  assertChargingStartAllowed(String(deal.state || ""), deal.completion_window_until);
  if (await activeControlFlag(base44, "pause_charging_emergency", deal)) {
    throw Object.assign(new Error("charging is paused by admin control"), { status: 403, code: ErrorCode.ForbiddenAction });
  }
  const reservations = Array.isArray(deal.join_reservations) ? deal.join_reservations : [];
  const now = new Date();
  const nowIso = now.toISOString();
  const completionWindowUntil = new Date(now.getTime() + SITON_CRITICAL_TERMS.completion_window_hours * 60 * 60 * 1000).toISOString();
  const completionWindowSignature = await signCompletionWindow(deal, completionWindowUntil);
  const chargingReservations = reservations.map((reservation: any) => {
    const fromBuyer = String(reservation?.buyer_state || "");
    const fromMoney = String(reservation?.money_state || "");
    assertBuyerTransition(fromBuyer, BuyerState.ChargingAttempt);
    assertMoneyTransition(fromMoney, MoneyState.ChargeAttempt);
    const buyerTransition = { state_type: "buyer_state", from_state: fromBuyer, to_state: BuyerState.ChargingAttempt, action_name: Action.ChargingStart, request_id: requestId, idempotency_key: idempotencyKey, created_at: nowIso, payload: {} };
    const moneyTransition = { state_type: "money_state", from_state: fromMoney, to_state: MoneyState.ChargeAttempt, action_name: Action.ChargingStart, request_id: requestId, idempotency_key: idempotencyKey, created_at: nowIso, payload: {} };
    return { ...reservation, buyer_state: BuyerState.ChargingAttempt, money_state: MoneyState.ChargeAttempt, transition_journal: [...(Array.isArray(reservation?.transition_journal) ? reservation.transition_journal : []), buyerTransition, moneyTransition] };
  });
  const eventUuid = crypto.randomUUID();
  const outboxEvent = {
    event_uuid: eventUuid,
    aggregate_type: "deal",
    aggregate_id: String(deal.deal_id),
    event_type: "charge_deal",
    status: "pending",
    payload: { deal_id: String(deal.deal_id) },
    idempotency_key: `charge-deal:${deal.deal_id}`,
    available_at: nowIso,
    attempt_count: 0,
    max_attempts: 4,
    created_at: nowIso,
  };
  const result = await transitionDealDocument({
    admin: base44.asServiceRole,
    deal,
    fromState: DealState.ReadyForCharging,
    toState: DealState.Charging,
    action: Action.ChargingStart,
    requestId,
    idempotencyKey,
    payload: { outbox_event_uuid: eventUuid, completion_window_until: completionWindowUntil },
    extraSet: { join_reservations: chargingReservations, completion_window_until: completionWindowUntil, completion_window_signature: completionWindowSignature },
    extraPush: { outbox_events: outboxEvent },
  });
  const response = { ok: true, deal_id: String(deal.deal_id), state: DealState.Charging, event_uuid: eventUuid, completion_window_until: completionWindowUntil, replay: result.replay };
  if (!result.replay) {
    await writeDerivedEvidence(base44.asServiceRole, deal, result.transition, response);
    await base44.asServiceRole.entities.OutboxEvent.create(outboxEvent).catch(() => undefined);
    for (const reservation of chargingReservations) await syncParticipantProjection(base44.asServiceRole, String(deal.deal_id), reservation, BuyerState.LockedIn, BuyerState.ChargingAttempt, MoneyState.AuthLocked, MoneyState.ChargeAttempt, Action.ChargingStart, requestId, idempotencyKey, nowIso);
  }
  return response;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.InvalidInput);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (!user?.id) return fail(401, "authentication required", ErrorCode.ForbiddenAction);

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const dealId = String(body?.deal_id || "").trim();
  const action = String(body?.action || "").trim();
  const requestId = String(body?.request_id || `req:${crypto.randomUUID()}`).slice(0, 240);
  const idempotencyKey = String(body?.idempotency_key || "").trim().slice(0, 300);
  if (!validUuid(dealId) || !idempotencyKey) return fail(400, "deal_id and idempotency_key are required", ErrorCode.InvalidInput);
  if (![Action.DealPublish, Action.DealCloseJoining, Action.DealPrepareCharging, Action.ChargingStart, Action.ChargingRecovery, Action.ChargingFinalize].includes(action as any)) return fail(403, "action is not enabled in transition-engine", ErrorCode.ForbiddenAction);

  try {
    const deal = await readOwnedDeal(base44.asServiceRole, user, dealId);
    if (!deal) return fail(403, "deal unavailable", ErrorCode.ForbiddenAction);
    const replay = await replayRecord(base44.asServiceRole, deal, action, idempotencyKey);
    if (replay) return Response.json({ ...replay, replay: true });

    let response: any;
    if (action === Action.DealPublish) response = await publish(base44, user, deal, body, requestId, idempotencyKey);
    else if (action === Action.DealCloseJoining) response = await closeJoining(base44, deal, requestId, idempotencyKey);
    else if (action === Action.DealPrepareCharging) response = await prepareCharging(base44, deal, requestId, idempotencyKey);
    else if (action === Action.ChargingRecovery) response = await applyRecoveryResults(base44, user, deal, body, requestId, idempotencyKey);
    else if (action === Action.ChargingFinalize) response = await finalizeCharging(base44, user, deal, body, requestId, idempotencyKey);
    else if (String(body?.phase || "") === "apply_results") response = await applyChargeResults(base44, user, deal, body, requestId, idempotencyKey);
    else response = await startCharging(base44, deal, requestId, idempotencyKey);
    return Response.json(response);
  } catch (error: any) {
    const status = Number(error?.status || error?.statusCode || 500);
    const code = String(error?.code || ErrorCode.TemporarilyUnavailable);
    return fail(status >= 400 && status < 600 ? status : 500, String(error?.message || "transition failed"), code);
  }
});
