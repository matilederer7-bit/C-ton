import { ErrorCode, MoneyState } from "../../shared/constitution.ts";
export const SITON_PLATFORM_FEE_RATE = 0.08;
export const FINANCIAL_RULES_VERSION = "siton-platform-fee-v1";

export function roundMoney(value: number) {
  return Math.round((Number(value) || 0) * 100) / 100;
}

export function platformFeeVatRate() {
  const raw = String(Deno.env.get("SITON_PLATFORM_FEE_VAT_RATE") ?? "0.18").trim();
  const rate = Number(raw);
  if (!Number.isFinite(rate) || rate < 0 || rate > 1) {
    throw Object.assign(new Error("SITON_PLATFORM_FEE_VAT_RATE is invalid"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
  }
  return rate;
}

export function calculatePlatformFeeMoney(grossInput: number, sign: 1 | -1 = 1) {
  const gross = roundMoney(Math.max(0, Number(grossInput || 0)));
  const vatRate = platformFeeVatRate();
  const feeBase = gross;
  const platformFeeBase = roundMoney(feeBase * SITON_PLATFORM_FEE_RATE);
  const platformFeeVat = roundMoney(platformFeeBase * vatRate);
  const platformFeeTotal = roundMoney(platformFeeBase + platformFeeVat);
  const sellerNet = roundMoney(gross - platformFeeTotal);
  return {
    gross_amount: roundMoney(gross * sign),
    vat_amount: 0,
    fee_base_amount: roundMoney(feeBase * sign),
    platform_fee_rate: SITON_PLATFORM_FEE_RATE,
    platform_fee_vat_rate: vatRate,
    platform_fee_base_amount: roundMoney(platformFeeBase * sign),
    platform_fee_vat_amount: roundMoney(platformFeeVat * sign),
    platform_fee_total_amount: roundMoney(platformFeeTotal * sign),
    seller_net_amount: roundMoney(sellerNet * sign)
  };
}

export function buildFinalMoneyEvent(args: {
  deal: any;
  reservation: any;
  eventType: "charge_captured" | "recovery_captured" | "refund_issued";
  sourceEventUuid: string;
  providerResult?: any;
  providerCode?: string | null;
  recordedAt: string;
}) {
  const participantId = String(args.reservation?.participant_id || "");
  const qty = Math.max(0, Number(args.reservation?.qty || 0));
  const unitPrice = Math.max(0, Number(args.deal?.price_per_unit || 0));
  const deliveryCost = Math.max(0, Number(args.reservation?.delivery_cost || 0));
  const gross = roundMoney(qty * unitPrice + deliveryCost);
  if (!participantId || !(gross > 0)) {
    throw Object.assign(new Error("final money event has invalid participant or gross amount"), { status: 409, code: ErrorCode.IllegalStateTransition });
  }
  const refund = args.eventType === "refund_issued";
  const amounts = calculatePlatformFeeMoney(gross, refund ? -1 : 1);
  const sourceMoneyState = args.eventType === "recovery_captured"
    ? MoneyState.RecoveredCharge
    : args.eventType === "refund_issued"
      ? MoneyState.Refunded
      : MoneyState.ChargedSuccess;
  const logicalEntryType = refund ? "refund_adjustment" : "charge";
  const providerCode = String(args.providerCode || args.reservation?.authorization_provider || "provider").slice(0, 100);
  return {
    event_key: `money:${args.eventType}:${args.sourceEventUuid}:${participantId}`,
    participant_id: participantId,
    deal_id: String(args.deal.deal_id),
    seller_id: String(args.deal.seller_id || ""),
    event_type: args.eventType,
    logical_entry_type: logicalEntryType,
    provider_code: providerCode,
    provider_reference: args.providerResult?.provider_reference ? String(args.providerResult.provider_reference).slice(0, 500) : null,
    correlation_id: args.providerResult?.correlation_id ? String(args.providerResult.correlation_id).slice(0, 300) : null,
    source_money_state: sourceMoneyState,
    ...amounts,
    payout_readiness_status: refund ? "reversed_after_refund" : "ready_for_settlement",
    recorded_at: args.recordedAt,
    financial_rules_version: FINANCIAL_RULES_VERSION
  };
}

export function appendCanonicalMoneyEvents(existing: any, additions: any[]) {
  const rows = Array.isArray(existing) ? [...existing] : [];
  const keys = new Set(rows.map((row: any) => String(row?.event_key || "")).filter(Boolean));
  for (const event of additions) {
    const key = String(event?.event_key || "");
    if (!key || keys.has(key)) continue;
    rows.push(event);
    keys.add(key);
  }
  return rows;
}

export async function projectMoneyEvents(admin: any, events: any[]) {
  for (const event of events || []) {
    const key = String(event?.event_key || "");
    if (!key) continue;
    const prior = await admin.entities.MoneyLedgerEvent.filter({ event_key: key }, "-recorded_at", 1).catch(() => []);
    if (prior?.[0]) continue;
    await admin.entities.MoneyLedgerEvent.create(event).catch(() => undefined);
  }
}
