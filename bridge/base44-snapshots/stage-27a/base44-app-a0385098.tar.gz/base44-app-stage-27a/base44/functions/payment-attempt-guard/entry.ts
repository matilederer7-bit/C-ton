import { createClientFromRequest } from "npm:@base44/sdk";
import { ErrorCode } from "../../shared/constitution.ts";

const WINDOW_MS = 30 * 60_000;
const MAX_ATTEMPTS = 3;
function fail(status:number,error:string,code:string){return Response.json({ok:false,error,code},{status});}
async function sha256(value:string){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(value));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("");}
async function authorized(base44:any,body:any){
  try{const user=await base44.auth.me();if(String(user?.role||"")==="admin")return true;}catch{}
  const expected=String(Deno.env.get("PAYMENT_WORKER_INTERNAL_SECRET")||"");
  if(expected.length<32)return false;
  return (await sha256(String(body?.internal_call_token||"")))===(await sha256(expected));
}
function uuid(value:unknown){const v=String(value||"").trim();return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v)?v:"";}

Deno.serve(async(req)=>{
  if(req.method!=="POST")return fail(405,"method_not_allowed",ErrorCode.ForbiddenAction);
  const base44=createClientFromRequest(req);let body:any;try{body=await req.json();}catch{return fail(400,"invalid JSON body",ErrorCode.InvalidInput);}
  if(!(await authorized(base44,body)))return fail(403,"worker authorization required",ErrorCode.ForbiddenAction);
  const participantId=uuid(body?.participant_id),dealId=uuid(body?.deal_id),key=String(body?.idempotency_key||"").trim().slice(0,300);
  if(!participantId||!dealId||!key)return fail(400,"participant_id, deal_id and idempotency_key are required",ErrorCode.InvalidInput);
  const admin=base44.asServiceRole;
  for(let spin=0;spin<6;spin+=1){
    const row=(await admin.entities.Participant.filter({participant_id:participantId,deal_id:dealId},"-created_date",1).catch(()=>[]))?.[0];
    if(!row)return fail(400,"participant not found",ErrorCode.InvalidInput);
    const keys=Array.isArray(row.payment_retry_slot_keys)?row.payment_retry_slot_keys.map(String):[];
    const currentCount=Math.max(0,Number(row.payment_retry_attempt_count||0));
    const startMs=Date.parse(String(row.payment_retry_window_started_at||""));
    const now=Date.now();
    if(keys.includes(key)){
      const windowStart=Number.isFinite(startMs)?startMs:now;
      return Response.json({ok:true,allowed:true,replay:true,participant_id:participantId,deal_id:dealId,attempt_count:currentCount,max_attempts:MAX_ATTEMPTS,window_expires_at:new Date(windowStart+WINDOW_MS).toISOString(),attempt_guard_key:key});
    }
    const activeWindow=Number.isFinite(startMs)&&now-startMs<WINDOW_MS;
    if(activeWindow&&currentCount>=MAX_ATTEMPTS)return fail(403,"payment retry storm limit reached for participant in deal",ErrorCode.ForbiddenAction);
    let update:any;
    if(!activeWindow){
      update={$set:{payment_retry_window_started_at:new Date(now).toISOString(),payment_retry_attempt_count:1,payment_retry_slot_keys:[key]}};
    }else{
      update={$inc:{payment_retry_attempt_count:1},$addToSet:{payment_retry_slot_keys:key}};
    }
    const changed=await admin.entities.Participant.updateMany({participant_id:participantId,deal_id:dealId,payment_retry_attempt_count:currentCount},update).catch(()=>({updated:0}));
    if(Number(changed?.updated||0)!==1)continue;
    const count=activeWindow?currentCount+1:1;
    const windowStart=activeWindow?startMs:now;
    return Response.json({ok:true,allowed:true,replay:false,participant_id:participantId,deal_id:dealId,attempt_count:count,max_attempts:MAX_ATTEMPTS,window_expires_at:new Date(windowStart+WINDOW_MS).toISOString(),attempt_guard_key:key});
  }
  return fail(503,"payment attempt guard lost repeated conditional updates",ErrorCode.TemporarilyUnavailable);
});
