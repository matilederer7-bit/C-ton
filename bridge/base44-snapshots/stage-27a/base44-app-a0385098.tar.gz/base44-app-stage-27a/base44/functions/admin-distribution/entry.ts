import { DealState, ErrorCode, MoneyState } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}

function code(value: unknown) {
  return String(value || "").trim().toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
}
function text(value: unknown, max: number) { return String(value ?? "").trim().slice(0, max); }

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (String(user?.role || "") !== "admin") return fail(403, "admin required", ErrorCode.ForbiddenAction);
  const admin = base44.asServiceRole;
  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const operation = String(body?.operation || "list");

  if (operation === "list") {
    const [sources, attributions, events, participants, deals, accesses] = await Promise.all([
      admin.entities.DistributionSource.list("display_name", 500),
      admin.entities.DistributionAttribution.list("-attributed_at", 5000),
      admin.entities.DistributionEvent.list("-created_at", 5000).catch(() => []),
      admin.entities.Participant.list("-created_date", 5000),
      admin.entities.Deal.list("-created_date", 1000),
      admin.entities.DistributorDealAccess.list("-created_at", 1000).catch(() => [])
    ]);
    const participantById = new Map((participants || []).map((row: any) => [String(row.participant_id || ""), row]));
    const dealById = new Map((deals || []).map((row: any) => [String(row.deal_id || ""), row]));
    const totals = new Map<string, { clicks: number; visits: number; attributions: number; units: number; attributed_sales: number; attributed_gross: number }>();
    const ensure = (sourceId: string) => {
      const current = totals.get(sourceId) || { clicks: 0, visits: 0, attributions: 0, units: 0, attributed_sales: 0, attributed_gross: 0 };
      totals.set(sourceId, current);
      return current;
    };
    for (const row of events || []) {
      const current = ensure(String(row.source_id || ""));
      if (String(row.event_type) === "click") current.clicks += 1;
      if (String(row.event_type) === "visit") current.visits += 1;
    }
    for (const row of attributions || []) {
      const current = ensure(String(row.source_id || ""));
      current.attributions += 1;
      current.units += Number(row.qty || 0);
      const participant = participantById.get(String(row.participant_id || ""));
      const deal = dealById.get(String(row.deal_id || ""));
      const settled = participant && deal && String(deal.state || "") === DealState.Completed && [MoneyState.ChargedSuccess, MoneyState.RecoveredCharge].includes(String(participant.money_state || ""));
      if (settled) {
        const qty = Math.max(0, Number(participant.qty || row.qty || 0));
        const gross = qty * Math.max(0, Number(deal.price_per_unit || 0)) + Math.max(0, Number(participant.delivery_cost || 0));
        current.attributed_sales += 1;
        current.attributed_gross += Math.round((gross + Number.EPSILON) * 100) / 100;
      }
    }
    const global = [...totals.values()].reduce((sum, row) => ({
      clicks: sum.clicks + row.clicks,
      visits: sum.visits + row.visits,
      attributions: sum.attributions + row.attributions,
      units: sum.units + row.units,
      attributed_sales: sum.attributed_sales + row.attributed_sales,
      attributed_gross: Math.round((sum.attributed_gross + row.attributed_gross + Number.EPSILON) * 100) / 100
    }), { clicks: 0, visits: 0, attributions: 0, units: 0, attributed_sales: 0, attributed_gross: 0 });
    return Response.json({
      ok: true,
      sources: (sources || []).map((row: any) => {
        const sourceTotals = ensure(String(row.source_id));
        return {
          source_id: row.source_id,
          source_code: row.source_code,
          display_name: row.display_name,
          source_type: row.source_type || "admin",
          owner_user_id: row.owner_user_id || null,
          deal_id: row.deal_id || null,
          distributor_access_id: row.distributor_access_id || null,
          active: row.active !== false,
          notes: row.notes || null,
          created_at: row.created_at || row.created_date || null,
          total_clicks: sourceTotals.clicks,
          total_visits: sourceTotals.visits,
          total_attributions: sourceTotals.attributions,
          total_units: sourceTotals.units,
          attributed_sales: sourceTotals.attributed_sales,
          attributed_gross: sourceTotals.attributed_gross,
          conversion_rate: sourceTotals.visits > 0 ? Math.round((sourceTotals.attributions / sourceTotals.visits) * 10000) / 100 : 0
        };
      }),
      recent_attributions: (attributions || []).slice(0, 100).map((row: any) => ({ attribution_id: row.attribution_id, source_code: row.source_code, deal_id: row.deal_id, participant_id: row.participant_id, qty: Number(row.qty || 0), attributed_at: row.attributed_at })),
      distributor_accesses: (accesses || []).map((row: any) => ({ access_id: row.access_id, owner_user_id: row.owner_user_id, user_email: row.user_email, deal_id: row.deal_id, status: row.status, created_at: row.created_at || row.created_date || null, revoked_at: row.revoked_at || null, revoke_reason: row.revoke_reason || null })),
      totals: {
        total_clicks: global.clicks,
        total_visits: global.visits,
        total_attributions: global.attributions,
        total_units: global.units,
        attributed_sales: global.attributed_sales,
        attributed_gross: global.attributed_gross
      },
      financial_semantics: "attributed_gross_is_measurement_only"
    });
  }

  if (operation === "create") {
    const sourceCode = code(body.source_code);
    const displayName = text(body.display_name, 160);
    if (sourceCode.length < 2) return fail(400, "source_code is required", ErrorCode.InvalidInput);
    if (!displayName) return fail(400, "display_name is required", ErrorCode.InvalidInput);
    const prior = await admin.entities.DistributionSource.filter({ source_code: sourceCode }, "-created_date", 1);
    if (prior?.[0]) return fail(409, "source_code already exists", ErrorCode.IllegalStateTransition);
    const now = new Date().toISOString();
    const sourceId = crypto.randomUUID();
    const event = { event_type: "distribution_source.create", created_at: now, actor_user_id: String(user.id), payload: { source_code: sourceCode } };
    const created = await admin.entities.DistributionSource.create({ source_id: sourceId, source_code: sourceCode, display_name: displayName, source_type: "admin", active: body.active !== false, notes: text(body.notes, 2000) || null, created_by_user_id: String(user.id), created_at: now, event_journal: [event] });
    return Response.json({ ok: true, source: created });
  }

  if (operation === "grant_distributor") {
    const userEmail = String(body.user_email || "").trim().toLowerCase();
    const dealId = String(body.deal_id || "").trim();
    if (!userEmail || !userEmail.includes("@")) return fail(400, "valid user_email is required", ErrorCode.InvalidInput);
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(dealId)) return fail(400, "valid deal_id is required", ErrorCode.InvalidInput);
    const [users, deals] = await Promise.all([
      admin.entities.User.filter({ email: userEmail }, "-created_date", 1),
      admin.entities.Deal.filter({ deal_id: dealId }, "-created_date", 1)
    ]);
    const targetUser = users?.[0];
    const deal = deals?.[0];
    if (!targetUser) return fail(404, "registered user not found", ErrorCode.InvalidInput);
    if (!deal) return fail(404, "deal not found", ErrorCode.InvalidInput);
    const prior = await admin.entities.DistributorDealAccess.filter({ owner_user_id: String(targetUser.id), deal_id: dealId, status: "active" }, "-created_at", 1);
    if (prior?.[0]) return Response.json({ ok: true, access: prior[0], replay: true });
    const at = new Date().toISOString();
    const accessId = crypto.randomUUID();
    const ev = { event_type: "distributor_access.granted", created_at: at, actor_user_id: String(user.id), payload: { user_email: userEmail, deal_id: dealId } };
    const created = await admin.entities.DistributorDealAccess.create({ access_id: accessId, owner_user_id: String(targetUser.id), user_email: userEmail, deal_id: dealId, status: "active", created_by_user_id: String(user.id), created_at: at, event_journal: [ev] });
    return Response.json({ ok: true, access: created, replay: false });
  }

  if (operation === "revoke_distributor") {
    const accessId = text(body.access_id, 80);
    const reason = text(body.reason, 1000);
    if (!accessId) return fail(400, "access_id is required", ErrorCode.InvalidInput);
    if (!reason) return fail(400, "reason is required", ErrorCode.InvalidInput);
    const access = (await admin.entities.DistributorDealAccess.filter({ access_id: accessId }, "-created_at", 1))?.[0];
    if (!access) return fail(404, "distributor access not found", ErrorCode.InvalidInput);
    if (access.status === "revoked") return Response.json({ ok: true, access, replay: true });
    const at = new Date().toISOString();
    const ev = { event_type: "distributor_access.revoked", created_at: at, actor_user_id: String(user.id), payload: { reason } };
    const result = await admin.entities.DistributorDealAccess.updateMany(
      { access_id: accessId, status: "active" },
      { $set: { status: "revoked", revoked_by_user_id: String(user.id), revoked_at: at, revoke_reason: reason }, $push: { event_journal: ev } }
    );
    if (Number(result?.updated || 0) !== 1) return fail(409, "access changed concurrently", ErrorCode.IllegalStateTransition);
    await admin.entities.DistributionSource.updateMany(
      { distributor_access_id: accessId, source_type: "distributor", active: true },
      { $set: { active: false }, $push: { event_journal: { event_type: "distribution_source.disabled_by_access_revoke", created_at: at, actor_user_id: String(user.id), payload: { access_id: accessId, reason } } } }
    ).catch(() => undefined);
    const latest = (await admin.entities.DistributorDealAccess.filter({ access_id: accessId }, "-created_at", 1))?.[0];
    return Response.json({ ok: true, access: latest, replay: false });
  }

  if (operation === "update") {
    const sourceId = text(body.source_id, 80);
    if (!sourceId) return fail(400, "source_id required", ErrorCode.InvalidInput);
    const source = (await admin.entities.DistributionSource.filter({ source_id: sourceId }, "-created_date", 1))?.[0];
    if (!source) return fail(404, "distribution source not found", ErrorCode.InvalidInput);
    const reason = text(body.reason, 1000);
    if (!reason) return fail(400, "reason is required", ErrorCode.InvalidInput);
    const now = new Date().toISOString();
    const event = { event_type: "distribution_source.update", created_at: now, actor_user_id: String(user.id), payload: { reason, active: body.active === undefined ? source.active !== false : body.active !== false } };
    await admin.entities.DistributionSource.update(source.id, {
      display_name: body.display_name === undefined ? source.display_name : text(body.display_name, 160) || source.display_name,
      active: body.active === undefined ? source.active !== false : body.active !== false,
      notes: body.notes === undefined ? source.notes || null : text(body.notes, 2000) || null,
      event_journal: [...(Array.isArray(source.event_journal) ? source.event_journal : []), event]
    });
    const latest = (await admin.entities.DistributionSource.filter({ source_id: sourceId }, "-created_date", 1))?.[0];
    return Response.json({ ok: true, source: latest });
  }

  return fail(400, "unsupported distribution operation", ErrorCode.InvalidInput);
});
