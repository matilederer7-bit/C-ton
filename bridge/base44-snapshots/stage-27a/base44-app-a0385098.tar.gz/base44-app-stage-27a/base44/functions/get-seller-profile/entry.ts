import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status: number, message: string, code?: string) {
  return Response.json({ ok: false, error: message, ...(code ? { code } : {}) }, { status });
}

Deno.serve(async (req) => {
  if (req.method !== "GET" && req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }

  const rows = await base44.asServiceRole.entities.SellerAccount.filter({ owner_user_id: String(user.id) }, "-created_date", 1);
  const seller = rows?.[0];
  if (!seller) return Response.json({ ok: true, seller: null });

  return Response.json({
    ok: true,
    seller: {
      seller_id: String(seller.seller_id || ""),
      display_name: String(seller.display_name || ""),
      business_name: String(seller.business_name || ""),
      support_phone: String(seller.support_phone || ""),
      support_email: String(seller.support_email || ""),
      seller_status: String(seller.seller_status || "Active"),
      verification_status: String(seller.verification_status || "pending"),
      verification_reviewed_at: seller.verification_reviewed_at || null
    }
  });
});
