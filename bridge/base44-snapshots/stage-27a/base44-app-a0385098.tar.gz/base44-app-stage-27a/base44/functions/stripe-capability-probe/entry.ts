import { createClientFromRequest } from "npm:@base44/sdk";

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return Response.json({ ok: false, error: "method_not_allowed" }, { status: 405 });
  }

  const base44 = createClientFromRequest(req);
  try {
    const connection = await base44.asServiceRole.connectors.getConnection("stripe");
    const hasToken = Boolean(connection?.accessToken);
    return Response.json({
      ok: true,
      stripe_connection_available: hasToken,
      connection_config_present: Boolean(connection?.connectionConfig),
      secret_material_returned: false
    });
  } catch (error: any) {
    return Response.json({
      ok: true,
      stripe_connection_available: false,
      error_code: String(error?.code || error?.response?.data?.code || "stripe_connection_unavailable"),
      error_message: String(error?.response?.data?.error || error?.message || "stripe connection unavailable").slice(0, 240),
      secret_material_returned: false
    });
  }
});