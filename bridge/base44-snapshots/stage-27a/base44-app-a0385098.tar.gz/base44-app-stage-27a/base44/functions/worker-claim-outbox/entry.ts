import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const DEFAULT_LEASE_MS = 60_000;

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (!user?.id || String(user.role || "") !== "admin") return fail(403, "admin worker authority required", ErrorCode.ForbiddenAction);

  let body: any = {};
  try { body = await req.json(); } catch { body = {}; }

  const now = new Date();
  const nowIso = now.toISOString();
  const leaseMs = Math.max(5_000, Math.min(10 * 60_000, Number(body.lease_ms || DEFAULT_LEASE_MS)));
  const allowedTypes = Array.isArray(body.event_types)
    ? body.event_types.map((value: unknown) => String(value)).filter(Boolean).slice(0, 20)
    : [];
  const requestedEventUuid = String(body.event_uuid || "").trim();

  // Reclaim expired processing rows. Attempt count is not incremented on reclaim;
  // it increments only when a new lease is successfully claimed.
  await base44.asServiceRole.entities.OutboxEvent.updateMany(
    {
      status: "processing",
      $or: [
        { lease_expires_at: { $lte: nowIso } },
        { lease_expires_at: null }
      ]
    },
    {
      $set: {
        status: "pending",
        lease_owner: "",
        lease_expires_at: null,
        available_at: nowIso,
        last_error: "worker_reclaim_after_restart"
      }
    }
  ).catch(() => undefined);

  const baseQuery: any = {
    status: "pending",
    available_at: { $lte: nowIso },
    $expr: { $lt: ["$attempt_count", "$max_attempts"] }
  };
  if (allowedTypes.length) baseQuery.event_type = { $in: allowedTypes };
  if (requestedEventUuid) baseQuery.event_uuid = requestedEventUuid;

  // Some Base44 environments may not support $expr. Fall back to a bounded
  // candidate read and enforce attempt_count < max_attempts in application code,
  // while the claim itself remains conditional on event_uuid/status/available_at.
  let candidates: any[] = [];
  try {
    candidates = await base44.asServiceRole.entities.OutboxEvent.filter(baseQuery, "created_date", 20);
  } catch {
    const fallbackQuery: any = { status: "pending", available_at: { $lte: nowIso } };
    if (allowedTypes.length) fallbackQuery.event_type = { $in: allowedTypes };
    if (requestedEventUuid) fallbackQuery.event_uuid = requestedEventUuid;
    candidates = await base44.asServiceRole.entities.OutboxEvent.filter(fallbackQuery, "created_date", 20);
  }

  candidates = (candidates || []).filter((event: any) => Number(event.attempt_count || 0) < Number(event.max_attempts || 4));
  for (const candidate of candidates) {
    const leaseOwner = `base44-worker:${crypto.randomUUID()}`;
    const leaseExpiresAt = new Date(now.getTime() + leaseMs).toISOString();
    const result = await base44.asServiceRole.entities.OutboxEvent.updateMany(
      {
        event_uuid: String(candidate.event_uuid),
        status: "pending",
        available_at: { $lte: nowIso },
        attempt_count: Number(candidate.attempt_count || 0)
      },
      {
        $set: {
          status: "processing",
          lease_owner: leaseOwner,
          lease_expires_at: leaseExpiresAt,
          last_error: ""
        },
        $inc: { attempt_count: 1 }
      }
    );
    if (Number(result?.updated || 0) !== 1) continue;

    const claimed = (await base44.asServiceRole.entities.OutboxEvent.filter({ event_uuid: String(candidate.event_uuid), lease_owner: leaseOwner }, "-updated_date", 1))?.[0];
    if (!claimed) continue;
    return Response.json({
      ok: true,
      claimed: true,
      event: {
        event_uuid: claimed.event_uuid,
        event_type: claimed.event_type,
        aggregate_type: claimed.aggregate_type,
        aggregate_id: claimed.aggregate_id,
        payload: claimed.payload,
        attempt_count: claimed.attempt_count,
        max_attempts: claimed.max_attempts,
        lease_owner: leaseOwner,
        lease_expires_at: leaseExpiresAt
      }
    });
  }

  return Response.json({ ok: true, claimed: false, event: null });
});
