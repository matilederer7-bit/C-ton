import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const OTP_TTL_MS = 10 * 60_000;
const OTP_RATE_LIMIT_WINDOW_MS = 15 * 60_000;
const OTP_RATE_LIMIT_MAX_REQUESTS = 5;
const OTP_DEFAULT_MAX_ATTEMPTS = 3;
const CHANNELS = ["sms", "email"];
const PURPOSES = ["buyer_join", "buyer_recovery", "seller_login"];
const encoder = new TextEncoder();

function error(status: number, message: string, code: string) {
  return Response.json({ ok: false, error: message, code }, { status });
}

function normalizeDestination(channel: string, destination: string) {
  const raw = String(destination || "").trim();
  return channel === "sms" ? raw.replace(/\D/g, "") : raw.toLowerCase();
}

function validateDestination(channel: string, destination: string) {
  const normalized = normalizeDestination(channel, destination);
  if (channel === "sms") return normalized.length >= 7 && normalized.length <= 15;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized);
}

function maskDestination(channel: string, destination: string) {
  const normalized = normalizeDestination(channel, destination);
  if (channel === "sms") {
    if (normalized.length <= 4) return "***";
    return `${"*".repeat(normalized.length - 4)}${normalized.slice(-4)}`;
  }
  const at = normalized.indexOf("@");
  if (at <= 1) return "***";
  const local = normalized.slice(0, at);
  return `${local.slice(0, 1)}${"*".repeat(Math.max(2, local.length - 1))}${normalized.slice(at)}`;
}

function bytesToHex(bytes: ArrayBuffer) {
  return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function randomBase64Url(byteLength = 16) {
  const bytes = crypto.getRandomValues(new Uint8Array(byteLength));
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

async function sha256Hex(value: string) {
  return bytesToHex(await crypto.subtle.digest("SHA-256", encoder.encode(value)));
}

async function hashOtpCode(code: string, challengeId: string, salt: string) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(code), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", iterations: 120_000, salt: encoder.encode(`${salt}:${challengeId}`) },
    key,
    256
  );
  return bytesToHex(bits);
}

function generateOtpCode() {
  const bytes = crypto.getRandomValues(new Uint32Array(1));
  return String((bytes[0] || 0) % 1_000_000).padStart(6, "0");
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return error(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let body: any;
  try { body = await req.json(); } catch { return error(400, "invalid JSON body", ErrorCode.InvalidInput); }

  const channel = String(body.channel || "").trim().toLowerCase();
  const purpose = String(body.purpose || "").trim();
  const destination = String(body.destination || "").trim();
  const dealId = body.deal_id ? String(body.deal_id).trim() : "";

  if (!CHANNELS.includes(channel)) return error(400, "channel must be sms or email", ErrorCode.InvalidInput);
  if (!PURPOSES.includes(purpose)) return error(400, "unsupported purpose", ErrorCode.InvalidInput);
  if (!validateDestination(channel, destination)) return error(400, channel === "sms" ? "destination must be 7-15 digit phone" : "destination must be a valid email", ErrorCode.InvalidInput);

  const normalized = normalizeDestination(channel, destination);
  const destinationHash = await sha256Hex(`${channel}:${normalized}`);
  const destinationDisplay = maskDestination(channel, normalized);
  const now = Date.now();
  const recentWindow = new Date(now - OTP_RATE_LIMIT_WINDOW_MS).toISOString();

  const recent = await base44.asServiceRole.entities.OtpChallenge.filter(
    { destination_hash: destinationHash, created_date: { $gt: recentWindow } },
    "-created_date",
    OTP_RATE_LIMIT_MAX_REQUESTS + 1
  );
  if ((recent || []).length >= OTP_RATE_LIMIT_MAX_REQUESTS) {
    return error(429, "too many otp requests for this destination", ErrorCode.ForbiddenAction);
  }

  const windowKey = Math.floor(now / OTP_TTL_MS);
  const idempotencyKey = [channel, destinationHash, purpose, dealId, windowKey].join(":");
  const existing = await base44.asServiceRole.entities.OtpChallenge.filter(
    { idempotency_key: idempotencyKey, status: "pending", expires_at: { $gt: new Date(now).toISOString() } },
    "-created_date",
    1
  );
  if (existing?.[0]) {
    const row = existing[0];
    const attempts = await base44.asServiceRole.entities.OtpDeliveryAttempt.filter({ challenge_id: String(row.challenge_id) }, "-created_date", 1).catch(() => []);
    const latestAttempt = attempts?.[0];
    return Response.json({
      ok: true,
      challenge_id: row.challenge_id,
      status: "pending",
      expires_at: row.expires_at,
      destination_display: row.destination_display,
      reused: true,
      delivery_status: latestAttempt?.result_status === "success" ? "sent" : String(latestAttempt?.result_status || "skipped"),
      provider: latestAttempt?.provider || row.provider || "log",
      provider_mode: latestAttempt?.provider_mode || row.provider_mode || "migration"
    });
  }

  const challengeId = crypto.randomUUID();
  const code = generateOtpCode();
  const salt = randomBase64Url(18);
  const codeHash = await hashOtpCode(code, challengeId, salt);
  const expiresAt = new Date(now + OTP_TTL_MS).toISOString();

  const row = await base44.asServiceRole.entities.OtpChallenge.create({
    challenge_id: challengeId,
    channel,
    destination_hash: destinationHash,
    destination_display: destinationDisplay,
    purpose,
    deal_id: dealId || null,
    code_hash: codeHash,
    code_salt: salt,
    status: "pending",
    expires_at: expiresAt,
    max_attempts: OTP_DEFAULT_MAX_ATTEMPTS,
    attempts_count: 0,
    idempotency_key: idempotencyKey,
    provider: "log",
    provider_mode: "migration"
  });

  const internalToken = String(Deno.env.get("COMMUNICATION_INTERNAL_CALL_SECRET") || "");
  let delivery: any = { result_class: "skipped", provider: "log", provider_mode: "migration", error_code: "external_otp_provider_not_connected", error_message: "external communication provider is not connected" };
  if (internalToken.length >= 32) {
    try {
      const deliveryResponse = await base44.asServiceRole.functions.invoke("communication-delivery", {
        internal_call_token: internalToken,
        channel,
        destination: normalized,
        template_key: `otp_${purpose}_he`,
        locale: "he-IL",
        idempotency_key: `otp-delivery:${challengeId}`,
        variables: { code, expires_minutes: 10, purpose }
      });
      const result = deliveryResponse?.data || deliveryResponse;
      if (result?.ok) delivery = result;
      else delivery = { result_class: "unknown", provider: "provider-ready", provider_mode: "configured", error_code: result?.code || "delivery_call_failed", error_message: result?.error || "delivery call failed" };
    } catch {
      delivery = { result_class: "unknown", provider: "provider-ready", provider_mode: "configured", error_code: "delivery_invocation_unknown", error_message: "delivery invocation outcome is unknown" };
    }
  }

  await base44.asServiceRole.entities.OtpDeliveryAttempt.create({
    attempt_id: crypto.randomUUID(),
    challenge_id: challengeId,
    provider: String(delivery.provider || "provider-ready"),
    provider_mode: String(delivery.provider_mode || "configured"),
    result_status: String(delivery.result_class || "unknown"),
    provider_message_id: delivery.provider_message_id || null,
    error_code: delivery.error_code || null,
    error_message: delivery.error_message || null
  }).catch(() => undefined);

  const deliverySucceeded = delivery.result_class === "success";
  const providerDisconnected = delivery.result_class === "skipped";
  if (!deliverySucceeded && !providerDisconnected) {
    await base44.asServiceRole.entities.OtpChallenge.updateMany(
      { challenge_id: challengeId, status: "pending" },
      { $set: { status: "cancelled", last_error: String(delivery.error_code || delivery.result_class || "delivery_failed"), provider: String(delivery.provider || "provider-ready"), provider_mode: String(delivery.provider_mode || "configured") } }
    );
    return error(503, "otp delivery was not confirmed; request a new code", ErrorCode.TemporarilyUnavailable);
  }

  await base44.asServiceRole.entities.OtpChallenge.updateMany(
    { challenge_id: challengeId, status: "pending" },
    { $set: { provider: String(delivery.provider || "log"), provider_mode: String(delivery.provider_mode || "migration") } }
  ).catch(() => undefined);

  return Response.json({
    ok: true,
    challenge_id: row.challenge_id,
    status: "pending",
    expires_at: row.expires_at,
    destination_display: row.destination_display,
    reused: false,
    delivery_status: deliverySucceeded ? "sent" : "skipped",
    provider: String(delivery.provider || "log"),
    provider_mode: String(delivery.provider_mode || "migration")
  });
});
