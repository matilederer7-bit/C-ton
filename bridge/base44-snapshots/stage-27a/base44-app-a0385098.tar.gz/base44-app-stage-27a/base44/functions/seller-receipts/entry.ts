import { BuyerState, DealState, ErrorCode, MoneyState } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const CHARGE_MONEY = new Set([MoneyState.ChargedSuccess,MoneyState.RecoveredCharge]);
function fail(status: number, error: string, code?: string) { return Response.json({ ok:false, error, ...(code?{code}:{}) }, { status }); }
function uuid(value: unknown) { const text=String(value||"").trim(); return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(text)?text:""; }

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405,"method_not_allowed", ErrorCode.ForbiddenAction);
  const base44=createClientFromRequest(req);
  let user:any; try { user=await base44.auth.me(); } catch { return fail(401,"authentication required",ErrorCode.ForbiddenAction); }
  if (!user?.id) return fail(401,"authentication required", ErrorCode.ForbiddenAction);
  let body:any; try { body=await req.json(); } catch { return fail(400,"invalid JSON body",ErrorCode.InvalidInput); }
  const dealId=uuid(body?.deal_id); if(!dealId) return fail(400,"deal_id must be a UUID", ErrorCode.InvalidInput);
  const admin=base44.asServiceRole;
  const deal=(await admin.entities.Deal.filter({ deal_id:dealId, owner_user_id:String(user.id) },"-created_date",1))?.[0];
  if(!deal) return fail(404,"deal not found", ErrorCode.InvalidInput);

  const docs=await admin.entities.InvoiceDocument.filter({ deal_id:dealId, deal_owner_user_id:String(user.id) },"-created_at",1000).catch(()=>[]);
  const reservations=Array.isArray(deal.join_reservations)?deal.join_reservations:[];
  const chargeEligible=String(deal.state)===DealState.Completed ? reservations.filter((row:any)=>String(row?.buyer_state||"")===BuyerState.DealCompleted && CHARGE_MONEY.has(String(row?.money_state||""))) : [];
  const expectedKeys=new Set(chargeEligible.map((row:any)=>`charge_receipt:${String(row.participant_id||"")}`));
  const existingKeys=new Set((docs||[]).map((row:any)=>String(row.document_key||"")));
  const missingKeys=[...expectedKeys].filter((key)=>!existingKeys.has(key));

  const safeDocs=(docs||[]).map((row:any)=>({
    document_id:row.document_id,
    document_key:row.document_key,
    document_type:row.document_type,
    participant_id:row.participant_id,
    status:row.status,
    qty:Number(row.qty||0),
    money_state_at_issue:row.money_state_at_issue,
    financial_snapshot_proven:row.financial_snapshot_proven===true,
    gross_amount:row.financial_snapshot_proven===true?Number(row.gross_amount||0):null,
    siton_fee_amount:row.financial_snapshot_proven===true?Number(row.siton_fee_amount||0):null,
    seller_net_amount:row.financial_snapshot_proven===true?Number(row.seller_net_amount||0):null,
    provider_code:row.provider_code||null,
    provider_document_id:row.provider_document_id||null,
    attempt_count:Number(row.attempt_count||0),
    max_attempts:Number(row.max_attempts||3),
    available_at:row.available_at||null,
    issued_at:row.issued_at||null,
    last_error:row.last_error||null,
    created_at:row.created_at||row.created_date||null
  }));

  return Response.json({
    ok:true,
    deal:{ deal_id:dealId, title:String(deal.title||""), state:String(deal.state||"") },
    documents:safeDocs,
    readiness:{
      expected_charge_receipts:expectedKeys.size,
      existing_charge_receipts:safeDocs.filter((row:any)=>row.document_type==="charge_receipt").length,
      missing_charge_receipts:missingKeys.length,
      issued:safeDocs.filter((row:any)=>row.status==="issued").length,
      failed:safeDocs.filter((row:any)=>row.status==="failed").length,
      pending:safeDocs.filter((row:any)=>["pending","processing"].includes(String(row.status))).length,
      provider_connected:safeDocs.some((row:any)=>Boolean(row.provider_code)),
      financial_snapshot_ready:safeDocs.length>0 && safeDocs.every((row:any)=>row.financial_snapshot_proven===true)
    },
    missing_document_keys:missingKeys.slice(0,200),
    issuance_enabled:false,
    issuance_blocker:"real invoice provider and authoritative VAT/financial snapshot are not connected",
    fee_calculation_performed:false
  });
});
