import { DealState, ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const DEADLINE_MIN_MS = 2 * 60 * 60 * 1000;
const DEADLINE_MAX_MS = 7 * 24 * 60 * 60 * 1000;
const DEAL_TYPES = ["physical_product", "voucher", "ticket"];

function fail(status: number, message: string, code?: string) {
  return Response.json({ ok: false, error: message, ...(code ? { code } : {}) }, { status });
}

function sanitizeDeliveryOptions(raw: unknown) {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((option: any, index: number) => ({
      option_id: String(option?.option_id || crypto.randomUUID()),
      option_type: ["delivery", "pickup", "distribution_point"].includes(String(option?.option_type || ""))
        ? String(option.option_type)
        : "pickup",
      label: String(option?.label || "").trim().slice(0, 160),
      cost: Math.max(0, Number(option?.cost || 0)),
      sort_order: Number.isFinite(Number(option?.sort_order)) ? Number(option.sort_order) : index
    }))
    .filter((option: any) => option.label)
    .slice(0, 5);
}

function normalizeVoucherTerms(input: any) {
  if (!input || typeof input !== "object") return null;
  const faceValue = Number(input.face_value_amount);
  if (!Number.isFinite(faceValue) || faceValue <= 0) {
    throw Object.assign(new Error("face_value_amount must be a positive number"), { status: 400, code: ErrorCode.InvalidInput });
  }
  const mode = String(input.voucher_code_mode || "system_generated");
  if (mode === "seller_uploaded") {
    throw Object.assign(new Error("seller_uploaded voucher codes are not supported yet"), { status: 400, code: ErrorCode.InvalidInput });
  }
  return {
    face_value_amount: faceValue,
    currency: String(input.currency || "ILS").trim().slice(0, 8) || "ILS",
    valid_from: input.valid_from || null,
    valid_until: input.valid_until || null,
    redemption_location: String(input.redemption_location || "").trim().slice(0, 500),
    redemption_instructions: String(input.redemption_instructions || "").trim().slice(0, 1000),
    terms: String(input.terms || "").trim().slice(0, 2000),
    is_single_use: input.is_single_use !== false,
    allow_partial_redemption: input.allow_partial_redemption === true,
    voucher_code_mode: mode
  };
}

function normalizeTicketTerms(input: any) {
  if (!input || typeof input !== "object") return null;
  const eventName = String(input.event_name || "").trim().slice(0, 200);
  if (!eventName) throw Object.assign(new Error("event_name is required for ticket deals"), { status: 400, code: ErrorCode.InvalidInput });
  const startsAtMs = new Date(String(input.event_starts_at || "")).getTime();
  if (!Number.isFinite(startsAtMs)) throw Object.assign(new Error("event_starts_at must be a valid ISO date"), { status: 400, code: ErrorCode.InvalidInput });
  const seatMode = String(input.seat_mode || "general_admission");
  if (seatMode === "assigned_seating_not_supported_yet") {
    throw Object.assign(new Error("assigned seating is not supported yet"), { status: 400, code: ErrorCode.InvalidInput });
  }
  const endsAt = input.event_ends_at ? new Date(String(input.event_ends_at)) : null;
  return {
    event_name: eventName,
    event_starts_at: new Date(startsAtMs).toISOString(),
    event_ends_at: endsAt && Number.isFinite(endsAt.getTime()) ? endsAt.toISOString() : null,
    venue_name: String(input.venue_name || "").trim().slice(0, 200),
    venue_address: String(input.venue_address || "").trim().slice(0, 300),
    venue_city: String(input.venue_city || "").trim().slice(0, 100),
    entry_instructions: String(input.entry_instructions || "").trim().slice(0, 1000),
    ticket_type: String(input.ticket_type || "general_admission"),
    seat_mode: seatMode,
    transfer_allowed: input.transfer_allowed === true
  };
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);

  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }

  const dealId = String(body?.deal_id || "").trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(dealId)) return fail(400, "deal_id must be a valid UUID", ErrorCode.InvalidInput);

  try {
    const deals = await base44.asServiceRole.entities.Deal.filter({ deal_id: dealId, owner_user_id: String(user.id) }, "-created_date", 1);
    const deal = deals?.[0];
    if (!deal) return fail(404, "deal not found", ErrorCode.InvalidInput);
    if (String(deal.state) !== DealState.Draft) return fail(409, "only Draft deals can be edited", ErrorCode.IllegalStateTransition);

    const sellers = await base44.asServiceRole.entities.SellerAccount.filter({ owner_user_id: String(user.id) }, "-created_date", 1);
    const seller = sellers?.[0];
    if (!seller || String(seller.seller_id) !== String(deal.seller_id)) return fail(404, "deal not found", ErrorCode.InvalidInput);
    const sellerStatus = String(seller.seller_status || "Active");
    if (sellerStatus === "Suspended") return fail(403, "seller is suspended from seller actions", ErrorCode.ForbiddenAction);
    if (sellerStatus === "Banned") return fail(403, "seller is banned from seller actions", ErrorCode.ForbiddenAction);

    const dealType = String(body.deal_type ?? deal.deal_type ?? "physical_product");
    if (!DEAL_TYPES.includes(dealType)) return fail(400, "invalid deal_type", ErrorCode.InvalidInput);

    const title = String(body.title ?? deal.title ?? "").trim();
    if (!title) return fail(400, "title is required", ErrorCode.InvalidInput);
    if (title.length > 200) return fail(400, "title must be 200 characters or fewer", ErrorCode.InvalidInput);
    const shortDescription = String(body.short_description ?? deal.short_description ?? "").trim().slice(0, 1200);
    const whatYouGet = String(body.what_you_get ?? deal.what_you_get ?? "").trim().slice(0, 2000);

    const price = Number(body.price_per_unit ?? deal.price_per_unit);
    if (!Number.isFinite(price) || price <= 0) return fail(400, "price_per_unit must be a positive number", ErrorCode.InvalidInput);

    const minUnits = Math.max(1, Number(body.min_units ?? deal.min_units));
    if (!Number.isFinite(minUnits)) return fail(400, "min_units must be a positive number", ErrorCode.InvalidInput);
    const maxUnits = Math.max(minUnits, Number(body.max_units ?? deal.max_units));
    if (!Number.isFinite(maxUnits)) return fail(400, "max_units must be a positive number", ErrorCode.InvalidInput);

    const deadlineMs = new Date(String(body.deadline ?? deal.deadline ?? "")).getTime();
    if (!Number.isFinite(deadlineMs)) return fail(400, "deadline must be a valid ISO date", ErrorCode.InvalidInput);
    const diff = deadlineMs - Date.now();
    if (diff < DEADLINE_MIN_MS) return fail(400, "deadline must be at least 2 hours in the future", ErrorCode.InvalidInput);
    if (diff > DEADLINE_MAX_MS) return fail(400, "deadline must be within 7 days from now", ErrorCode.InvalidInput);

    if (dealType === "voucher" && (!body.voucher_terms || typeof body.voucher_terms !== "object")) return fail(400, "voucher_terms is required for voucher deals", ErrorCode.InvalidInput);
    if (dealType === "ticket" && (!body.ticket_terms || typeof body.ticket_terms !== "object")) return fail(400, "ticket_terms is required for ticket deals", ErrorCode.InvalidInput);

    const deliveryOptions = dealType === "physical_product" ? sanitizeDeliveryOptions(body.delivery_options ?? deal.delivery_options) : [];
    const voucherTerms = dealType === "voucher" ? normalizeVoucherTerms(body.voucher_terms) : null;
    const ticketTerms = dealType === "ticket" ? normalizeTicketTerms(body.ticket_terms) : null;

    const updated = await base44.asServiceRole.entities.Deal.update(deal.id, {
      deal_type: dealType,
      title,
      short_description: shortDescription || null,
      what_you_get: whatYouGet || null,
      price_per_unit: price,
      min_units: Math.trunc(minUnits),
      max_units: Math.trunc(maxUnits),
      threshold_units: Math.ceil(0.9 * Math.trunc(minUnits)),
      commission_rate: 0.08,
      completion_window_hours: 24,
      deadline: new Date(deadlineMs).toISOString(),
      delivery_options: deliveryOptions,
      voucher_terms: voucherTerms,
      ticket_terms: ticketTerms
    });

    return Response.json({
      ok: true,
      deal: {
        deal_id: updated.deal_id,
        state: updated.state,
        deal_type: updated.deal_type,
        title: updated.title,
        short_description: updated.short_description || null,
        what_you_get: updated.what_you_get || null,
        price_per_unit: updated.price_per_unit,
        min_units: updated.min_units,
        max_units: updated.max_units,
        threshold_units: updated.threshold_units,
        deadline: updated.deadline,
        delivery_options: updated.delivery_options || [],
        voucher_terms: updated.voucher_terms || null,
        ticket_terms: updated.ticket_terms || null
      }
    });
  } catch (e: any) {
    return fail(Number(e?.status || e?.statusCode || 500), String(e?.message || "internal_error"), e?.code ? String(e.code) : undefined);
  }
});
