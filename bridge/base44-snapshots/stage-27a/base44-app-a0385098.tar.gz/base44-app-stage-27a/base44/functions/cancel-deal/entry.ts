import { ErrorCode } from "../../shared/constitution.ts";
const FORBIDDEN_ACTION = ErrorCode.ForbiddenAction;

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return Response.json({ ok: false, error: "method_not_allowed", code: FORBIDDEN_ACTION }, { status: 405 });
  }
  return Response.json({
    ok: false,
    error: "seller cancellation is fail-closed until Constitution conflict C-01 defines a legal Action and transition into Cancelled",
    code: FORBIDDEN_ACTION,
    blocker: "BASE44_CONSTITUTION_CONFLICTS:C-01"
  }, { status: 503 });
});
