import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

function fail(status:number,error:string,code?:string){return Response.json({ok:false,error,...(code?{code}:{})},{status});}
function round(value:number){return Math.round((Number(value)||0)*100)/100;}
Deno.serve(async(req)=>{
  if(req.method!=="POST") return fail(405,"method_not_allowed", ErrorCode.ForbiddenAction);
  const base44=createClientFromRequest(req);let user:any;try{user=await base44.auth.me();}catch{return fail(401,"authentication required",ErrorCode.ForbiddenAction);}
  if(!user?.id)return fail(401,"authentication required", ErrorCode.ForbiddenAction);
  const admin=base44.asServiceRole;
  const seller=(await admin.entities.SellerAccount.filter({owner_user_id:String(user.id)},"-created_date",1))?.[0];
  if(!seller)return fail(404,"seller account not found", ErrorCode.InvalidInput);
  const sellerId=String(seller.seller_id||"");
  const [settlements,batches]=await Promise.all([
    admin.entities.SellerSettlement.filter({seller_id:sellerId},"-last_calculated_at",1000).catch(()=>[]),
    admin.entities.SellerPayoutBatch.filter({seller_id:sellerId},"-created_at",1000).catch(()=>[])
  ]);
  const safeSettlements=(settlements||[]).map((row:any)=>({
    settlement_id:row.settlement_id,deal_id:row.deal_id,payout_status:row.payout_status,gross_collected:Number(row.gross_collected||0),platform_fee_total:Number(row.platform_fee_total||0),refunds_total:Number(row.refunds_total||0),seller_net_payable:Number(row.seller_net_payable||0),payout_amount:Number(row.payout_amount||0),paid_amount:Number(row.paid_amount||0),failed_amount:Number(row.failed_amount||0),returned_amount:Number(row.returned_amount||0),blocked_amount:Number(row.blocked_amount||0),blocking_reasons:Array.isArray(row.blocking_reasons)?row.blocking_reasons:[],eligible:row.eligible===true,last_calculated_at:row.last_calculated_at||null
  }));
  const safeBatches=(batches||[]).map((row:any)=>({payout_batch_id:row.payout_batch_id,payout_status:row.payout_status,settlement_count:Number(row.settlement_count||0),gross_collected:Number(row.gross_collected||0),platform_fee_total:Number(row.platform_fee_total||0),refunds_total:Number(row.refunds_total||0),seller_net_payable:Number(row.seller_net_payable||0),payout_amount:Number(row.payout_amount||0),attempt_count:Number(row.attempt_count||0),created_at:row.created_at||null,updated_at:row.updated_at||null,last_error:row.last_error||null}));
  return Response.json({ok:true,seller:{seller_id:sellerId,display_name:seller.display_name||seller.business_name||"",settlement_status:String(seller.settlement_status||"active")},settlements:safeSettlements,batches:safeBatches,summary:{ready_amount:round(safeSettlements.filter((r:any)=>r.payout_status==="ready").reduce((n:number,r:any)=>n+r.payout_amount,0)),paid_amount:round(safeSettlements.reduce((n:number,r:any)=>n+r.paid_amount,0)),blocked_amount:round(safeSettlements.reduce((n:number,r:any)=>n+r.blocked_amount,0)),ready_count:safeSettlements.filter((r:any)=>r.payout_status==="ready").length},provider:{external_transfer_enabled:false,mode:"internal-truth-only"},financial_rules:{platform_fee_rate:0.08,distributor_commission:0}});
});
