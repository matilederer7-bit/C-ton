import { ErrorCode } from "../../shared/constitution.ts";
const encoder = new TextEncoder();

function fail(status:number,error:string,code?:string){return Response.json({ok:false,error,...(code?{code}:{})},{status});}
function stable(value:any):string{if(value===null||typeof value!=="object")return JSON.stringify(value);if(Array.isArray(value))return `[${value.map(stable).join(",")}]`;return `{${Object.keys(value).sort().map(k=>`${JSON.stringify(k)}:${stable(value[k])}`).join(",")}}`;}
function hex(bytes:ArrayBuffer){return [...new Uint8Array(bytes)].map(b=>b.toString(16).padStart(2,"0")).join("");}
async function sha256(value:string){return hex(await crypto.subtle.digest("SHA-256",encoder.encode(value)));}
async function hmac(secret:string,value:string){const key=await crypto.subtle.importKey("raw",encoder.encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);return hex(await crypto.subtle.sign("HMAC",key,encoder.encode(value)));}
async function sameSecret(a:string,b:string){if(!a||!b)return false;return (await sha256(a))===(await sha256(b));}
function validDestination(channel:string,destination:string){if(channel==="sms")return /^\+?[0-9]{7,15}$/.test(destination.replace(/[\s()-]/g,""));if(channel==="email")return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(destination);return false;}

Deno.serve(async(req)=>{
  if(req.method!=="POST")return fail(405,"method_not_allowed", ErrorCode.ForbiddenAction);
  let body:any;try{body=await req.json();}catch{return fail(400,"invalid JSON body",ErrorCode.InvalidInput);}
  const internalSecret=String(Deno.env.get("COMMUNICATION_INTERNAL_CALL_SECRET")||"");
  if(internalSecret.length<32)return fail(503,"communication internal secret is not configured", ErrorCode.TemporarilyUnavailable);
  if(!(await sameSecret(String(body?.internal_call_token||""),internalSecret)))return fail(403,"forbidden", ErrorCode.ForbiddenAction);

  const channel=String(body?.channel||"").trim().toLowerCase();
  const destination=String(body?.destination||"").trim();
  const templateKey=String(body?.template_key||"").trim().slice(0,160);
  const idempotencyKey=String(body?.idempotency_key||"").trim().slice(0,400);
  if(!["sms","email"].includes(channel)||!validDestination(channel,destination))return fail(400,"invalid communication destination", ErrorCode.InvalidInput);
  if(!templateKey||!idempotencyKey)return fail(400,"template_key and idempotency_key are required", ErrorCode.InvalidInput);

  const url=String(Deno.env.get("COMMUNICATION_PROVIDER_URL")||"").trim().replace(/\/+$/g,"");
  const providerSecret=String(Deno.env.get("COMMUNICATION_PROVIDER_SHARED_SECRET")||"");
  const providerCode=String(Deno.env.get("COMMUNICATION_PROVIDER_CODE")||"provider-ready").trim().slice(0,100);
  const mode=String(Deno.env.get("COMMUNICATION_PROVIDER_MODE")||"disabled").trim().toLowerCase();
  if(!url||providerSecret.length<32||mode==="disabled")return Response.json({ok:true,result_class:"skipped",provider:providerCode,provider_mode:"disabled",error_code:"communication_provider_not_connected",provider_message_id:null});
  if(!url.startsWith("https://")&&!url.startsWith("http://127.0.0.1")&&!url.startsWith("http://localhost"))return fail(503,"communication provider must use HTTPS", ErrorCode.TemporarilyUnavailable);

  const payload={channel,destination,template_key:templateKey,variables:body?.variables&&typeof body.variables==="object"?body.variables:{},locale:String(body?.locale||"he-IL"),idempotency_key:idempotencyKey};
  const timestamp=String(Math.floor(Date.now()/1000));
  const bodyText=stable(payload);const bodyHash=await sha256(bodyText);const path="/v1/messages/send";
  const signature=await hmac(providerSecret,`${timestamp}\nPOST\n${path}\n${bodyHash}`);
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),8000);
  try{
    const response=await fetch(`${url}${path}`,{method:"POST",headers:{"content-type":"application/json","x-siton-timestamp":timestamp,"x-siton-signature":signature,"idempotency-key":idempotencyKey},body:JSON.stringify(payload),signal:controller.signal});
    const data=await response.json().catch(()=>({}));
    if(response.ok){return Response.json({ok:true,result_class:"success",provider:providerCode,provider_mode:mode,provider_message_id:data?.provider_message_id?String(data.provider_message_id).slice(0,500):null});}
    const resultClass=response.status===429||response.status>=500?"temporary_fail":"permanent_fail";
    return Response.json({ok:true,result_class:resultClass,provider:providerCode,provider_mode:mode,provider_message_id:null,error_code:String(data?.code||`http_${response.status}`).slice(0,200),error_message:String(data?.error||"provider request failed").slice(0,1000)});
  }catch(error:any){
    return Response.json({ok:true,result_class:"unknown",provider:providerCode,provider_mode:mode,provider_message_id:null,error_code:error?.name==="AbortError"?"provider_timeout":"provider_network_error",error_message:"provider outcome is unknown"});
  }finally{clearTimeout(timer);}
});
