import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const DEFAULT_LEASE_MS = 60_000;

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (!user?.id || String(user.role || "") !== "admin") return fail(403, "admin worker authority required", ErrorCode.ForbiddenAction);

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const eventUuid = String(body?.event_uuid || "").trim();
  const leaseOwner = String(body?.lease_owner || "").trim();
  if (!eventUuid || !leaseOwner) return fail(400, "event_uuid and lease_owner are required", ErrorCode.InvalidInput);

  const now = new Date();
  const leaseMs = Math.max(5_000, Math.min(10 * 60_000, Number(body.lease_ms || DEFAULT_LEASE_MS)));
  const leaseExpiresAt = new Date(now.getTime() + leaseMs).toISOString();
  const result = await base44.asServiceRole.entities.OutboxEvent.updateMany(
    {
      event_uuid: eventUuid,
      status: "processing",
      lease_owner: leaseOwner,
      lease_expires_at: { $gt: now.toISOString() }
    },
    { $set: { lease_expires_at: leaseExpiresAt } }
  );
  if (Number(result?.updated || 0) !== 1) return fail(409, "worker lease is missing or expired", ErrorCode.NotInWindow);
  return Response.json({ ok: true, event_uuid: eventUuid, lease_owner: leaseOwner, lease_expires_at: leaseExpiresAt });
});
