import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const TYPES = new Set(["pause_joining_emergency", "pause_charging_emergency", "payout_freeze", "content_takedown"]);
const SCOPES = new Set(["global", "deal", "seller", "participant", "payout", "content"]);
const EMERGENCY = new Set(["pause_joining_emergency", "pause_charging_emergency"]);

function fail(status: number, error: string, code?: string) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}) }, { status });
}
function text(value: unknown, max: number) { return String(value ?? "").trim().slice(0, max); }
function isFuture(value: unknown) { const ms = Date.parse(String(value || "")); return Number.isFinite(ms) && ms > Date.now(); }
function isEmergency(flag: any) { return EMERGENCY.has(String(flag?.flag_type || "")); }
function event(type: string, actorUserId: string | null, payload: Record<string, unknown> = {}) {
  return { event_type: type, created_at: new Date().toISOString(), ...(actorUserId ? { actor_user_id: actorUserId } : { actor_type: "system" }), payload };
}
function stable(value: any): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stable).join(",")}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stable(value[key])}`).join(",")}}`;
}
function bytesToHex(bytes: ArrayBuffer) {
  return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function signControlEvent(value: Record<string, unknown>) {
  const secret = String(Deno.env.get("ADMIN_CONTROL_INTEGRITY_SECRET") || "");
  if (secret.length < 32) throw Object.assign(new Error("ADMIN_CONTROL_INTEGRITY_SECRET is required for emergency approvals"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return bytesToHex(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(stable(value))));
}
async function validSignedAudit(row: any) {
  if (!row?.signature) return false;
  const canonical = {
    event_id: String(row.event_id), flag_id: String(row.flag_id), event_type: String(row.event_type), flag_type: String(row.flag_type),
    scope_type: String(row.scope_type), scope_id: row.scope_id ? String(row.scope_id) : null,
    requested_by_user_id: String(row.requested_by_user_id), approved_by_user_id: String(row.approved_by_user_id),
    created_at: String(row.created_at), expires_at: row.expires_at ? String(row.expires_at) : null, reason: row.reason ? String(row.reason) : null,
    activation_event_id: row.activation_event_id ? String(row.activation_event_id) : null,
    activation_signature: row.activation_signature ? String(row.activation_signature) : null,
    signature_version: String(row.signature_version || "hmac-sha256-v1")
  };
  return (await signControlEvent(canonical)) === String(row.signature);
}
async function appendSignedAudit(admin: any, args: any) {
  const canonical = {
    event_id: crypto.randomUUID(),
    flag_id: String(args.flag_id),
    event_type: String(args.event_type),
    flag_type: String(args.flag_type),
    scope_type: String(args.scope_type),
    scope_id: args.scope_id ? String(args.scope_id) : null,
    requested_by_user_id: String(args.requested_by_user_id),
    approved_by_user_id: String(args.approved_by_user_id),
    created_at: String(args.created_at),
    expires_at: args.expires_at ? String(args.expires_at) : null,
    reason: args.reason ? String(args.reason) : null,
    activation_event_id: args.activation_event_id ? String(args.activation_event_id) : null,
    activation_signature: args.activation_signature ? String(args.activation_signature) : null,
    signature_version: "hmac-sha256-v1"
  };
  const signature = await signControlEvent(canonical);
  return admin.entities.AdminControlAudit.create({ ...canonical, signature });
}

async function loadFlag(admin: any, flagId: string) {
  return (await admin.entities.AdminControlFlag.filter({ flag_id: flagId }, "-created_at", 1))?.[0] || null;
}

async function expireElapsedFlags(admin: any) {
  const candidates = await admin.entities.AdminControlFlag.filter({ status: { $in: ["active", "pending_approval"] } }, "-created_at", 1000).catch(() => []);
  const now = Date.now();
  for (const row of candidates || []) {
    if (!row.expires_at) continue;
    const expiry = Date.parse(String(row.expires_at));
    if (!Number.isFinite(expiry) || expiry > now) continue;
    await admin.entities.AdminControlFlag.updateMany(
      { flag_id: String(row.flag_id), status: String(row.status) },
      {
        $set: { status: "expired" },
        $push: { event_journal: event("control_flag.expired", null, { flag_type: row.flag_type, scope_type: row.scope_type, scope_id: row.scope_id || null }) }
      }
    ).catch(() => undefined);
  }
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (String(user?.role || "") !== "admin") return fail(403, "admin required", ErrorCode.ForbiddenAction);
  const admin = base44.asServiceRole;
  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const operation = String(body?.operation || "list");
  const actorId = String(user.id || "");

  await expireElapsedFlags(admin);

  if (operation === "list") {
    const rows = await admin.entities.AdminControlFlag.list("-created_at", 1000).catch(() => []);
    const flags = (rows || []).map((row: any) => ({
      flag_id: row.flag_id,
      flag_type: row.flag_type,
      scope_type: row.scope_type,
      scope_id: row.scope_id || null,
      reason: row.reason,
      status: row.status,
      expires_at: row.expires_at || null,
      created_at: row.created_at || row.created_date || null,
      created_by_user_id: row.created_by_user_id || null,
      approved_by_user_id: row.approved_by_user_id || null,
      approved_at: row.approved_at || null,
      release_requested_by_user_id: row.release_requested_by_user_id || null,
      release_requested_at: row.release_requested_at || null,
      release_request_reason: row.release_request_reason || null,
      released_by_user_id: row.released_by_user_id || null,
      released_at: row.released_at || null,
      release_reason: row.release_reason || null,
      emergency: isEmergency(row),
      event_count: Array.isArray(row.event_journal) ? row.event_journal.length : 0
    }));
    return Response.json({
      ok: true,
      flags,
      summary: {
        active: flags.filter((row: any) => row.status === "active").length,
        pending_approval: flags.filter((row: any) => row.status === "pending_approval").length,
        pending_release: flags.filter((row: any) => row.status === "active" && row.release_requested_at).length,
        expired: flags.filter((row: any) => row.status === "expired").length,
        released: flags.filter((row: any) => row.status === "released").length,
        joining_pauses: flags.filter((row: any) => row.status === "active" && row.flag_type === "pause_joining_emergency").length,
        charging_pauses: flags.filter((row: any) => row.status === "active" && row.flag_type === "pause_charging_emergency").length
      }
    });
  }

  if (operation === "create") {
    const flagType = String(body.flag_type || "");
    const scopeType = String(body.scope_type || "");
    const scopeId = text(body.scope_id, 200);
    const reason = text(body.reason, 2000);
    const idem = text(body.idempotency_key, 300) || `flag:${crypto.randomUUID()}`;
    if (!TYPES.has(flagType)) return fail(400, "invalid flag_type", ErrorCode.InvalidInput);
    if (!SCOPES.has(scopeType)) return fail(400, "invalid scope_type", ErrorCode.InvalidInput);
    if (scopeType !== "global" && !scopeId) return fail(400, "scope_id is required for non-global scope", ErrorCode.InvalidInput);
    if (!reason) return fail(400, "reason is required", ErrorCode.InvalidInput);
    if (EMERGENCY.has(flagType) && !isFuture(body.expires_at)) return fail(400, "emergency pause requires a future expires_at", ErrorCode.InvalidInput);
    const prior = await admin.entities.AdminControlFlag.filter({ idempotency_key: idem }, "-created_at", 1);
    if (prior?.[0]) return Response.json({ ok: true, flag: prior[0], replay: true });

    const at = new Date().toISOString();
    const emergency = EMERGENCY.has(flagType);
    const status = emergency ? "pending_approval" : "active";
    const created = await admin.entities.AdminControlFlag.create({
      flag_id: crypto.randomUUID(),
      flag_type: flagType,
      scope_type: scopeType,
      scope_id: scopeId || null,
      reason,
      status,
      expires_at: body.expires_at || null,
      created_by_user_id: actorId,
      created_at: at,
      idempotency_key: idem,
      event_journal: [event(emergency ? "control_flag.activation_requested" : "control_flag.create", actorId, { flag_type: flagType, scope_type: scopeType, scope_id: scopeId || null, reason, expires_at: body.expires_at || null })]
    });
    return Response.json({ ok: true, flag: created, replay: false, second_admin_required: emergency });
  }

  const flagId = text(body.flag_id, 80);
  if (!flagId) return fail(400, "flag_id is required", ErrorCode.InvalidInput);
  const flag = await loadFlag(admin, flagId);
  if (!flag) return fail(404, "control flag not found", ErrorCode.InvalidInput);

  if (operation === "approve") {
    if (!isEmergency(flag)) return fail(409, "second approval is only used for emergency pauses", ErrorCode.IllegalStateTransition);
    if (flag.status === "active" && flag.approved_by_user_id) return Response.json({ ok: true, flag, replay: true });
    if (flag.status !== "pending_approval") return fail(409, "flag is not pending approval", ErrorCode.IllegalStateTransition);
    if (String(flag.created_by_user_id || "") === actorId) return fail(409, "a different admin must approve the emergency pause", ErrorCode.IllegalStateTransition);
    if (!isFuture(flag.expires_at)) return fail(409, "emergency pause approval expired", ErrorCode.NotInWindow);
    const at = new Date().toISOString();
    let activationAudit: any;
    try {
      activationAudit = await appendSignedAudit(admin, {
        flag_id: flagId,
        event_type: "activation_approved",
        flag_type: flag.flag_type,
        scope_type: flag.scope_type,
        scope_id: flag.scope_id || null,
        requested_by_user_id: flag.created_by_user_id,
        approved_by_user_id: actorId,
        created_at: at,
        expires_at: flag.expires_at || null,
        reason: flag.reason || null
      });
    } catch (error: any) {
      return fail(Number(error?.status || 503), String(error?.message || "control integrity audit failed"), String(error?.code || "control_integrity_unavailable"));
    }
    const result = await admin.entities.AdminControlFlag.updateMany(
      { flag_id: flagId, status: "pending_approval", created_by_user_id: String(flag.created_by_user_id || "") },
      {
        $set: { status: "active", approved_by_user_id: actorId, approved_at: at },
        $push: { event_journal: event("control_flag.activation_approved", actorId, { requested_by_user_id: flag.created_by_user_id }) }
      }
    );
    if (Number(result?.updated || 0) !== 1) {
      const latest = await loadFlag(admin, flagId);
      if (!(latest?.status === "active" && latest?.approved_by_user_id)) return fail(409, "approval lost conditional update", ErrorCode.IllegalStateTransition);
    }
    return Response.json({ ok: true, flag: await loadFlag(admin, flagId), activation_audit_id: activationAudit.event_id, replay: false });
  }

  if (operation === "release") {
    if (isEmergency(flag)) return fail(409, "emergency pause release requires release_request followed by release_approve", ErrorCode.IllegalStateTransition);
    if (flag.status === "released") return Response.json({ ok: true, flag, replay: true });
    if (flag.status !== "active") return fail(409, "only active flags can be released", ErrorCode.IllegalStateTransition);
    const at = new Date().toISOString();
    const reason = text(body.release_reason, 2000);
    const result = await admin.entities.AdminControlFlag.updateMany(
      { flag_id: flagId, status: "active" },
      {
        $set: { status: "released", released_by_user_id: actorId, released_at: at, release_reason: reason || null },
        $push: { event_journal: event("control_flag.release", actorId, { release_reason: reason || null }) }
      }
    );
    if (Number(result?.updated || 0) !== 1) return fail(409, "release lost conditional update", ErrorCode.IllegalStateTransition);
    return Response.json({ ok: true, flag: await loadFlag(admin, flagId), replay: false });
  }

  if (operation === "release_request") {
    if (!isEmergency(flag)) return fail(409, "release_request is only required for emergency pauses", ErrorCode.IllegalStateTransition);
    if (flag.status === "released") return Response.json({ ok: true, flag, replay: true });
    if (flag.status !== "active") return fail(409, "only active emergency flags can request release", ErrorCode.IllegalStateTransition);
    if (flag.release_requested_at) return Response.json({ ok: true, flag, replay: true, second_admin_required: true });
    const at = new Date().toISOString();
    const reason = text(body.release_reason, 2000);
    const result = await admin.entities.AdminControlFlag.updateMany(
      { flag_id: flagId, status: "active", release_requested_at: { $exists: false } },
      {
        $set: { release_requested_by_user_id: actorId, release_requested_at: at, release_request_reason: reason || null },
        $push: { event_journal: event("control_flag.release_requested", actorId, { release_reason: reason || null }) }
      }
    );
    if (Number(result?.updated || 0) !== 1) {
      const latest = await loadFlag(admin, flagId);
      if (latest?.release_requested_at) return Response.json({ ok: true, flag: latest, replay: true, second_admin_required: true });
      return fail(409, "release request lost conditional update", ErrorCode.IllegalStateTransition);
    }
    return Response.json({ ok: true, flag: await loadFlag(admin, flagId), replay: false, second_admin_required: true });
  }

  if (operation === "release_approve") {
    if (!isEmergency(flag)) return fail(409, "release approval is only used for emergency pauses", ErrorCode.IllegalStateTransition);
    if (flag.status === "released") return Response.json({ ok: true, flag, replay: true });
    if (flag.status !== "active") return fail(409, "emergency flag is not active", ErrorCode.IllegalStateTransition);
    const requester = String(flag.release_requested_by_user_id || "");
    if (!requester || !flag.release_requested_at) return fail(409, "release was not requested", ErrorCode.IllegalStateTransition);
    if (requester === actorId) return fail(409, "a different admin must approve the emergency release", ErrorCode.IllegalStateTransition);
    const at = new Date().toISOString();
    const activationEvents = await admin.entities.AdminControlAudit.filter({ flag_id: flagId, event_type: "activation_approved" }, "-created_at", 50).catch(() => []);
    let activation: any = null;
    try {
      for (const candidate of activationEvents || []) {
        if (await validSignedAudit(candidate)) { activation = candidate; break; }
      }
    } catch (error: any) {
      return fail(Number(error?.status || 503), String(error?.message || "control integrity verification failed"), String(error?.code || "control_integrity_unavailable"));
    }
    if (!activation) return fail(409, "signed activation audit is missing", ErrorCode.IllegalStateTransition);
    let releaseAudit: any;
    try {
      releaseAudit = await appendSignedAudit(admin, {
        flag_id: flagId,
        event_type: "release_approved",
        flag_type: flag.flag_type,
        scope_type: flag.scope_type,
        scope_id: flag.scope_id || null,
        requested_by_user_id: requester,
        approved_by_user_id: actorId,
        created_at: at,
        expires_at: flag.expires_at || null,
        reason: flag.release_request_reason || null,
        activation_event_id: activation.event_id,
        activation_signature: activation.signature
      });
    } catch (error: any) {
      return fail(Number(error?.status || 503), String(error?.message || "control integrity audit failed"), String(error?.code || "control_integrity_unavailable"));
    }
    const result = await admin.entities.AdminControlFlag.updateMany(
      { flag_id: flagId, status: "active", release_requested_by_user_id: requester },
      {
        $set: { status: "released", released_by_user_id: actorId, released_at: at, release_reason: String(flag.release_request_reason || "") || null },
        $push: { event_journal: event("control_flag.release_approved", actorId, { requested_by_user_id: requester, release_reason: flag.release_request_reason || null }) }
      }
    );
    if (Number(result?.updated || 0) !== 1) {
      const latest = await loadFlag(admin, flagId);
      if (latest?.status !== "released") return fail(409, "release approval lost conditional update", ErrorCode.IllegalStateTransition);
    }
    return Response.json({ ok: true, flag: await loadFlag(admin, flagId), release_audit_id: releaseAudit.event_id, replay: false });
  }

  return fail(400, "unsupported control operation", ErrorCode.InvalidInput);
});