import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, RefreshCw, ShieldAlert, ShieldCheck, Database, Activity, Store, CreditCard, LifeBuoy } from "lucide-react";

const STATE_LABELS = {
  Draft: "טיוטה",
  PendingTarget: "ממתינה ליעד",
  TargetReached: "היעד הושג",
  ClosedForJoining: "סגורה להצטרפות",
  ReadyForCharging: "מוכנה לחיוב",
  Charging: "בתהליך חיוב",
  CompletionWindow: "חלון השלמה",
  Completed: "הושלמה",
  Failed: "נכשלה",
  Cancelled: "בוטלה",
};

function Metric({ icon: Icon, label, value, hint = "" }) {
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm text-slate-500">{label}</div>
          <div className="mt-1 text-2xl font-bold">{value ?? 0}</div>
          {hint && <div className="mt-1 text-xs text-slate-500">{hint}</div>}
        </div>
        <div className="rounded-lg bg-slate-100 p-2"><Icon className="h-5 w-5 text-slate-700" /></div>
      </div>
    </Card>
  );
}

function StateGrid({ states = {} }) {
  const ordered = Object.keys(STATE_LABELS);
  return (
    <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
      {ordered.map((state) => (
        <div key={state} className="rounded-lg border bg-white p-3">
          <div className="text-xs text-slate-500">{STATE_LABELS[state]}</div>
          <div className="mt-1 text-xl font-semibold">{states[state] || 0}</div>
        </div>
      ))}
    </div>
  );
}

export default function AdminOverview() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await base44.functions.invoke("admin-overview", {});
      setData(response?.data || response);
    } catch (e) {
      const body = e?.response?.data;
      setError(body?.error || e?.message || "לא ניתן לטעון את מסך הניהול");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const queue = data?.queue || {};
  const support = data?.support_readiness || {};
  const safetyBlocked = data?.safety?.join_enabled === false;

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-5 sm:px-6">
          <div>
            <div className="flex items-center gap-2 text-sm font-medium text-indigo-700"><ShieldCheck className="h-4 w-4" /> ניהול סיטון</div>
            <h1 className="mt-1 text-2xl font-bold">Mission Control</h1>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="outline"><Link to="/admin/search">Omnisearch</Link></Button>
            <Button asChild variant="outline"><Link to="/admin/system">System Status</Link></Button>
            <Button asChild variant="outline"><Link to="/admin/deals">עסקאות וחריגים</Link></Button>
            <Button asChild variant="outline"><Link to="/admin/controls">בקרות חירום</Link></Button>
            <Button asChild variant="outline"><Link to="/admin/payouts">Payouts</Link></Button>
            <Button asChild variant="outline"><Link to="/admin/notifications">התראות</Link></Button>
            <Button asChild variant="outline"><Link to="/admin/forensics">פורנזיקה</Link></Button>
            <Button asChild variant="outline"><Link to="/admin/distribution">מקורות הפצה</Link></Button>
            <Button asChild variant="outline"><Link to="/admin/support">מרכז תמיכה</Link></Button>
            <Button asChild variant="outline"><Link to="/admin/sellers">ניהול מוכרים</Link></Button>
            <Button variant="outline" onClick={load} disabled={loading} className="gap-2"><RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />רענון</Button>
            <Button asChild variant="outline"><Link to="/" className="gap-2"><ArrowRight className="h-4 w-4" />חזרה</Link></Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6">
        {error && <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
        {loading && !data ? <div className="py-16 text-center text-slate-500">טוען נתוני מערכת...</div> : data && (
          <>
            <div className={`flex items-start gap-3 rounded-xl border p-4 ${safetyBlocked ? "border-amber-200 bg-amber-50" : "border-emerald-200 bg-emerald-50"}`}>
              {safetyBlocked ? <ShieldAlert className="mt-0.5 h-5 w-5 text-amber-700" /> : <ShieldCheck className="mt-0.5 h-5 w-5 text-emerald-700" />}
              <div>
                <div className="font-semibold">{safetyBlocked ? "Join חסום מטעמי בטיחות" : "Join פעיל"}</div>
                <div className="mt-1 text-sm text-slate-600">{safetyBlocked ? "מבחן מקביליות אמיתי הוכיח שה-Reservation עדיין אינו מונע Oversell באופן קשיח. אין כסף אמיתי פעיל." : "מנגנון ההצטרפות פעיל."}</div>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              <Metric icon={Database} label="עסקאות" value={data.counts?.deals} />
              <Metric icon={Store} label="מוכרים" value={data.counts?.sellers} />
              <Metric icon={Activity} label="אירועי Outbox" value={data.counts?.outbox} hint={`${queue.pending || 0} ממתינים`} />
              <Metric icon={CreditCard} label="ניסיונות תשלום" value={data.counts?.payment_attempts} hint="ללא כסף אמיתי כרגע" />
              <Metric icon={LifeBuoy} label="Support Cases" value={data.counts?.support_cases} hint={`${support.open || 0} פתוחים · ${support.overdue_count || 0} בחריגת SLA`} />
            </div>

            {support.verdict && support.verdict !== "ready" && <Card className={`p-4 ${support.verdict === "blocked" ? "border-red-200 bg-red-50" : "border-amber-200 bg-amber-50"}`}>
              <div className="flex items-start gap-3"><ShieldAlert className={`mt-0.5 h-5 w-5 ${support.verdict === "blocked" ? "text-red-700" : "text-amber-700"}`} /><div><div className="font-semibold">Support readiness: {support.verdict}</div><div className="mt-1 text-sm text-slate-600">{support.urgent_open || 0} Urgent פתוחים, {support.high_open || 0} High פתוחים, {support.overdue_count || 0} חריגות SLA.</div></div></div>
            </Card>}

            <Card className="p-5">
              <div className="mb-4 flex items-center justify-between gap-3"><h2 className="text-lg font-semibold">עסקאות לפי מצב</h2><span className="text-xs text-slate-500">עדכון {new Date(data.generated_at).toLocaleString("he-IL")}</span></div>
              <StateGrid states={data.deal_states} />
            </Card>

            <div className="grid gap-4 lg:grid-cols-2">
              <Card className="p-5">
                <h2 className="text-lg font-semibold">Worker ו־Outbox</h2>
                <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
                  {[['ממתינים', queue.pending], ['בעבודה', queue.processing], ['נכשלו', queue.failed], ['Lease שפג', queue.stale_processing], ['DLQ', queue.dlq], ['Dead letter projection', queue.dead_letter_projection]].map(([label, value]) => (
                    <div key={label} className="rounded-lg border bg-slate-50 p-3"><div className="text-xs text-slate-500">{label}</div><div className="mt-1 text-xl font-semibold">{value || 0}</div></div>
                  ))}
                </div>
              </Card>
              <Card className="p-5">
                <h2 className="text-lg font-semibold">מוכרים ותשלומים</h2>
                <div className="mt-4 space-y-3">
                  <div><div className="mb-2 text-xs text-slate-500">סטטוסי מוכרים</div><div className="flex flex-wrap gap-2">{Object.entries(data.seller_statuses || {}).map(([key, value]) => <Badge key={key} variant="secondary">{key}: {value}</Badge>)}</div></div>
                  <div><div className="mb-2 text-xs text-slate-500">תוצאות ניסיונות תשלום</div><div className="flex flex-wrap gap-2">{Object.entries(data.payment_results || {}).map(([key, value]) => <Badge key={key} variant="outline">{key}: {value}</Badge>)}</div></div>
                </div>
              </Card>
            </div>

            <Card className="overflow-hidden">
              <div className="border-b px-5 py-4"><h2 className="text-lg font-semibold">עסקאות אחרונות</h2></div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 text-right text-xs text-slate-500"><tr><th className="px-4 py-3">עסקה</th><th className="px-4 py-3">מוכר</th><th className="px-4 py-3">מצב</th><th className="px-4 py-3">יחידות</th><th className="px-4 py-3">דדליין</th></tr></thead>
                  <tbody className="divide-y">{(data.recent_deals || []).map((deal) => <tr key={deal.deal_id}><td className="px-4 py-3"><div className="font-medium">{deal.title}</div><div className="mt-1 text-xs text-slate-400">{deal.deal_id}</div></td><td className="px-4 py-3">{deal.seller_display_name || deal.seller_id}</td><td className="px-4 py-3"><Badge variant="outline">{STATE_LABELS[deal.state] || deal.state}</Badge></td><td className="px-4 py-3">{deal.reserved_units || 0} / {deal.max_units || 0}</td><td className="px-4 py-3">{deal.deadline ? new Date(deal.deadline).toLocaleString("he-IL") : "—"}</td></tr>)}</tbody>
                </table>
              </div>
            </Card>

            {(data.recent_dlq || []).length > 0 && <Card className="p-5"><h2 className="text-lg font-semibold text-red-800">אירועי DLQ אחרונים</h2><div className="mt-3 space-y-2">{data.recent_dlq.map((row) => <div key={row.event_uuid} className="rounded-lg border border-red-100 bg-red-50 p-3 text-sm"><div className="font-medium">{row.event_type} · {row.attempt_count} ניסיונות</div><div className="mt-1 break-words text-xs text-red-700">{row.last_error || "ללא פירוט שגיאה"}</div></div>)}</div></Card>}
          </>
        )}
      </main>
    </div>
  );
}
