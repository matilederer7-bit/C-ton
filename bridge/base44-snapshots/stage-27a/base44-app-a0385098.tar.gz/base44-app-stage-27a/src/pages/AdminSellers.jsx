import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowRight, RefreshCw, ShieldCheck } from "lucide-react";

const SELLER_STATUSES = ["Active", "UnderReview", "Restricted", "Suspended", "Banned"];
const SETTLEMENT_STATUSES = ["active", "review", "hold"];

function formatDate(value) {
  if (!value) return "—";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "—";
  return new Intl.DateTimeFormat("he-IL", { dateStyle: "short", timeStyle: "short" }).format(d);
}

export default function AdminSellers() {
  const [sellers, setSellers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [notes, setNotes] = useState({});
  const [statuses, setStatuses] = useState({});
  const [settlementStatuses, setSettlementStatuses] = useState({});

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await base44.functions.invoke("admin-sellers", {});
      const result = response?.data || response;
      setSellers(result?.sellers || []);
      setStatuses(Object.fromEntries((result?.sellers || []).map((seller) => [seller.seller_id, seller.seller_status])));
      setSettlementStatuses(Object.fromEntries((result?.sellers || []).map((seller) => [seller.seller_id, seller.settlement_status || "active"])));
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "לא ניתן לטעון מוכרים");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const updateSettlement = async (seller) => {
    setBusy(`settlement:${seller.seller_id}`);
    setError("");
    try {
      await base44.functions.invoke("admin-sellers", {
        operation: "set_settlement_status",
        seller_id: seller.seller_id,
        settlement_status: settlementStatuses[seller.seller_id] || seller.settlement_status || "active",
        reason: notes[seller.seller_id] || "",
      });
      await load();
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "עדכון Settlement נכשל");
    } finally {
      setBusy("");
    }
  };

  const review = async (seller, payload) => {
    setBusy(seller.seller_id);
    setError("");
    try {
      await base44.functions.invoke("admin-review-seller", {
        seller_id: seller.seller_id,
        note: notes[seller.seller_id] || "",
        ...payload,
      });
      await load();
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "עדכון המוכר נכשל");
    } finally {
      setBusy("");
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-5 sm:px-6">
          <div>
            <div className="flex items-center gap-2 text-sm font-medium text-indigo-700"><ShieldCheck className="h-4 w-4" />ניהול סיטון</div>
            <h1 className="mt-1 text-2xl font-bold">ביקורת מוכרים ו־KYC</h1>
            <p className="mt-1 text-sm text-slate-500">אישור KYC תקף רק לאחר פעולה מפורשת במסך זה ונשמר ב־audit trail.</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={load} disabled={loading} className="gap-2"><RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />רענון</Button>
            <Button asChild variant="outline"><Link to="/admin" className="gap-2"><ArrowRight className="h-4 w-4" />חזרה לניהול</Link></Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-4 px-4 py-6 sm:px-6">
        {error && <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
        {loading ? <Card className="p-10 text-center text-slate-500">טוען מוכרים...</Card> : sellers.length === 0 ? <Card className="p-10 text-center text-slate-500">אין מוכרים להצגה.</Card> : sellers.map((seller) => (
          <Card key={seller.seller_id} className="p-5">
            <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-lg font-semibold">{seller.business_name || seller.display_name || seller.seller_id}</h2>
                  <Badge variant={seller.kyc_effective_approved ? "default" : "secondary"}>{seller.kyc_effective_approved ? "KYC מאושר" : `KYC: ${seller.verification_status}`}</Badge>
                  <Badge variant="outline">{seller.seller_status}</Badge>
                  <Badge variant="outline">Settlement: {seller.settlement_status || "active"}</Badge>
                </div>
                <div className="mt-1 break-all text-xs text-slate-500">{seller.seller_id}</div>
                <div className="mt-4 grid gap-3 text-sm sm:grid-cols-2 lg:grid-cols-4">
                  <div><div className="text-xs text-slate-500">שם תצוגה</div><div className="mt-1">{seller.display_name || "—"}</div></div>
                  <div><div className="text-xs text-slate-500">טלפון שירות</div><div className="mt-1">{seller.support_phone || "—"}</div></div>
                  <div><div className="text-xs text-slate-500">מייל שירות</div><div className="mt-1 break-all">{seller.support_email || "—"}</div></div>
                  <div><div className="text-xs text-slate-500">ביקורת KYC אחרונה</div><div className="mt-1">{formatDate(seller.verification_reviewed_at)}</div></div>
                </div>
                {seller.verification_status === "approved" && !seller.kyc_effective_approved && (
                  <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">האישור הישן אינו תקף ל־Publish כי חסרה חותמת ביקורת Admin. יש לאשר מחדש.</div>
                )}
                {seller.latest_review && <div className="mt-4 rounded-lg bg-slate-50 p-3 text-xs text-slate-600">ביקורת אחרונה: {formatDate(seller.latest_review.created_at)} · {seller.latest_review.note || "ללא הערה"}</div>}
              </div>

              <div className="w-full space-y-3 lg:w-80">
                <Input value={notes[seller.seller_id] || ""} onChange={(e) => setNotes((prev) => ({ ...prev, [seller.seller_id]: e.target.value }))} placeholder="הערת ביקורת אופציונלית" maxLength={500} />
                <div className="grid grid-cols-3 gap-2">
                  <Button disabled={busy === seller.seller_id} onClick={() => review(seller, { verification_status: "approved" })}>אשר KYC</Button>
                  <Button variant="outline" disabled={busy === seller.seller_id} onClick={() => review(seller, { verification_status: "pending" })}>החזר לבדיקה</Button>
                  <Button variant="destructive" disabled={busy === seller.seller_id} onClick={() => review(seller, { verification_status: "rejected" })}>דחה</Button>
                </div>
                <div className="flex gap-2">
                  <Select value={statuses[seller.seller_id] || seller.seller_status} onValueChange={(value) => setStatuses((prev) => ({ ...prev, [seller.seller_id]: value }))}>
                    <SelectTrigger className="flex-1"><SelectValue /></SelectTrigger>
                    <SelectContent>{SELLER_STATUSES.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent>
                  </Select>
                  <Button variant="outline" disabled={busy === seller.seller_id || (statuses[seller.seller_id] || seller.seller_status) === seller.seller_status} onClick={() => review(seller, { seller_status: statuses[seller.seller_id] })}>עדכן סטטוס</Button>
                </div>
                <div className="flex gap-2">
                  <Select value={settlementStatuses[seller.seller_id] || seller.settlement_status || "active"} onValueChange={(value) => setSettlementStatuses((prev) => ({ ...prev, [seller.seller_id]: value }))}>
                    <SelectTrigger className="flex-1"><SelectValue /></SelectTrigger>
                    <SelectContent>{SETTLEMENT_STATUSES.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent>
                  </Select>
                  <Button variant="outline" disabled={busy === `settlement:${seller.seller_id}` || (settlementStatuses[seller.seller_id] || seller.settlement_status || "active") === (seller.settlement_status || "active")} onClick={() => updateSettlement(seller)}>עדכן Settlement</Button>
                </div>
                <p className="text-xs leading-5 text-slate-500">שינוי Settlement דורש Reason בשדה ההערה. `review` או `hold` חוסמים Payout אך אינם משנים KYC או seller_status.</p>
                <p className="text-xs leading-5 text-slate-500">`UnderReview`, `Restricted`, `Suspended` ו־`Banned` חוסמים Publish. Draft נשאר אפשרי לפי כללי המערכת.</p>
              </div>
            </div>
          </Card>
        ))}
      </main>
    </div>
  );
}
