import React, { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BadgeCheck, Clock3, Package, Plus, RefreshCw, ShieldCheck } from "lucide-react";

const initialForm = () => ({
  title: "",
  short_description: "",
  what_you_get: "",
  deal_type: "physical_product",
  price_per_unit: "",
  min_units: "10",
  max_units: "20",
  deadline_hours: "24",
  delivery_label: "איסוף עצמי",
  delivery_cost: "0",
  voucher_face_value: "",
  ticket_event_name: "",
  ticket_event_starts_at: "",
});

function money(value) {
  const n = Number(value || 0);
  return new Intl.NumberFormat("he-IL", { style: "currency", currency: "ILS", maximumFractionDigits: 2 }).format(n);
}

function dealTypeLabel(type) {
  if (type === "voucher") return "שובר";
  if (type === "ticket") return "כרטיס";
  return "מוצר פיזי";
}

export default function Home() {
  const [searchParams] = useSearchParams();
  const [form, setForm] = useState(initialForm);
  const [deals, setDeals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [publishingId, setPublishingId] = useState("");
  const [cloneNotice, setCloneNotice] = useState("");

  const threshold = useMemo(() => Math.ceil(0.9 * Math.max(1, Number(form.min_units || 1))), [form.min_units]);

  const loadDeals = async () => {
    setLoading(true);
    try {
      const response = await base44.functions.invoke("seller-deals", {});
      const result = response?.data || response;
      setDeals(result?.deals || []);
    } catch (e) {
      setError(e?.message || "לא ניתן לטעון עסקאות");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDeals();
    if (searchParams.get("clone") === "1") {
      try {
        const raw = window.sessionStorage.getItem("siton_clone_deal");
        if (raw) {
          const clone = JSON.parse(raw);
          setForm((current) => ({ ...current, ...clone, deadline_hours: "" }));
          setCloneNotice("פרטי העסקה הועתקו. חובה לבחור דדליין חדש לפני יצירת הטיוטה; חלון ההשלמה יוגדר מחדש לפי החוקה בעת החיוב.");
          window.sessionStorage.removeItem("siton_clone_deal");
        }
      } catch {
        setCloneNotice("");
      }
    }
  }, []);

  const setField = (name, value) => setForm((prev) => ({ ...prev, [name]: value }));

  const publishDeal = async (deal) => {
    const confirmed = window.confirm("פרסום העסקה יעביר אותה מ-Draft ל-PendingTarget. באישור אתה מאשר את תנאי המוכר, התנאים הקריטיים וכלל סף ה-90%. להמשיך?");
    if (!confirmed) return;
    setError("");
    setSuccess("");
    setPublishingId(deal.deal_id);
    try {
      const response = await base44.functions.invoke("publish-deal", {
        deal_id: deal.deal_id,
        seller_terms_accepted: true,
        seller_critical_terms_accepted: true,
        seller_threshold_90_accepted: true,
        idempotency_key: `publish:${deal.deal_id}`,
      });
      const result = response?.data || response;
      setSuccess(`העסקה פורסמה: ${result.deal_id}`);
      await loadDeals();
    } catch (e) {
      const body = e?.response?.data;
      setError(body?.error || e?.message || "פרסום העסקה נכשל");
    } finally {
      setPublishingId("");
    }
  };

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    setSuccess("");
    setSubmitting(true);
    try {
      const hours = Number(form.deadline_hours || 24);
      const payload = {
        title: form.title,
        short_description: form.short_description,
        what_you_get: form.what_you_get,
        deal_type: form.deal_type,
        price_per_unit: Number(form.price_per_unit),
        min_units: Number(form.min_units),
        max_units: Number(form.max_units),
        deadline: new Date(Date.now() + hours * 60 * 60 * 1000).toISOString(),
      };

      if (form.deal_type === "physical_product") {
        payload.delivery_options = [{
          option_type: "pickup",
          label: form.delivery_label || "איסוף עצמי",
          cost: Number(form.delivery_cost || 0),
          sort_order: 0,
        }];
      }
      if (form.deal_type === "voucher") {
        payload.voucher_terms = {
          face_value_amount: Number(form.voucher_face_value),
          currency: "ILS",
          voucher_code_mode: "system_generated",
        };
      }
      if (form.deal_type === "ticket") {
        payload.ticket_terms = {
          event_name: form.ticket_event_name,
          event_starts_at: form.ticket_event_starts_at
            ? new Date(form.ticket_event_starts_at).toISOString()
            : "",
          seat_mode: "general_admission",
          ticket_type: "general_admission",
        };
      }

      const response = await base44.functions.invoke("create-deal-draft", payload);
      const result = response?.data || response;
      setSuccess(`טיוטת העסקה נוצרה בהצלחה: ${result.deal_id}`);
      setForm(initialForm());
      await loadDeals();
    } catch (e) {
      const body = e?.response?.data;
      setError(body?.error || e?.message || "יצירת העסקה נכשלה");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-5 sm:px-6">
          <div>
            <div className="flex items-center gap-2 text-sm font-medium text-emerald-700">
              <ShieldCheck className="h-4 w-4" />
              Siton Base44 migration
            </div>
            <h1 className="mt-1 text-2xl font-bold tracking-tight">ראש הגשר של סיטון</h1>
            <p className="mt-1 text-sm text-slate-500">יכולת ראשונה: יצירת עסקת Draft ללא תלות ב־Render</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => { window.location.href = "/seller"; }}>
              דשבורד מוכר
            </Button>
            <Button variant="outline" onClick={() => { window.location.href = "/seller/profile"; }}>
              פרטי מוכר
            </Button>
            <Button variant="outline" onClick={loadDeals} disabled={loading} className="gap-2">
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              רענון
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto grid max-w-7xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,.95fr)]">
        <Card className="p-5 sm:p-6">
          <div className="mb-6 flex items-start justify-between gap-3">
            <div>
              <h2 className="text-xl font-semibold">יצירת עסקה חדשה</h2>
              <p className="mt-1 text-sm text-slate-500">הטופס כותב ישירות ל־Base44 דרך פונקציית Backend קנונית.</p>
            </div>
            <div className="rounded-full bg-orange-50 px-3 py-1 text-xs font-medium text-orange-700">Draft בלבד</div>
          </div>

          <form onSubmit={submit} className="space-y-5">
            {cloneNotice && <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800"><div className="font-semibold">עסקה דומה · נדרש עדכון זמן</div><div className="mt-1">{cloneNotice}</div></div>}
            <div className="space-y-2">
              <Label htmlFor="title">כותרת העסקה</Label>
              <Input id="title" value={form.title} onChange={(e) => setField("title", e.target.value)} maxLength={200} placeholder="לדוגמה: רכישה קבוצתית של..." required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="short-description">תיאור קצר</Label>
              <Textarea id="short-description" value={form.short_description} onChange={(e) => setField("short_description", e.target.value)} maxLength={1200} placeholder="מה העסקה ולמי היא מתאימה" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="what-you-get">מה מקבלים</Label>
              <Textarea id="what-you-get" value={form.what_you_get} onChange={(e) => setField("what_you_get", e.target.value)} maxLength={2000} placeholder="תכולת המוצר או השירות בצורה ברורה" />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>סוג העסקה</Label>
                <Select value={form.deal_type} onValueChange={(value) => setField("deal_type", value)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="physical_product">מוצר פיזי</SelectItem>
                    <SelectItem value="voucher">שובר</SelectItem>
                    <SelectItem value="ticket">כרטיס</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="price">מחיר ליחידה</Label>
                <Input id="price" type="number" min="0.01" step="0.01" value={form.price_per_unit} onChange={(e) => setField("price_per_unit", e.target.value)} required />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="min">יעד מינימום</Label>
                <Input id="min" type="number" min="1" step="1" value={form.min_units} onChange={(e) => setField("min_units", e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="max">מלאי מקסימלי</Label>
                <Input id="max" type="number" min="1" step="1" value={form.max_units} onChange={(e) => setField("max_units", e.target.value)} required />
              </div>
              <div className="rounded-lg border bg-slate-50 p-3">
                <div className="text-xs text-slate-500">סף נעילה קנוני</div>
                <div className="mt-1 text-2xl font-bold">{threshold}</div>
                <div className="text-xs text-slate-500">90% מהיעד</div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="deadline">דדליין בעוד שעות</Label>
              <Input id="deadline" type="number" min="2" max="168" step="1" value={form.deadline_hours} onChange={(e) => setField("deadline_hours", e.target.value)} required />
              <p className={`text-xs ${cloneNotice && !form.deadline_hours ? "font-semibold text-red-700" : "text-slate-500"}`}>{cloneNotice && !form.deadline_hours ? "חובה לבחור דדליין חדש. הדדליין של העסקה הקודמת לא הועתק." : "החוזה הקיים מאפשר שעתיים עד שבעה ימים."}</p>
            </div>

            {form.deal_type === "physical_product" && (
              <div className="grid gap-4 rounded-xl border bg-slate-50 p-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="delivery-label">אפשרות מסירה ראשונה</Label>
                  <Input id="delivery-label" value={form.delivery_label} onChange={(e) => setField("delivery_label", e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="delivery-cost">עלות מסירה</Label>
                  <Input id="delivery-cost" type="number" min="0" step="0.01" value={form.delivery_cost} onChange={(e) => setField("delivery_cost", e.target.value)} />
                </div>
              </div>
            )}

            {form.deal_type === "voucher" && (
              <div className="space-y-2 rounded-xl border bg-slate-50 p-4">
                <Label htmlFor="voucher-value">ערך נקוב של השובר</Label>
                <Input id="voucher-value" type="number" min="0.01" step="0.01" value={form.voucher_face_value} onChange={(e) => setField("voucher_face_value", e.target.value)} required />
              </div>
            )}

            {form.deal_type === "ticket" && (
              <div className="grid gap-4 rounded-xl border bg-slate-50 p-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="event-name">שם האירוע</Label>
                  <Input id="event-name" value={form.ticket_event_name} onChange={(e) => setField("ticket_event_name", e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="event-start">תחילת האירוע</Label>
                  <Input id="event-start" type="datetime-local" value={form.ticket_event_starts_at} onChange={(e) => setField("ticket_event_starts_at", e.target.value)} required />
                </div>
              </div>
            )}

            {error && <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}
            {success && <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-700">{success}</div>}

            <Button type="submit" disabled={submitting} className="w-full gap-2 sm:w-auto">
              <Plus className="h-4 w-4" />
              {submitting ? "יוצר טיוטה..." : "צור טיוטת עסקה"}
            </Button>
          </form>
        </Card>

        <div className="space-y-4">
          <Card className="p-5">
            <div className="grid grid-cols-3 gap-3 text-center">
              <div>
                <Package className="mx-auto h-5 w-5 text-slate-500" />
                <div className="mt-2 text-2xl font-bold">{deals.length}</div>
                <div className="text-xs text-slate-500">עסקאות בבייס</div>
              </div>
              <div>
                <BadgeCheck className="mx-auto h-5 w-5 text-emerald-600" />
                <div className="mt-2 text-2xl font-bold">{deals.filter((d) => d.state === "Draft").length}</div>
                <div className="text-xs text-slate-500">Draft</div>
              </div>
              <div>
                <Clock3 className="mx-auto h-5 w-5 text-orange-600" />
                <div className="mt-2 text-2xl font-bold">8%</div>
                <div className="text-xs text-slate-500">עמלת סיטון הקבועה</div>
              </div>
            </div>
            <p className="mt-4 border-t pt-4 text-xs leading-5 text-slate-500">העמלה הקנונית היא 8% על הכול כולל משלוח, למעט מע״מ. אין עמלת מפיצים.</p>
          </Card>

          <Card className="overflow-hidden">
            <div className="border-b px-5 py-4">
              <h2 className="font-semibold">העסקאות האחרונות</h2>
              <p className="mt-1 text-xs text-slate-500">נתונים חיים מישות Deal של Base44</p>
            </div>
            <div className="divide-y">
              {loading ? (
                <div className="p-8 text-center text-sm text-slate-500">טוען...</div>
              ) : deals.length === 0 ? (
                <div className="p-8 text-center text-sm text-slate-500">עוד לא נוצרה עסקה בבייס.</div>
              ) : deals.map((deal) => (
                <div key={deal.id} className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-medium">{deal.title}</div>
                      <div className="mt-1 text-xs text-slate-500">{dealTypeLabel(deal.deal_type)} · {deal.deal_id}</div>
                    </div>
                    <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium">{deal.state}</span>
                  </div>
                  <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
                    <div><span className="text-slate-500">מחיר</span><div className="font-medium">{money(deal.price_per_unit)}</div></div>
                    <div><span className="text-slate-500">יעד</span><div className="font-medium">{deal.min_units}</div></div>
                    <div><span className="text-slate-500">סף 90%</span><div className="font-medium">{deal.threshold_units}</div></div>
                  </div>
                  {deal.state === "Draft" ? (
                    <Button
                      type="button"
                      size="sm"
                      className="mt-3 w-full"
                      onClick={() => publishDeal(deal)}
                      disabled={publishingId === deal.deal_id}
                    >
                      {publishingId === deal.deal_id ? "מפרסם..." : "פרסם עסקה"}
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="mt-3 w-full"
                      onClick={() => window.open(`/deal/${deal.deal_id}`, "_blank", "noopener,noreferrer")}
                    >
                      פתח עמוד קונה
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}
