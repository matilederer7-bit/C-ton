import React, { useEffect, useMemo, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, CheckCircle2, Clock3, Copy, CreditCard, Gift, Mail, MessageCircle, PackageCheck, RefreshCw, Share2, ShieldAlert, Ticket, Truck, Users, XCircle } from "lucide-react";

const BUYER_LABELS = {
  NotJoined: "טרם הצטרפת",
  JoinedAuthorized: "הצטרפת והמסגרת נתפסה",
  LockedIn: "העסקה נסגרה להצטרפות",
  ChargingAttempt: "החיוב בתהליך",
  ChargedSuccess: "החיוב הצליח",
  ChargeFailedCompletion: "נדרש עדכון אמצעי תשלום",
  Recovered: "התשלום הושלם",
  Dropped: "ההשתתפות לא הושלמה",
  DealCompleted: "העסקה הושלמה",
  DealFailed: "העסקה נכשלה",
};

const MONEY_LABELS = {
  NoFinancial: "ללא פעולה כספית",
  AuthHeld: "תפיסת מסגרת",
  AuthLocked: "המסגרת נעולה",
  ChargeAttempt: "ניסיון חיוב",
  ChargedSuccess: "חויב בהצלחה",
  ChargeFailedRecovery: "החיוב נכשל, ממתין להשלמה",
  RecoveredCharge: "החיוב הושלם לאחר התאוששות",
  AuthReleased: "המסגרת שוחררה",
  Refunded: "הוחזר",
};

function formatMoney(value) {
  return new Intl.NumberFormat("he-IL", { style: "currency", currency: "ILS" }).format(Number(value || 0));
}

function StatusIcon({ buyerState }) {
  if (["DealCompleted", "ChargedSuccess", "Recovered"].includes(buyerState)) return <CheckCircle2 className="h-7 w-7 text-emerald-600" />;
  if (["DealFailed", "Dropped"].includes(buyerState)) return <XCircle className="h-7 w-7 text-red-600" />;
  if (buyerState === "ChargeFailedCompletion") return <ShieldAlert className="h-7 w-7 text-amber-600" />;
  return <Clock3 className="h-7 w-7 text-blue-600" />;
}

function dealStateLabel(state) {
  return ({ PendingTarget:"ממתינים להשלמת הכמות", TargetReached:"הכמות הושגה · העסקה יוצאת לפועל", ClosedForJoining:"הרשימה נסגרה", ReadyForCharging:"מתכוננים לחיוב", Charging:"החיובים מתבצעים כעת", CompletionWindow:"חלון השלמה פתוח", Completed:"העסקה הושלמה בהצלחה", Failed:"העסקה לא הושלמה", Cancelled:"העסקה בוטלה" })[state] || state || "—";
}

function remaining(value) {
  if (!value) return "—";
  const diff = new Date(value).getTime() - Date.now();
  if (!Number.isFinite(diff) || diff <= 0) return "הזמן הסתיים";
  const minutes = Math.floor(diff / 60000), days = Math.floor(minutes / 1440), hours = Math.floor((minutes % 1440) / 60), mins = minutes % 60;
  if (days > 0) return `${days} ימים ${hours} שעות`;
  if (hours > 0) return `${hours} שעות ${mins} דקות`;
  return `${mins} דקות`;
}

export default function BuyerTracking() {
  const { participantId } = useParams();
  const [searchParams] = useSearchParams();
  const token = searchParams.get("t") || "";
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [lastRefreshAt, setLastRefreshAt] = useState(null);
  const [shareStatus, setShareStatus] = useState("");

  const load = async ({ background = false } = {}) => {
    if (!background) setLoading(true);
    if (!background) setError("");
    try {
      const response = await base44.functions.invoke("get-buyer-tracking", { participant_id: participantId, tracking_token: token });
      const next = response?.data || response;
      setData(next);
      setLastRefreshAt(next?.refreshed_at ? new Date(next.refreshed_at) : new Date());
    } catch (e) {
      if (!background) {
        const body = e?.response?.data;
        setError(body?.error || e?.message || "לא ניתן לטעון את מצב ההשתתפות");
      }
    } finally {
      if (!background) setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const timer = window.setInterval(() => {
      if (document.visibilityState === "visible") load({ background: true });
    }, 15_000);
    return () => window.clearInterval(timer);
  }, [participantId, token]);

  const progress = useMemo(() => {
    const reserved = Number(data?.deal?.reserved_units || 0);
    const minimum = Math.max(1, Number(data?.deal?.min_units || 1));
    return Math.min(100, Math.round((reserved / minimum) * 100));
  }, [data]);

  const p = data?.participant;
  const deal = data?.deal;
  const units = data?.fulfillment_units || [];
  const shareUrl = typeof window !== "undefined" && p?.deal_id ? `${window.location.origin}/deal/${encodeURIComponent(p.deal_id)}` : "";
  const shareText = deal?.title ? `אני כבר הצטרפתי לעסקה בסיטון: ${deal.title}` : "אני כבר הצטרפתי לעסקה בסיטון";
  const canShare = ["PendingTarget", "TargetReached"].includes(deal?.state);
  const sellerPhoneDigits = String(deal?.seller_contact?.support_phone || "").replace(/\D/g, "");
  const sellerWhatsApp = sellerPhoneDigits ? (sellerPhoneDigits.startsWith("0") ? `972${sellerPhoneDigits.slice(1)}` : sellerPhoneDigits) : "";
  const openShare = (url) => window.open(url, "_blank", "noopener,noreferrer");
  const copyShare = async () => {
    try { await navigator.clipboard.writeText(shareUrl); setShareStatus("הלינק הועתק"); }
    catch { setShareStatus("לא ניתן להעתיק אוטומטית"); }
    window.setTimeout(() => setShareStatus(""), 2500);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
      <main className="mx-auto max-w-2xl px-4 py-8 sm:px-6">
        <div className="mb-6 text-center">
          <div className="text-sm font-medium text-slate-500">סיטון</div>
          <h1 className="mt-1 text-2xl font-bold">מעקב אחר ההשתתפות שלך</h1>
        </div>

        {loading && <Card className="p-10 text-center text-slate-500">טוען מצב עדכני...</Card>}
        {error && <Card className="border-red-200 bg-red-50 p-6 text-center"><XCircle className="mx-auto h-8 w-8 text-red-600" /><div className="mt-3 font-semibold text-red-800">לא ניתן לפתוח את המעקב</div><div className="mt-1 text-sm text-red-700">{error}</div></Card>}

        {!loading && !error && data && (
          <div className="space-y-4">
            <Card className="p-5">
              <div className="flex items-start gap-4">
                <StatusIcon buyerState={p?.buyer_state} />
                <div className="min-w-0 flex-1">
                  <div className="text-sm text-slate-500">{deal?.title}</div>
                  <div className="mt-1 text-xl font-bold">{BUYER_LABELS[p?.buyer_state] || p?.buyer_state}</div>
                  <div className="mt-2 flex flex-wrap gap-2"><Badge variant="outline">{MONEY_LABELS[p?.money_state] || p?.money_state}</Badge><Badge variant="secondary">{p?.qty || 0} יחידות</Badge></div>
                  <div className="mt-3 rounded-lg bg-slate-50 px-3 py-2 text-sm text-slate-700"><span className="text-slate-500">מצב העסקה: </span><span className="font-medium">{dealStateLabel(deal?.state)}</span></div>
                  {!["Completed","Failed","Cancelled"].includes(deal?.state) && deal?.deadline && <div className="mt-2 text-xs text-slate-500">נותרו לדדליין: {remaining(deal.deadline)}</div>}
                </div>
              </div>
            </Card>

            <Card className="p-5">
              <div className="flex items-center justify-between gap-3"><h2 className="font-semibold">התקדמות העסקה</h2><span className="text-sm font-medium">{progress}% מהמינימום</span></div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-200"><div className="h-full rounded-full bg-slate-800" style={{ width: `${progress}%` }} /></div>
              <div className="mt-2 text-xs text-slate-500">{deal?.reserved_units || 0} יחידות מתוך מינימום של {deal?.min_units || 0}. מלאי מרבי {deal?.max_units || 0}.</div>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500"><span className="flex items-center gap-2"><Users className="h-4 w-4" />אתה ועוד {Math.max(0, Number(deal?.participant_count || 0) - 1)} משתתפים בעסקה</span><span className="flex items-center gap-2"><RefreshCw className="h-3.5 w-3.5" />מתעדכן אוטומטית כל 15 שניות{lastRefreshAt ? ` · עודכן ${lastRefreshAt.toLocaleTimeString("he-IL", { hour:"2-digit", minute:"2-digit", second:"2-digit" })}` : ""}</span></div>
            </Card>

            {canShare && <Card className="p-5">
              <div className="flex items-center gap-2"><Share2 className="h-5 w-5 text-indigo-600" /><h2 className="font-semibold">עזרו לעסקה להתקדם</h2></div>
              <p className="mt-2 text-sm text-slate-600">כבר הצטרפת. עכשיו אפשר לשתף את העסקה עם חברים כדי לעזור להגיע ליעד.</p>
              <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-3"><Button type="button" variant="outline" onClick={() => openShare(`https://wa.me/?text=${encodeURIComponent(`${shareText}\n${shareUrl}`)}`)}>WhatsApp</Button><Button type="button" variant="outline" onClick={() => openShare(`https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`)}>Telegram</Button><Button type="button" variant="outline" onClick={copyShare}><Copy className="ml-2 h-4 w-4" />העתק לינק</Button></div>
              {shareStatus && <div className="mt-3 text-xs font-medium text-emerald-700">{shareStatus}</div>}
            </Card>}

            {(sellerWhatsApp || deal?.seller_contact?.support_email) && <Card className="p-5">
              <div className="flex items-center gap-2"><MessageCircle className="h-5 w-5 text-emerald-600" /><h2 className="font-semibold">שאלות? צרו קשר עם המוכר</h2></div>
              {deal?.seller_display_name && <div className="mt-2 text-sm text-slate-600">{deal.seller_display_name}</div>}
              <div className="mt-4 flex flex-wrap gap-2">
                {sellerWhatsApp && <Button type="button" variant="outline" onClick={() => openShare(`https://wa.me/${sellerWhatsApp}?text=${encodeURIComponent(`היי, אני מעוניין בפרטים נוספים לגבי העסקה ${deal?.title || ""} בסיטון`)}`)}>WhatsApp</Button>}
                {deal?.seller_contact?.support_email && <Button type="button" variant="outline" onClick={() => openShare(`mailto:${encodeURIComponent(deal.seller_contact.support_email)}?subject=${encodeURIComponent(`שאלה לגבי ${deal?.title || "העסקה"}`)}`)}><Mail className="ml-2 h-4 w-4" />מייל</Button>}
              </div>
            </Card>}

            <div className={`grid gap-3 ${deal?.deal_type === "physical_product" ? "sm:grid-cols-2" : "sm:grid-cols-1"}`}>
              <Card className="p-4"><div className="flex items-center gap-2 text-sm text-slate-500"><CreditCard className="h-4 w-4" />סכום שמור</div><div className="mt-2 text-xl font-semibold">{formatMoney(p?.hold_total)}</div><div className="mt-1 text-xs text-slate-500">הסטטוס הכספי מוצג לפי המצב שנשמר במערכת.</div></Card>
              {deal?.deal_type === "physical_product" && <Card className="p-4"><div className="flex items-center gap-2 text-sm text-slate-500"><Truck className="h-4 w-4" />מסירה</div><div className="mt-2 font-semibold">{p?.delivery_method_label || "לא הוגדרה"}</div><div className="mt-1 text-xs text-slate-500">עלות {formatMoney(p?.delivery_cost)}</div></Card>}
            </div>

            {deal?.deal_type === "voucher" && deal?.voucher_terms && <Card className="p-5"><div className="flex items-center gap-2"><Gift className="h-5 w-5 text-indigo-600" /><h2 className="font-semibold">פרטי השובר</h2></div><div className="mt-3 grid gap-3 sm:grid-cols-2"><div className="rounded-lg bg-slate-50 p-3"><div className="text-xs text-slate-500">ערך</div><div className="font-semibold">{formatMoney(deal.voucher_terms.face_value_amount)}</div></div><div className="rounded-lg bg-slate-50 p-3"><div className="text-xs text-slate-500">תוקף</div><div className="font-semibold">{deal.voucher_terms.valid_until ? new Date(deal.voucher_terms.valid_until).toLocaleDateString("he-IL") : "—"}</div></div></div>{deal.voucher_terms.redemption_location && <div className="mt-3 text-sm text-slate-600">{deal.voucher_terms.redemption_location}</div>}{deal.voucher_terms.redemption_instructions && <div className="mt-2 text-sm text-slate-600">{deal.voucher_terms.redemption_instructions}</div>}</Card>}

            {deal?.deal_type === "ticket" && deal?.ticket_terms && <Card className="p-5"><div className="flex items-center gap-2"><Ticket className="h-5 w-5 text-indigo-600" /><h2 className="font-semibold">פרטי הכרטיס</h2></div><div className="mt-3 font-semibold">{deal.ticket_terms.event_name}</div>{deal.ticket_terms.event_starts_at && <div className="mt-2 flex items-center gap-2 text-sm text-slate-600"><CalendarDays className="h-4 w-4" />{new Date(deal.ticket_terms.event_starts_at).toLocaleString("he-IL")}</div>}<div className="mt-2 text-sm text-slate-600">{[deal.ticket_terms.venue_name, deal.ticket_terms.venue_address, deal.ticket_terms.venue_city].filter(Boolean).join(", ") || ""}</div>{deal.ticket_terms.entry_instructions && <div className="mt-2 text-sm text-slate-600">{deal.ticket_terms.entry_instructions}</div>}</Card>}

            {["voucher","ticket"].includes(deal?.deal_type) && <Card className="p-5"><div className="flex items-center justify-between gap-3"><h2 className="font-semibold">{deal.deal_type === "voucher" ? "יחידות שובר" : "כרטיסים"}</h2><Badge variant="outline">{units.length} / {data?.fulfillment?.expected_units || p?.qty || 0}</Badge></div>{units.length ? <div className="mt-4 space-y-2">{units.map((unit)=><div key={unit.fulfillment_unit_id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-slate-50 px-3 py-3"><div><div className="font-medium">יחידה {unit.unit_index}</div><div className="text-xs text-slate-500">{unit.status}</div></div><div className="text-left"><div className="text-xs text-slate-500">4 תווים אחרונים</div><div className="font-mono font-semibold">{unit.code_display_last4 || "—"}</div></div></div>)}</div> : <div className="mt-3 rounded-lg border border-amber-100 bg-amber-50 p-3 text-sm text-amber-800">העסקה עשויה להיות זכאית להנפקה, אך מסלול מסירת הקוד המלא עדיין אינו מופעל. לא נוצר קוד שאפשר לאבד במקרה של קריסה.</div>}</Card>}

            {p?.buyer_state === "ChargeFailedCompletion" && deal?.state === "CompletionWindow" && deal?.completion_window_until && <Card className="border-amber-200 bg-amber-50 p-4"><div className="flex gap-3"><Clock3 className="mt-0.5 h-5 w-5 text-amber-700" /><div className="flex-1"><div className="font-semibold">נדרש עדכון אמצעי תשלום</div><div className="mt-1 text-sm text-slate-700">החיוב לא עבר. יש להשלים את התשלום בתוך חלון ההשלמה.</div><div className="mt-2 text-sm font-semibold text-amber-800">נותרו {remaining(deal.completion_window_until)}</div><div className="mt-1 text-xs text-slate-500">עד {new Date(deal.completion_window_until).toLocaleString("he-IL")}</div><Button className="mt-4 w-full" disabled={!data?.safety?.real_money_enabled}>עדכון אמצעי תשלום</Button>{!data?.safety?.real_money_enabled && <div className="mt-2 text-xs text-slate-500">הפעולה תופעל לאחר חיבור ספק הסליקה האמיתי.</div>}</div></div></Card>}

            {p?.buyer_state === "DealCompleted" && <Card className="border-emerald-200 bg-emerald-50 p-4"><div className="flex gap-3"><PackageCheck className="mt-0.5 h-5 w-5 text-emerald-700" /><div><div className="font-semibold">העסקה הושלמה</div><div className="mt-1 text-sm text-slate-600">ההשתתפות שלך מסומנת כהושלמה במערכת.</div></div></div></Card>}

            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-xs leading-5 text-amber-900">בגרסת ההגירה הנוכחית Join וכסף אמיתי חסומים עד השלמת מבחני המקביליות וחיבור ספק סליקה. המסך הזה מיועד לשקף את חוזה המעקב והמ States שהועברו.</div>

            <div className="text-center"><Button asChild variant="outline"><Link to={`/deal/${p?.deal_id}`}>חזרה לעמוד העסקה</Link></Button></div>
          </div>
        )}
      </main>
    </div>
  );
}
