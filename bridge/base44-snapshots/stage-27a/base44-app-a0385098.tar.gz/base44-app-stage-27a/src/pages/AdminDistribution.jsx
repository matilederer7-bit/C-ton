import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Copy, Link2, Network, Plus, RefreshCw } from "lucide-react";

const inputClass = "w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-400";
const money = (value) => new Intl.NumberFormat("he-IL", { style:"currency", currency:"ILS", maximumFractionDigits:2 }).format(Number(value || 0));

export default function AdminDistribution() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [dealId, setDealId] = useState("");
  const [form, setForm] = useState({ source_code:"", display_name:"", notes:"" });
  const [accessForm, setAccessForm] = useState({ user_email:"", deal_id:"" });
  const [revokeReasons, setRevokeReasons] = useState({});
  const [drafts, setDrafts] = useState({});

  const invoke = async (payload) => {
    const response = await base44.functions.invoke("admin-distribution", payload);
    return response?.data || response;
  };
  const load = async () => {
    setLoading(true); setError("");
    try { setData(await invoke({ operation:"list" })); }
    catch (e) { setError(e?.response?.data?.error || e?.message || "לא ניתן לטעון מקורות הפצה"); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const createSource = async () => {
    if (!form.source_code.trim() || !form.display_name.trim()) return setError("נדרשים קוד ושם מקור");
    setBusy("create"); setError("");
    try { await invoke({ operation:"create", ...form }); setForm({ source_code:"", display_name:"", notes:"" }); await load(); }
    catch (e) { setError(e?.response?.data?.error || e?.message || "יצירת מקור נכשלה"); }
    finally { setBusy(""); }
  };

  const grantDistributor = async () => {
    if (!accessForm.user_email.trim() || !accessForm.deal_id.trim()) return setError("נדרשים מייל משתמש ו-Deal ID");
    setBusy("grant-distributor"); setError("");
    try { await invoke({ operation:"grant_distributor", ...accessForm }); setAccessForm({ user_email:"", deal_id:"" }); await load(); }
    catch (e) { setError(e?.response?.data?.error || e?.message || "הקצאת מפיץ נכשלה"); }
    finally { setBusy(""); }
  };

  const revokeDistributor = async (access) => {
    const reason=String(revokeReasons[access.access_id]||"").trim();
    if (!reason) return setError("Reason הוא חובה בביטול הרשאת מפיץ");
    setBusy(`access:${access.access_id}`); setError("");
    try { await invoke({ operation:"revoke_distributor", access_id:access.access_id, reason }); setRevokeReasons(v=>({...v,[access.access_id]:""})); await load(); }
    catch (e) { setError(e?.response?.data?.error || e?.message || "ביטול הרשאה נכשל"); }
    finally { setBusy(""); }
  };

  const save = async (source) => {
    const draft = drafts[source.source_id] || {};
    if (!String(draft.reason || "").trim()) return setError("Reason הוא חובה בשינוי מקור");
    setBusy(source.source_id); setError("");
    try {
      await invoke({ operation:"update", source_id:source.source_id, display_name:draft.display_name ?? source.display_name, active:draft.active ?? source.active, notes:draft.notes ?? source.notes, reason:draft.reason });
      setDrafts((current) => { const next={...current}; delete next[source.source_id]; return next; });
      await load();
    } catch (e) { setError(e?.response?.data?.error || e?.message || "עדכון מקור נכשל"); }
    finally { setBusy(""); }
  };

  const copyLink = async (source) => {
    if (!dealId.trim()) return setError("יש להזין Deal ID כדי ליצור קישור");
    const link = `${window.location.origin}/deal/${encodeURIComponent(dealId.trim())}?ref=${encodeURIComponent(source.source_code)}`;
    try { await navigator.clipboard.writeText(link); setError(""); }
    catch { setError(link); }
  };

  const sources = data?.sources || [];
  return <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
    <header className="border-b bg-white"><div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between"><div><div className="flex items-center gap-2 text-sm font-medium text-indigo-700"><Network className="h-4 w-4"/>Distribution Attribution</div><h1 className="mt-1 text-2xl font-bold">מקורות הפצה</h1><p className="mt-1 text-sm text-slate-500">ייחוס ומדידה בלבד. אין עמלת מפיץ, payout או settlement.</p></div><div className="flex gap-2"><Button asChild variant="outline"><Link to="/admin" className="gap-2"><ArrowRight className="h-4 w-4"/>Mission Control</Link></Button><Button variant="outline" onClick={load} disabled={loading} className="gap-2"><RefreshCw className={`h-4 w-4 ${loading?"animate-spin":""}`}/>רענון</Button></div></div></header>
    <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6">
      {error && <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 break-all">{error}</div>}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6"><Card className="p-4"><div className="text-xs text-slate-500">מקורות</div><div className="mt-1 text-2xl font-bold">{sources.length}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">קליקים</div><div className="mt-1 text-2xl font-bold">{data?.totals?.total_clicks || 0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">כניסות</div><div className="mt-1 text-2xl font-bold">{data?.totals?.total_visits || 0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">הצטרפויות</div><div className="mt-1 text-2xl font-bold">{data?.totals?.total_attributions || 0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">יחידות מיוחסות</div><div className="mt-1 text-2xl font-bold">{data?.totals?.total_units || 0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">מכירות מיוחסות</div><div className="mt-1 text-xl font-bold">{money(data?.totals?.attributed_gross)}</div><div className="mt-1 text-[11px] text-slate-400">מדידה בלבד</div></Card></div>
      <Card className="p-5"><div className="mb-4 flex items-center gap-2"><Plus className="h-4 w-4"/><h2 className="font-semibold">מקור חדש</h2></div><div className="grid gap-3 md:grid-cols-3"><input className={inputClass} placeholder="source-code" value={form.source_code} onChange={(e)=>setForm({...form,source_code:e.target.value})}/><input className={inputClass} placeholder="שם תצוגה" value={form.display_name} onChange={(e)=>setForm({...form,display_name:e.target.value})}/><input className={inputClass} placeholder="הערות" value={form.notes} onChange={(e)=>setForm({...form,notes:e.target.value})}/></div><Button className="mt-3" onClick={createSource} disabled={busy==="create"}>צור מקור</Button></Card>
      <Card className="p-5"><div className="flex items-center gap-2"><Link2 className="h-4 w-4"/><h2 className="font-semibold">יצירת קישורים</h2></div><p className="mt-1 text-xs text-slate-500">הזן Deal ID פעם אחת ולחץ העתק ליד המקור הרצוי.</p><input className={`${inputClass} mt-3 max-w-xl`} placeholder="Deal ID" value={dealId} onChange={(e)=>setDealId(e.target.value)}/></Card>
      <Card className="p-5"><div className="flex items-center gap-2"><Network className="h-4 w-4"/><h2 className="font-semibold">הרשאות מפיצים</h2></div><p className="mt-1 text-xs text-slate-500">ההרשאה מאפשרת למשתמש רשום לייצר קישורים רק לעסקה שהוקצתה לו. אין עמלה או payout.</p><div className="mt-3 grid gap-3 md:grid-cols-[1fr_1fr_auto]"><input className={inputClass} placeholder="מייל המשתמש" value={accessForm.user_email} onChange={e=>setAccessForm({...accessForm,user_email:e.target.value})}/><input className={inputClass} placeholder="Deal ID" value={accessForm.deal_id} onChange={e=>setAccessForm({...accessForm,deal_id:e.target.value})}/><Button onClick={grantDistributor} disabled={busy==="grant-distributor"}>הקצה עסקה</Button></div><div className="mt-4 space-y-2">{(data?.distributor_accesses||[]).map(access=><div key={access.access_id} className="rounded-xl border p-3"><div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between"><div><div className="flex flex-wrap items-center gap-2"><span className="font-medium">{access.user_email}</span><Badge variant="outline">{access.status}</Badge></div><div className="mt-1 text-xs text-slate-500">Deal {access.deal_id}</div></div>{access.status==="active"&&<div className="flex gap-2"><input className={inputClass} placeholder="Reason לביטול" value={revokeReasons[access.access_id]||""} onChange={e=>setRevokeReasons({...revokeReasons,[access.access_id]:e.target.value})}/><Button variant="outline" onClick={()=>revokeDistributor(access)} disabled={busy===`access:${access.access_id}`}>בטל הרשאה</Button></div>}</div></div>)}</div></Card>
      {loading && !data ? <Card className="p-10 text-center text-slate-500">טוען...</Card> : <div className="space-y-3">{sources.map((source)=>{ const d=drafts[source.source_id]||{}; return <Card key={source.source_id} className="p-5"><div className="grid gap-4 lg:grid-cols-[1fr_1fr_auto]"><div><div className="flex flex-wrap items-center gap-2"><span className="font-semibold">{source.display_name}</span><Badge variant="outline">{source.source_code}</Badge><Badge variant={source.active?"secondary":"outline"}>{source.active?"פעיל":"כבוי"}</Badge></div><div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1 text-sm text-slate-500 sm:grid-cols-3"><span>{source.total_clicks || 0} קליקים</span><span>{source.total_visits || 0} כניסות</span><span>{source.total_attributions || 0} הצטרפויות</span><span>{source.total_units || 0} יחידות</span><span>{source.conversion_rate || 0}% המרה</span><span>{money(source.attributed_gross)} מכירות מיוחסות</span></div><div className="mt-1 text-xs text-slate-400">מכירות מיוחסות הן נתון מדידה בלבד ואינן עמלה, יתרה או זכאות לתשלום.</div></div><div className="grid gap-2 sm:grid-cols-2"><input className={inputClass} value={d.display_name ?? source.display_name} onChange={(e)=>setDrafts({...drafts,[source.source_id]:{...d,display_name:e.target.value}})}/><select className={inputClass} value={String(d.active ?? source.active)} onChange={(e)=>setDrafts({...drafts,[source.source_id]:{...d,active:e.target.value==="true"}})}><option value="true">פעיל</option><option value="false">כבוי</option></select><input className={inputClass} placeholder="הערות" value={d.notes ?? source.notes ?? ""} onChange={(e)=>setDrafts({...drafts,[source.source_id]:{...d,notes:e.target.value}})}/><input className={inputClass} placeholder="Reason לשינוי" value={d.reason ?? ""} onChange={(e)=>setDrafts({...drafts,[source.source_id]:{...d,reason:e.target.value}})}/></div><div className="flex flex-wrap items-start gap-2 lg:flex-col"><Button variant="outline" className="gap-2" onClick={()=>copyLink(source)} disabled={!source.active}><Copy className="h-4 w-4"/>העתק קישור</Button><Button onClick={()=>save(source)} disabled={busy===source.source_id}>שמור</Button></div></div></Card>;})}</div>}
    </main>
  </div>;
}
