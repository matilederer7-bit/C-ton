import React, { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Copy, Database, RefreshCw, ShieldAlert, ShieldCheck } from "lucide-react";

const STATE_LABELS = {
  Draft:"טיוטה", PendingTarget:"ממתינה ליעד", TargetReached:"היעד הושג", ClosedForJoining:"סגורה להצטרפות",
  ReadyForCharging:"מוכנה לחיוב", Charging:"בתהליך חיוב", CompletionWindow:"חלון השלמה", Completed:"הושלמה", Failed:"נכשלה", Cancelled:"בוטלה"
};
const FILTERS = [
  ["anomalies","חריגות בלבד"], ["all","כל העסקאות"], ["completion_window_lt_1h","Completion Window מתחת לשעה"],
  ["inventory_projection_mismatch","Mismatch מלאי"], ["completed_zero_charged","Completed ללא חיוב מוצלח"],
  ["authorization_over_7d","Authorization מעל 7 ימים"], ["three_failed_attempts","3 ניסיונות חיוב כושלים"]
];
const ANOMALY_LABELS = {
  completion_window_lt_1h:"חלון השלמה מתחת לשעה", inventory_projection_mismatch:"Mismatch בין מלאי חיצוני ל־Projection",
  completed_zero_charged:"Completed ללא יחידה מחויבת", authorization_over_7d:"Authorization פעיל מעל 7 ימים", three_failed_attempts:"3 ניסיונות חיוב כושלים"
};

function fmt(value) { if (!value) return "—"; const d = new Date(value); return Number.isNaN(d.getTime()) ? "—" : d.toLocaleString("he-IL"); }
function copy(value) { if (value && navigator.clipboard) navigator.clipboard.writeText(String(value)).catch(()=>undefined); }

export default function AdminDeals() {
  const { dealId } = useParams();
  const [filter, setFilter] = useState("anomalies");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = async () => {
    setLoading(true); setError("");
    try {
      const payload = dealId ? { operation:"detail", deal_id:dealId } : { operation:"list", filter };
      const response = await base44.functions.invoke("admin-deals", payload);
      setData(response?.data || response);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "לא ניתן לטעון עסקאות אדמין");
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [dealId, filter]);

  if (dealId) return <DealProfile data={data} loading={loading} error={error} onRefresh={load} />;
  const rows = data?.deals || [];
  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b bg-white"><div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between"><div><div className="flex items-center gap-2 text-sm font-medium text-indigo-700"><Database className="h-4 w-4" />ניהול עסקאות</div><h1 className="mt-1 text-2xl font-bold">עסקאות וחריגים</h1><p className="mt-1 text-sm text-slate-500">ברירת המחדל מציגה חריגים בלבד. המסך קריאה בלבד.</p></div><div className="flex gap-2"><Button asChild variant="outline"><Link to="/admin" className="gap-2"><ArrowRight className="h-4 w-4"/>Mission Control</Link></Button><Button variant="outline" onClick={load} disabled={loading} className="gap-2"><RefreshCw className={`h-4 w-4 ${loading?"animate-spin":""}`}/>רענון</Button></div></div></header>
      <main className="mx-auto max-w-7xl space-y-5 px-4 py-6 sm:px-6">
        {error && <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
        <div className="flex flex-wrap gap-2">{FILTERS.map(([key,label])=><Button key={key} size="sm" variant={filter===key?"default":"outline"} onClick={()=>setFilter(key)}>{label}</Button>)}</div>
        <Card className="overflow-hidden">
          <div className="flex items-center justify-between border-b px-5 py-4"><div><h2 className="font-semibold">תוצאות</h2><div className="mt-1 text-xs text-slate-500">{data?.total ?? rows.length} עסקאות</div></div>{data?.financial_amounts_proven===false && <Badge variant="outline">סכומים כספיים לא מוצגים עד מקור אמת</Badge>}</div>
          {loading && !data ? <div className="p-12 text-center text-slate-500">טוען...</div> : rows.length===0 ? <div className="p-12 text-center text-slate-500">אין עסקאות התואמות לפילטר.</div> : <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="bg-slate-50 text-right text-xs text-slate-500"><tr><th className="px-4 py-3">עסקה</th><th className="px-4 py-3">מוכר</th><th className="px-4 py-3">מצב</th><th className="px-4 py-3">יחידות</th><th className="px-4 py-3">חריג</th><th className="px-4 py-3"></th></tr></thead><tbody className="divide-y">{rows.map((row)=><tr key={row.deal_id}><td className="px-4 py-3"><div className="font-medium">{row.title}</div><div className="mt-1 text-xs text-slate-400">{row.deal_id}</div></td><td className="px-4 py-3">{row.seller_display_name || row.seller_id}</td><td className="px-4 py-3"><Badge variant="outline">{STATE_LABELS[row.state]||row.state}</Badge></td><td className="px-4 py-3"><div>מחויב {row.final_units||0}</div><div className="text-xs text-orange-700">בהמתנה {row.pending_units||0}</div><div className="text-xs text-slate-500">לא חויב {row.failed_units||0}</div></td><td className="max-w-xs px-4 py-3">{row.anomalies?.length ? <div className="flex flex-wrap gap-1">{row.anomalies.map((a)=><Badge key={a} variant="destructive">{ANOMALY_LABELS[a]||a}</Badge>)}</div> : <span className="text-slate-400">ללא חריג</span>}</td><td className="px-4 py-3"><Button asChild size="sm" variant="outline"><Link to={`/admin/deals/${encodeURIComponent(row.deal_id)}`}>Deal Profile</Link></Button></td></tr>)}</tbody></table></div>}
        </Card>
      </main>
    </div>
  );
}

function DealProfile({ data, loading, error, onRefresh }) {
  const d = data?.deal;
  const attempts = data?.payment_attempts || [];
  const outbox = data?.outbox || [];
  const audit = data?.audit || [];
  const support = data?.support || [];
  const states = useMemo(() => Object.entries(data?.money_state_units || {}), [data]);
  return <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
    <header className="border-b bg-white"><div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between"><div><div className="text-sm font-medium text-indigo-700">Deal Profile</div><h1 className="mt-1 text-2xl font-bold">{d?.title || "עסקה"}</h1>{d && <div className="mt-1 text-xs text-slate-500">{d.deal_id} · {d.seller_display_name || d.seller_id}</div>}</div><div className="flex gap-2"><Button asChild variant="outline"><Link to="/admin/deals">חזרה לעסקאות</Link></Button><Button asChild variant="outline"><Link to="/admin/forensics">Forensics</Link></Button><Button asChild variant="outline"><Link to="/admin/controls">בקרות חירום</Link></Button><Button variant="outline" onClick={onRefresh} disabled={loading}><RefreshCw className={`ml-2 h-4 w-4 ${loading?"animate-spin":""}`}/>רענון</Button></div></div></header>
    <main className="mx-auto max-w-7xl space-y-5 px-4 py-6 sm:px-6">
      {error && <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
      {loading && !data ? <div className="p-12 text-center text-slate-500">טוען...</div> : d && <>
        <Card className={`p-5 ${d.anomalies?.length ? "border-amber-200 bg-amber-50" : ""}`}><div className="flex items-start gap-3">{d.anomalies?.length?<ShieldAlert className="mt-0.5 h-5 w-5 text-amber-700"/>:<ShieldCheck className="mt-0.5 h-5 w-5 text-emerald-700"/>}<div><div className="font-semibold">{STATE_LABELS[d.state]||d.state}</div><div className="mt-1 text-sm text-slate-600">{d.anomalies?.length ? d.anomalies.map((a)=>ANOMALY_LABELS[a]||a).join(" · ") : "לא זוהתה חריגה בפילטרים הקנוניים הזמינים."}</div></div></div></Card>
        <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5"><Metric label="יחידות סופיות" value={d.final_units}/><Metric label="Recovered" value={d.recovered_units}/><Metric label="בהמתנה" value={d.pending_units}/><Metric label="לא חויב" value={d.failed_units}/><Metric label="סף הצלחה" value={d.threshold_units}/></section>
        <Card className="p-5"><div className="flex items-center justify-between"><h2 className="font-semibold">מצבי כסף</h2><Badge variant="outline">ללא סכומים כספיים עד Snapshot מוכח</Badge></div><div className="mt-4 flex flex-wrap gap-2">{states.length?states.map(([key,value])=><Badge key={key} variant="secondary">{key}: {value}</Badge>):<span className="text-sm text-slate-500">אין נתונים</span>}</div><div className="mt-4 grid gap-3 sm:grid-cols-3"><Metric label="Inventory committed" value={d.inventory_committed_units}/><Metric label="Deal reserved projection" value={d.reserved_units}/><Metric label="Inventory reserved" value={d.inventory_reserved_units}/></div></Card>
        <div className="grid gap-4 lg:grid-cols-2"><ReadTable title="Audit אחרון" rows={audit} empty="אין אירועי Audit">{(row)=><div className="flex items-center justify-between gap-3"><div><div className="font-medium">{row.action_name}</div><div className="text-xs text-slate-500">{row.from_state} → {row.to_state} · {fmt(row.created_at)}</div></div>{row.request_id&&<Button size="sm" variant="ghost" onClick={()=>copy(row.request_id)}><Copy className="h-4 w-4"/></Button>}</div>}</ReadTable><ReadTable title="Payment Attempts" rows={attempts} empty="אין ניסיונות">{(row)=><div><div className="flex items-center justify-between"><span className="font-medium">{row.attempt_type} · {row.result_class}</span><span className="text-xs text-slate-500">{fmt(row.started_at)}</span></div>{row.error_code&&<div className="mt-1 text-xs text-red-700">{row.error_code}</div>}{row.correlation_id&&<button className="mt-1 text-xs text-indigo-700" onClick={()=>copy(row.correlation_id)}>Correlation ID · העתק</button>}</div>}</ReadTable></div>
        <div className="grid gap-4 lg:grid-cols-2"><ReadTable title="Outbox" rows={outbox} empty="אין אירועי Outbox">{(row)=><div><div className="flex justify-between gap-3"><span className="font-medium">{row.event_type}</span><Badge variant="outline">{row.status}</Badge></div><div className="mt-1 text-xs text-slate-500">ניסיונות {row.attempt_count}/{row.max_attempts} · {fmt(row.available_at)}</div>{row.last_error&&<div className="mt-1 text-xs text-red-700">{row.last_error}</div>}</div>}</ReadTable><ReadTable title="Support" rows={support} empty="אין פניות מקושרות">{(row)=><div><div className="font-medium">{row.subject}</div><div className="mt-1 text-xs text-slate-500">{row.priority} · {row.status} · {fmt(row.opened_at)}</div></div>}</ReadTable></div>
        <Card className="border-slate-200 bg-slate-50 p-4 text-sm text-slate-600">המסך קריאה בלבד. אין כאן Refund, Capture, Void, עריכת תנאים או שינוי State. פעולות חירום נעשות רק דרך Control Plane נפרד.</Card>
      </>}
    </main>
  </div>;
}

function Metric({label,value}) { return <Card className="p-4"><div className="text-xs text-slate-500">{label}</div><div className="mt-1 text-2xl font-bold">{value ?? 0}</div></Card>; }
function ReadTable({title,rows,empty,children}) { return <Card className="p-5"><h2 className="font-semibold">{title}</h2><div className="mt-4 space-y-2">{rows.length?rows.map((row,index)=><div key={row.audit_id||row.attempt_id||row.event_uuid||row.case_id||index} className="rounded-lg border bg-white p-3 text-sm">{children(row)}</div>):<div className="text-sm text-slate-500">{empty}</div>}</div></Card>; }
