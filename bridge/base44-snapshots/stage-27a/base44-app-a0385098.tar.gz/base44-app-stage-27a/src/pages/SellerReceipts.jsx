import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, FileText, RefreshCw, ShieldAlert } from "lucide-react";

const STATUS = { pending:"ממתין", processing:"בטיפול", issued:"הונפק", failed:"נכשל", skipped:"דולג" };
function money(value) { return new Intl.NumberFormat("he-IL", { style:"currency", currency:"ILS", maximumFractionDigits:2 }).format(Number(value||0)); }
function fmt(value) { if(!value) return "—"; const d=new Date(value); return Number.isNaN(d.getTime())?"—":new Intl.DateTimeFormat("he-IL",{dateStyle:"short",timeStyle:"short"}).format(d); }

export default function SellerReceipts() {
  const { dealId } = useParams();
  const [data,setData]=useState(null);
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState("");
  const load=async()=>{setLoading(true);setError("");try{const r=await base44.functions.invoke("seller-receipts",{deal_id:dealId});setData(r?.data||r);}catch(e){setError(e?.response?.data?.error||e?.message||"לא ניתן לטעון מסמכים");}finally{setLoading(false);}};
  useEffect(()=>{load();},[dealId]);
  const docs=data?.documents||[]; const ready=data?.readiness||{};
  return <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
    <header className="border-b bg-white"><div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between"><div><div className="flex items-center gap-2 text-sm font-medium text-indigo-700"><FileText className="h-4 w-4"/>Invoice Documents</div><h1 className="mt-1 text-2xl font-bold">מסמכים · {data?.deal?.title||"עסקה"}</h1><p className="mt-1 text-sm text-slate-500">זהו משטח סטטוס בלבד. אין כאן הנפקה, חישוב מע״מ או חישוב עמלה בזמן אמת.</p></div><div className="flex gap-2"><Button asChild variant="outline"><Link to={`/seller/deal/${dealId}`} className="gap-2"><ArrowRight className="h-4 w-4"/>פרטי עסקה</Link></Button><Button variant="outline" onClick={load} disabled={loading} className="gap-2"><RefreshCw className={`h-4 w-4 ${loading?"animate-spin":""}`}/>רענון</Button></div></div></header>
    <main className="mx-auto max-w-6xl space-y-6 px-4 py-6 sm:px-6">
      {error&&<div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5"><Card className="p-4"><div className="text-xs text-slate-500">צפויים</div><div className="mt-1 text-2xl font-bold">{ready.expected_charge_receipts||0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">קיימים</div><div className="mt-1 text-2xl font-bold">{ready.existing_charge_receipts||0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">חסרים</div><div className="mt-1 text-2xl font-bold">{ready.missing_charge_receipts||0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">הונפקו</div><div className="mt-1 text-2xl font-bold">{ready.issued||0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">נכשלו</div><div className="mt-1 text-2xl font-bold">{ready.failed||0}</div></Card></div>
      {!data?.issuance_enabled&&<Card className="border-amber-200 bg-amber-50 p-4"><div className="flex gap-3"><ShieldAlert className="mt-0.5 h-5 w-5 text-amber-700"/><div><div className="font-semibold">הנפקת מסמכים עדיין חסומה</div><div className="mt-1 text-sm text-amber-800">{data?.issuance_blocker||"נדרש ספק מסמכים ומקור פיננסי מוסמך."}</div><div className="mt-1 text-xs text-amber-700">לא בוצע חישוב עמלה או מע״מ.</div></div></div></Card>}
      {loading&&!data?<Card className="p-10 text-center text-slate-500">טוען...</Card>:docs.length===0?<Card className="p-10 text-center text-slate-500">אין מסמכים קנוניים בעסקה הזאת כרגע.</Card>:<div className="space-y-3">{docs.map((doc)=><Card key={doc.document_id} className="p-5"><div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between"><div><div className="flex flex-wrap items-center gap-2"><span className="font-semibold">{doc.document_type}</span><Badge variant="outline">{STATUS[doc.status]||doc.status}</Badge>{doc.financial_snapshot_proven?<Badge variant="secondary">Snapshot proven</Badge>:<Badge variant="outline">ללא Snapshot פיננסי</Badge>}</div><div className="mt-1 text-xs text-slate-500">{doc.document_key}</div><div className="mt-2 text-sm text-slate-600">{doc.qty} יחידות · {doc.money_state_at_issue}</div></div><div className="text-sm text-slate-500"><div>נוצר: {fmt(doc.created_at)}</div><div>הונפק: {fmt(doc.issued_at)}</div><div>ניסיונות: {doc.attempt_count}/{doc.max_attempts}</div></div></div>{doc.financial_snapshot_proven&&<div className="mt-4 grid gap-3 sm:grid-cols-3"><div className="rounded-lg bg-slate-50 p-3"><div className="text-xs text-slate-500">Gross</div><div className="font-semibold">{money(doc.gross_amount)}</div></div><div className="rounded-lg bg-slate-50 p-3"><div className="text-xs text-slate-500">Siton fee</div><div className="font-semibold">{money(doc.siton_fee_amount)}</div></div><div className="rounded-lg bg-slate-50 p-3"><div className="text-xs text-slate-500">Seller net</div><div className="font-semibold">{money(doc.seller_net_amount)}</div></div></div>}{doc.last_error&&<div className="mt-3 rounded-lg border border-red-100 bg-red-50 p-3 text-xs text-red-700">{doc.last_error}</div>}</Card>)}</div>}
    </main>
  </div>;
}
