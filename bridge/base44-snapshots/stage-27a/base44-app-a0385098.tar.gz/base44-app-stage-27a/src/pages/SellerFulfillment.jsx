import React, { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Copy, Download, Mail, MessageCircle, PackageCheck, RefreshCw } from "lucide-react";

const STATUSES = ["ready_to_fulfill","shipped","delivered","issue"];
const LABEL = { ready_to_fulfill:"מוכן לביצוע", shipped:"נשלח", delivered:"נמסר", issue:"בעיה באספקה" };
const inputClass = "w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-400";

function xml(value) {
  return String(value ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
}
function phoneForWhatsApp(value) {
  const digits = String(value || "").replace(/\D/g, "");
  if (!digits) return "";
  return digits.startsWith("0") ? `972${digits.slice(1)}` : digits;
}

export default function SellerFulfillment() {
  const { dealId } = useParams();
  const [data, setData] = useState(null);
  const [drafts, setDrafts] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [notice, setNotice] = useState("");

  const invoke = async (payload) => {
    const response = await base44.functions.invoke("seller-fulfillment", payload);
    return response?.data || response;
  };
  const load = async () => {
    setLoading(true); setError("");
    try { setData(await invoke({ operation:"list", deal_id:dealId })); }
    catch (e) { setError(e?.response?.data?.error || e?.message || "לא ניתן לטעון את מערך המסירות"); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [dealId]);
  const rows = data?.deliveries || [];
  const summary = data?.summary || {};

  const draftFor = (row) => ({
    status: drafts[row.participant_id]?.status ?? row.status,
    carrier: drafts[row.participant_id]?.carrier ?? row.carrier ?? "",
    tracking_number: drafts[row.participant_id]?.tracking_number ?? row.tracking_number ?? "",
    seller_note: drafts[row.participant_id]?.seller_note ?? row.seller_note ?? "",
    reason: drafts[row.participant_id]?.reason ?? ""
  });
  const updateDraft = (id, patch) => setDrafts((current) => ({ ...current, [id]: { ...(current[id] || {}), ...patch } }));

  const save = async (row) => {
    const draft = draftFor(row);
    if (!draft.reason.trim()) return setError("סיבה קצרה היא חובה בכל שינוי סטטוס מסירה");
    if (draft.status === "issue" && draft.seller_note.length > 200) return setError("הערה על בעיית אספקה מוגבלת ל־200 תווים");
    setBusy(row.participant_id); setError("");
    try {
      await invoke({ operation:"update", deal_id:dealId, participant_id:row.participant_id, ...draft });
      setDrafts((current) => { const next = { ...current }; delete next[row.participant_id]; return next; });
      await load();
    } catch (e) { setError(e?.response?.data?.error || e?.message || "עדכון המסירה נכשל"); }
    finally { setBusy(""); }
  };

  const exportExcel = async () => {
    setError("");
    try {
      const result = await invoke({ operation:"export", deal_id:dealId });
      const exportRows = result?.export_rows || [];
      const columns = [
        ["שם", "buyer_name"], ["טלפון", "buyer_phone"], ["אימייל", "buyer_email"], ["כתובת מלאה", "delivery_address"],
        ["עיר", "delivery_city"], ["כמות", "qty"], ["אופן קבלה", "delivery_method"], ["הערות", "delivery_notes"],
        ["סטטוס אספקה", "status"], ["חברת שילוח", "carrier"], ["מספר מעקב", "tracking_number"]
      ];
      const header = columns.map(([label]) => `<Cell><Data ss:Type="String">${xml(label)}</Data></Cell>`).join("");
      const body = exportRows.map((row) => `<Row>${columns.map(([,key]) => `<Cell><Data ss:Type="String">${xml(row[key])}</Data></Cell>`).join("")}</Row>`).join("");
      const workbook = `<?xml version="1.0"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="משלוחים"><Table><Row>${header}</Row>${body}</Table></Worksheet></Workbook>`;
      const blob = new Blob(["\ufeff", workbook], { type:"application/vnd.ms-excel;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `siton-shipping-${dealId}.xls`; a.click(); URL.revokeObjectURL(url);
    } catch (e) { setError(e?.response?.data?.error || e?.message || "ייצוא המשלוחים נכשל"); }
  };

  const copyAddress = async (row) => {
    const value = [row.buyer_name, row.buyer_phone, row.delivery_address, row.delivery_city].filter(Boolean).join(" · ");
    try { await navigator.clipboard.writeText(value); setNotice("הכתובת הועתקה"); }
    catch { setNotice("לא ניתן להעתיק אוטומטית"); }
    window.setTimeout(() => setNotice(""), 2200);
  };

  const deliveredPct = useMemo(() => summary.total_records ? Math.round((Number(summary.delivered || 0) / Number(summary.total_records)) * 100) : 0, [summary]);

  return <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
    <header className="border-b bg-white"><div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between"><div><div className="flex items-center gap-2 text-sm font-medium text-emerald-700"><PackageCheck className="h-4 w-4"/>אספקה</div><h1 className="mt-1 text-2xl font-bold">מסירות · {data?.deal?.title || "עסקה"}</h1><p className="mt-1 text-sm text-slate-500">מוצגים רק קונים שחויבו סופית וזכאים לאספקה.</p></div><div className="flex flex-wrap gap-2"><Button asChild variant="outline"><Link to={`/seller/deal/${dealId}`} className="gap-2"><ArrowRight className="h-4 w-4"/>פרטי עסקה</Link></Button><Button variant="outline" onClick={load} disabled={loading} className="gap-2"><RefreshCw className={`h-4 w-4 ${loading ? "animate-spin":""}`}/>רענון</Button><Button onClick={exportExcel} className="gap-2"><Download className="h-4 w-4"/>הורד רשימת משלוחים Excel</Button></div></div></header>
    <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6">
      {notice && <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">{notice}</div>}
      {error && <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5"><Metric label="קונים לאספקה" value={summary.total_records || 0}/><Metric label="מוכן" value={summary.ready_to_fulfill || 0}/><Metric label="נשלח" value={summary.shipped || 0}/><Metric label="נמסר" value={`${summary.delivered || 0} · ${deliveredPct}%`}/><Metric label="בעיות" value={summary.issue || 0}/></div>
      {loading && !data ? <Card className="p-10 text-center text-slate-500">טוען...</Card> : rows.length === 0 ? <Card className="p-10 text-center text-slate-500">אין כרגע מסירות זכאיות.</Card> : <div className="space-y-4">{rows.map((row) => {
        const draft = draftFor(row);
        const wa = phoneForWhatsApp(row.buyer_phone);
        const mailSubject = encodeURIComponent(`עדכון לגבי העסקה ${data?.deal?.title || "בסיטון"}`);
        return <Card key={row.participant_id} className="overflow-hidden"><div className="border-b px-5 py-4"><div className="flex flex-wrap items-center justify-between gap-3"><div><div className="flex items-center gap-2"><span className="font-semibold">{row.buyer_name || row.buyer_phone || "קונה"}</span><Badge variant="outline">{LABEL[row.status] || row.status}</Badge></div><div className="mt-1 text-xs text-slate-500">{row.qty} יחידות · {row.delivery_method_label || row.delivery_method_type || "ללא שיטת מסירה"}</div></div><div className="flex flex-wrap gap-2"><Button size="sm" variant="outline" onClick={() => copyAddress(row)} className="gap-2"><Copy className="h-3.5 w-3.5"/>העתק כתובת</Button>{wa && <Button asChild size="sm" variant="outline"><a href={`https://wa.me/${wa}?text=${encodeURIComponent(`היי, עדכון לגבי העסקה ${data?.deal?.title || "בסיטון"}`)}`} target="_blank" rel="noreferrer" className="gap-2"><MessageCircle className="h-3.5 w-3.5"/>WhatsApp</a></Button>}{row.buyer_email && <Button asChild size="sm" variant="outline"><a href={`mailto:${encodeURIComponent(row.buyer_email)}?subject=${mailSubject}`} className="gap-2"><Mail className="h-3.5 w-3.5"/>Email</a></Button>}</div></div></div><div className="grid gap-5 p-5 lg:grid-cols-2"><div className="space-y-2 text-sm"><div><span className="text-slate-500">טלפון:</span> {row.buyer_phone || "—"}</div><div><span className="text-slate-500">מייל:</span> {row.buyer_email || "—"}</div><div><span className="text-slate-500">כתובת:</span> {[row.delivery_address,row.delivery_city].filter(Boolean).join(", ") || "—"}</div><div><span className="text-slate-500">הערות קונה:</span> {row.delivery_notes || "—"}</div><div><span className="text-slate-500">מספר מעקב:</span> {row.tracking_number || "—"}</div></div><div className="grid gap-3 sm:grid-cols-2"><label><div className="mb-1 text-xs text-slate-500">סטטוס</div><select className={inputClass} value={draft.status} onChange={(e)=>updateDraft(row.participant_id,{status:e.target.value})}>{STATUSES.map(v=><option key={v} value={v}>{LABEL[v]}</option>)}</select></label><label><div className="mb-1 text-xs text-slate-500">חברת שילוח</div><input className={inputClass} value={draft.carrier} onChange={(e)=>updateDraft(row.participant_id,{carrier:e.target.value})}/></label><label><div className="mb-1 text-xs text-slate-500">מספר מעקב</div><input className={inputClass} value={draft.tracking_number} onChange={(e)=>updateDraft(row.participant_id,{tracking_number:e.target.value})}/></label><label><div className="mb-1 text-xs text-slate-500">סיבה לשינוי</div><input className={inputClass} value={draft.reason} onChange={(e)=>updateDraft(row.participant_id,{reason:e.target.value})}/></label><label className="sm:col-span-2"><div className="mb-1 text-xs text-slate-500">הערת מוכר {draft.status === "issue" ? "· עד 200 תווים" : ""}</div><textarea maxLength={draft.status === "issue" ? 200 : 2000} className={`${inputClass} min-h-20`} value={draft.seller_note} onChange={(e)=>updateDraft(row.participant_id,{seller_note:e.target.value})}/></label><div className="sm:col-span-2"><Button onClick={()=>save(row)} disabled={busy === row.participant_id}>{busy === row.participant_id ? "שומר...":"שמור"}</Button></div></div></div></Card>;
      })}</div>}
      <p className="text-xs text-slate-500">בקשות החזר אינן מבוצעות ידנית במסך זה. אין כאן Capture, Void או Refund.</p>
    </main>
  </div>;
}
function Metric({label,value}) { return <Card className="p-4"><div className="text-xs text-slate-500">{label}</div><div className="mt-1 text-2xl font-bold">{value}</div></Card>; }
