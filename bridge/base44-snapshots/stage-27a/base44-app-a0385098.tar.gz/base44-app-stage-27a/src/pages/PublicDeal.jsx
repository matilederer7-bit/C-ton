import React, { useEffect, useMemo, useRef, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CalendarDays, CheckCircle2, Clock3, Copy, CreditCard, ExternalLink, Gift, Loader2, LockKeyhole, Mail, MapPin, MessageCircle, Package, RefreshCw, Share2, ShieldCheck, Ticket, Users } from "lucide-react";

function money(value) {
  return new Intl.NumberFormat("he-IL", { style: "currency", currency: "ILS", maximumFractionDigits: 2 }).format(Number(value || 0));
}

function stateLabel(state) {
  const labels = {
    PendingTarget: "העסקה פתוחה",
    TargetReached: "היעד הושג",
    ClosedForJoining: "ההצטרפות נסגרה",
    ReadyForCharging: "בהכנה לחיוב",
    Charging: "בתהליך חיוב",
    CompletionWindow: "חלון השלמה",
    Completed: "העסקה הושלמה",
    Failed: "העסקה נכשלה",
  };
  return labels[state] || state;
}

export default function PublicDeal() {
  const { dealId } = useParams();
  const [searchParams] = useSearchParams();
  const affiliateRef = String(searchParams.get("ref") || "").trim().slice(0, 80);
  const [deal, setDeal] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [buyerId, setBuyerId] = useState("");
  const [buyerName, setBuyerName] = useState("");
  const [buyerEmail, setBuyerEmail] = useState("");
  const [qty, setQty] = useState("1");
  const [deliveryOptionId, setDeliveryOptionId] = useState("");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [deliveryCity, setDeliveryCity] = useState("");
  const [deliveryNotes, setDeliveryNotes] = useState("");
  const [otpChannel, setOtpChannel] = useState("sms");
  const [otpChallengeId, setOtpChallengeId] = useState("");
  const [otpDestinationDisplay, setOtpDestinationDisplay] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [otpToken, setOtpToken] = useState("");
  const [otpStatus, setOtpStatus] = useState("");
  const [busy, setBusy] = useState("");
  const [lastRefreshAt, setLastRefreshAt] = useState(null);
  const [shareStatus, setShareStatus] = useState("");
  const [fomoMessage, setFomoMessage] = useState("");
  const [comments, setComments] = useState([]);
  const [commentName, setCommentName] = useState("");
  const [commentText, setCommentText] = useState("");
  const [commentBusy, setCommentBusy] = useState(false);
  const [commentStatus, setCommentStatus] = useState("");
  const purchaseCountRef = useRef(null);

  const loadDeal = async ({ background = false } = {}) => {
    if (!background) setLoading(true);
    if (!background) setError("");
    try {
      const res = await base44.functions.invoke("get-public-deal", { deal_id: dealId });
      const data = res?.data || res;
      const nextPurchaseCount = Number(data.deal?.purchase_count || 0);
      if (background && purchaseCountRef.current !== null && nextPurchaseCount > purchaseCountRef.current) {
        const delta = nextPurchaseCount - purchaseCountRef.current;
        setFomoMessage(delta === 1 ? `הצטרפות חדשה לעסקה · ${nextPurchaseCount} הצטרפויות עד עכשיו` : `${delta} הצטרפויות חדשות · ${nextPurchaseCount} הצטרפויות עד עכשיו`);
        window.setTimeout(() => setFomoMessage(""), 4500);
      }
      purchaseCountRef.current = nextPurchaseCount;
      setDeal(data.deal);
      setLastRefreshAt(new Date());
      const options = data.deal?.delivery_options || [];
      setDeliveryOptionId((current) => current || options[0]?.option_id || "");
    } catch (e) {
      if (!background) setError(e?.response?.data?.error || e?.message || "לא ניתן לטעון את העסקה");
    } finally {
      if (!background) setLoading(false);
    }
  };

  const loadComments = async () => {
    try {
      const res = await base44.functions.invoke("deal-comments", { operation: "list", deal_id: dealId });
      const data = res?.data || res;
      setComments(Array.isArray(data?.comments) ? data.comments : []);
    } catch {
      // Comments are supportive UX only. Deal state remains the source of truth.
    }
  };

  const commentSessionToken = () => {
    const key = "siton_public_comment_session";
    let token = window.localStorage.getItem(key);
    if (!token) {
      token = `${crypto.randomUUID()}:${crypto.randomUUID()}`;
      window.localStorage.setItem(key, token);
    }
    return token;
  };

  const submitComment = async () => {
    const name = commentName.trim();
    const message = commentText.trim();
    if (name.length < 2 || !message) {
      setCommentStatus("יש להזין שם ותגובה.");
      return;
    }
    setCommentBusy(true);
    setCommentStatus("");
    try {
      await base44.functions.invoke("deal-comments", {
        operation: "post",
        deal_id: dealId,
        display_name: name,
        message,
        session_token: commentSessionToken(),
        idempotency_key: `comment:${dealId}:${crypto.randomUUID()}`,
      });
      setCommentText("");
      setCommentStatus("התגובה פורסמה.");
      await loadComments();
    } catch (e) {
      setCommentStatus(e?.response?.data?.error || e?.message || "לא ניתן לפרסם את התגובה כרגע.");
    } finally {
      setCommentBusy(false);
    }
  };

  useEffect(() => {
    loadDeal();
    loadComments();
    const timer = window.setInterval(() => {
      if (document.visibilityState === "visible") {
        loadDeal({ background: true });
        loadComments();
      }
    }, 15_000);
    return () => window.clearInterval(timer);
  }, [dealId]);

  const isPhysical = deal?.deal_type === "physical_product";
  const selectedDelivery = useMemo(
    () => isPhysical ? (deal?.delivery_options || []).find((option) => option.option_id === deliveryOptionId) || null : null,
    [deal, deliveryOptionId, isPhysical]
  );
  const quantity = Math.max(1, Number(qty || 1));
  const total = deal ? quantity * Number(deal.price_per_unit || 0) + Number(selectedDelivery?.cost || 0) : 0;
  const destination = otpChannel === "email" ? buyerEmail : buyerId;

  const requestOtp = async () => {
    setError("");
    setOtpStatus("");
    if (!destination.trim()) {
      setError(otpChannel === "email" ? "יש להזין כתובת מייל" : "יש להזין מספר טלפון");
      return;
    }
    setBusy("otp-request");
    try {
      const res = await base44.functions.invoke("request-otp", {
        channel: otpChannel,
        destination,
        purpose: "buyer_join",
        deal_id: dealId,
      });
      const data = res?.data || res;
      setOtpChallengeId(data.challenge_id);
      setOtpDestinationDisplay(data.destination_display || "");
      if (data.delivery_status === "skipped") {
        setOtpStatus("האתגר נוצר, אך ספק OTP חיצוני עדיין אינו מחובר. לא נשלח קוד בפועל.");
      } else {
        setOtpStatus(`קוד נשלח אל ${data.destination_display || "היעד"}`);
      }
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "שליחת הקוד נכשלה");
    } finally {
      setBusy("");
    }
  };

  const verifyOtp = async () => {
    setError("");
    if (!otpChallengeId || !otpCode.trim()) return;
    setBusy("otp-verify");
    try {
      const res = await base44.functions.invoke("verify-otp", {
        challenge_id: otpChallengeId,
        code: otpCode,
      });
      const data = res?.data || res;
      setOtpToken(data.otp_token);
      setOtpStatus("הטלפון או המייל אומתו בהצלחה.");
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "אימות הקוד נכשל");
    } finally {
      setBusy("");
    }
  };

  const shareUrl = typeof window !== "undefined" ? window.location.href : "";
  const shareText = deal ? `הצטרפו לעסקה בסיטון: ${deal.title}` : "הצטרפו לעסקה בסיטון";
  const openShare = (url) => window.open(url, "_blank", "noopener,noreferrer");
  const copyShare = async (label = "הלינק") => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setShareStatus(`${label} הועתק`);
    } catch {
      setShareStatus("לא ניתן להעתיק אוטומטית. העתיקו את כתובת הדף מהדפדפן.");
    }
    window.setTimeout(() => setShareStatus(""), 2500);
  };
  const nativeShare = async () => {
    if (navigator.share) {
      try { await navigator.share({ title: deal?.title || "סיטון", text: shareText, url: shareUrl }); return; } catch { /* user cancelled */ }
    }
    await copyShare("הלינק");
  };

  if (loading) {
    return <div dir="rtl" className="min-h-screen bg-slate-50 grid place-items-center"><Loader2 className="h-8 w-8 animate-spin text-slate-500" /></div>;
  }
  if (!deal) {
    return <div dir="rtl" className="min-h-screen bg-slate-50 grid place-items-center p-6"><Card className="max-w-lg p-8 text-center"><h1 className="text-xl font-semibold">העסקה אינה זמינה</h1><p className="mt-2 text-sm text-slate-500">{error || "לא נמצאה עסקה ציבורית בכתובת הזאת."}</p></Card></div>;
  }

  const progress = Math.min(100, Number(deal.progress_percent || 0));
  const deliveryRequired = isPhysical && selectedDelivery?.option_type === "delivery";
  const sellerPhoneDigits = String(deal.seller_contact?.support_phone || "").replace(/\D/g, "");
  const sellerWhatsApp = sellerPhoneDigits ? (sellerPhoneDigits.startsWith("0") ? `972${sellerPhoneDigits.slice(1)}` : sellerPhoneDigits) : "";

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b bg-white">
        <div className="mx-auto max-w-5xl px-4 py-5 sm:px-6">
          <div className="flex items-center gap-2 text-sm font-medium text-emerald-700"><ShieldCheck className="h-4 w-4" /> סיטון · רכישה קבוצתית</div>
        </div>
      </header>

      {fomoMessage && <div className="fixed left-1/2 top-4 z-50 -translate-x-1/2 rounded-full border border-emerald-200 bg-white px-4 py-2 text-sm font-medium text-emerald-800 shadow-lg">{fomoMessage}</div>}

      <main className="mx-auto grid max-w-5xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[1fr_.9fr]">
        <section className="space-y-5">
          <Card className="p-5 sm:p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-sm text-slate-500">{deal.seller_display_name}</div>{affiliateRef && <div className="mt-1 text-xs text-indigo-600">קישור הפצה מזוהה</div>}
                <h1 className="mt-1 text-2xl font-bold">{deal.title}</h1>
              </div>
              <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-medium text-emerald-700">{stateLabel(deal.state)}</span>
            </div>
            {deal.short_description && <p className="mt-4 whitespace-pre-line text-sm leading-6 text-slate-600">{deal.short_description}</p>}
            {deal.what_you_get && <div className="mt-4 rounded-xl border bg-slate-50 p-4"><div className="text-xs font-semibold text-slate-500">מה מקבלים</div><div className="mt-2 whitespace-pre-line text-sm leading-6 text-slate-700">{deal.what_you_get}</div></div>}

            <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-xl bg-slate-50 p-3"><div className="text-xs text-slate-500">מחיר ליחידה</div><div className="mt-1 font-semibold">{money(deal.price_per_unit)}</div></div>
              <div className="rounded-xl bg-slate-50 p-3"><div className="text-xs text-slate-500">הצטרפו</div><div className="mt-1 font-semibold">{deal.reserved_units}</div></div>
              <div className="rounded-xl bg-slate-50 p-3"><div className="text-xs text-slate-500">כמות מינימום</div><div className="mt-1 font-semibold">{deal.min_units}</div></div>
              <div className="rounded-xl bg-slate-50 p-3"><div className="text-xs text-slate-500">נותרו במלאי</div><div className="mt-1 font-semibold">{deal.remaining_units}</div></div>
            </div>

            <div className="mt-5">
              <div className="mb-2 flex justify-between text-xs text-slate-500"><span>התקדמות אל כמות המינימום</span><span>{deal.reserved_units} / {deal.min_units} יחידות · {progress}%</span></div>
              <div className="h-3 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-emerald-500 transition-all" style={{ width: `${progress}%` }} /></div>
            </div>

            <div className="mt-5 flex flex-wrap items-center justify-between gap-3 text-sm text-slate-600">
              <div className="flex items-center gap-2"><Clock3 className="h-4 w-4" /> סיום העסקה: {deal.deadline ? new Date(deal.deadline).toLocaleString("he-IL") : "לא הוגדר"}</div>
              <div className="flex items-center gap-2 text-xs text-slate-500"><RefreshCw className="h-3.5 w-3.5" /> מתעדכן אוטומטית כל 15 שניות{lastRefreshAt ? ` · עודכן ${lastRefreshAt.toLocaleTimeString("he-IL", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}` : ""}</div>
            </div>
            <div className="mt-3 flex items-center gap-2 text-sm text-slate-600"><Users className="h-4 w-4" /><span>{deal.participant_count || 0} משתתפים · {deal.purchase_count || 0} הצטרפויות</span></div>
            {deal.state === "PendingTarget" && Number(deal.remaining_to_minimum || 0) > 0 && <div className="mt-3 rounded-lg bg-amber-50 px-3 py-2 text-sm font-medium text-amber-800">עוד {deal.remaining_to_minimum} יחידות כדי להגיע למינימום</div>}
            {deal.state === "TargetReached" && <div className="mt-3 rounded-lg bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-800">כמות המינימום הושגה · העסקה ממשיכה עד הסגירה</div>}
          </Card>

          {(deal.images || []).length > 0 && <Card className="overflow-hidden">
            <div className="grid gap-px bg-slate-200 sm:grid-cols-2">
              {deal.images.map((image, index) => <div key={image.image_id} className={`${index === 0 && deal.images.length > 1 ? "sm:row-span-2" : ""} bg-slate-100`}><img src={image.file_url} alt={`${deal.title} · תמונה ${index + 1}`} className="h-full min-h-56 w-full object-cover" loading={index === 0 ? "eager" : "lazy"} /></div>)}
            </div>
          </Card>}

          <Card className="p-5 sm:p-6">
            <div className="flex items-center gap-2"><Share2 className="h-5 w-5 text-indigo-600" /><h2 className="font-semibold">שתפו את העסקה</h2></div>
            <p className="mt-2 text-sm text-slate-600">עזרו לעסקה להתקדם ושלחו את הלינק לחברים.</p>
            <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
              <Button type="button" variant="outline" onClick={() => openShare(`https://wa.me/?text=${encodeURIComponent(`${shareText}\n${shareUrl}`)}`)}>WhatsApp</Button>
              <Button type="button" variant="outline" onClick={() => openShare(`https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`)}>Telegram</Button>
              <Button type="button" variant="outline" onClick={() => openShare(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`)}>Facebook</Button>
              <Button type="button" variant="outline" onClick={() => openShare(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`)}>X</Button>
              <Button type="button" variant="outline" onClick={() => openShare(`mailto:?subject=${encodeURIComponent(deal.title)}&body=${encodeURIComponent(`${shareText}\n${shareUrl}`)}`)}><Mail className="ml-2 h-4 w-4" />מייל</Button>
              <Button type="button" variant="outline" onClick={() => copyShare("הלינק")}><Copy className="ml-2 h-4 w-4" />העתקה</Button>
              <Button type="button" variant="outline" onClick={nativeShare}><Share2 className="ml-2 h-4 w-4" />עוד</Button>
              <Button type="button" asChild variant="ghost"><a href="/" className="gap-2"><ExternalLink className="h-4 w-4" />פתחו עסקה משלכם</a></Button>
            </div>
            {shareStatus && <div className="mt-3 text-xs font-medium text-emerald-700">{shareStatus}</div>}
          </Card>

          {deal.deal_type === "voucher" && deal.voucher_terms && <Card className="p-5 sm:p-6">
            <div className="flex items-center gap-2"><Gift className="h-5 w-5 text-indigo-600" /><h2 className="font-semibold">פרטי השובר</h2></div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl bg-slate-50 p-3"><div className="text-xs text-slate-500">ערך השובר</div><div className="mt-1 font-semibold">{money(deal.voucher_terms.face_value_amount)}</div></div>
              <div className="rounded-xl bg-slate-50 p-3"><div className="text-xs text-slate-500">תוקף</div><div className="mt-1 text-sm font-medium">{deal.voucher_terms.valid_until ? new Date(deal.voucher_terms.valid_until).toLocaleDateString("he-IL") : "ללא מועד סיום מוצג"}</div></div>
            </div>
            {deal.voucher_terms.redemption_location && <div className="mt-4 flex gap-2 text-sm text-slate-600"><MapPin className="mt-0.5 h-4 w-4 shrink-0" /><span>{deal.voucher_terms.redemption_location}</span></div>}
            {deal.voucher_terms.redemption_instructions && <p className="mt-3 text-sm text-slate-600">{deal.voucher_terms.redemption_instructions}</p>}
            {deal.voucher_terms.terms && <p className="mt-3 text-xs leading-5 text-slate-500">{deal.voucher_terms.terms}</p>}
            <div className="mt-4 rounded-xl border border-indigo-100 bg-indigo-50 p-3 text-xs text-indigo-900">השובר מונפק רק לאחר שהעסקה הושלמה והחיוב בפועל הצליח.</div>
          </Card>}

          {deal.deal_type === "ticket" && deal.ticket_terms && <Card className="p-5 sm:p-6">
            <div className="flex items-center gap-2"><Ticket className="h-5 w-5 text-indigo-600" /><h2 className="font-semibold">פרטי הכרטיס</h2></div>
            <div className="mt-4 space-y-3 text-sm text-slate-600">
              <div className="font-semibold text-slate-900">{deal.ticket_terms.event_name}</div>
              {deal.ticket_terms.event_starts_at && <div className="flex gap-2"><CalendarDays className="mt-0.5 h-4 w-4 shrink-0" /><span>{new Date(deal.ticket_terms.event_starts_at).toLocaleString("he-IL")}</span></div>}
              {(deal.ticket_terms.venue_name || deal.ticket_terms.venue_address || deal.ticket_terms.venue_city) && <div className="flex gap-2"><MapPin className="mt-0.5 h-4 w-4 shrink-0" /><span>{[deal.ticket_terms.venue_name, deal.ticket_terms.venue_address, deal.ticket_terms.venue_city].filter(Boolean).join(", ")}</span></div>}
              {deal.ticket_terms.entry_instructions && <p>{deal.ticket_terms.entry_instructions}</p>}
            </div>
            <div className="mt-4 rounded-xl border border-indigo-100 bg-indigo-50 p-3 text-xs text-indigo-900">הכרטיס מונפק רק לאחר שהעסקה הושלמה והחיוב בפועל הצליח.</div>
          </Card>}

          {(sellerWhatsApp || deal.seller_contact?.support_email) && <Card className="p-5 sm:p-6">
            <div className="flex items-center gap-2"><MessageCircle className="h-5 w-5 text-emerald-600" /><h2 className="font-semibold">שאלות? צרו קשר עם המוכר</h2></div>
            <div className="mt-4 flex flex-wrap gap-2">
              {sellerWhatsApp && <Button type="button" variant="outline" onClick={() => openShare(`https://wa.me/${sellerWhatsApp}?text=${encodeURIComponent(`היי, אני מעוניין בפרטים נוספים לגבי העסקה ${deal.title} בסיטון`)}`)}>WhatsApp</Button>}
              {deal.seller_contact?.support_email && <Button type="button" variant="outline" onClick={() => openShare(`mailto:${encodeURIComponent(deal.seller_contact.support_email)}?subject=${encodeURIComponent(`שאלה לגבי ${deal.title}`)}&body=${encodeURIComponent(`היי, אני מעוניין בפרטים נוספים לגבי העסקה ${deal.title} בסיטון`)}`)}><Mail className="ml-2 h-4 w-4" />מייל</Button>}
            </div>
          </Card>}

          <Card className="p-5 sm:p-6">
            <div className="flex items-center justify-between gap-3"><div className="flex items-center gap-2"><MessageCircle className="h-5 w-5 text-indigo-600" /><h2 className="font-semibold">תגובות ושיחה</h2></div><span className="text-xs text-slate-400">מתעדכן כל 15 שניות</span></div>
            <div className="mt-4 max-h-80 space-y-2 overflow-y-auto rounded-xl bg-slate-50 p-3">
              {comments.length ? comments.map((comment) => <div key={comment.comment_id} className="rounded-lg border bg-white px-3 py-2"><div className="flex items-center justify-between gap-3"><span className="text-sm font-medium">{comment.display_name}</span><span className="text-[11px] text-slate-400">{comment.created_at ? new Date(comment.created_at).toLocaleString("he-IL") : ""}</span></div><div className="mt-1 whitespace-pre-wrap break-words text-sm text-slate-700">{comment.message}</div></div>) : <div className="py-5 text-center text-sm text-slate-500">עדיין אין תגובות. אפשר להיות הראשונים.</div>}
            </div>
            <div className="mt-4 grid gap-2 sm:grid-cols-[160px_1fr_auto]">
              <Input value={commentName} onChange={(e) => setCommentName(e.target.value)} maxLength={80} placeholder="שם" />
              <textarea value={commentText} onChange={(e) => setCommentText(e.target.value)} maxLength={500} rows={2} placeholder="כתבו תגובה..." className="min-h-10 rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" />
              <Button type="button" onClick={submitComment} disabled={commentBusy}>{commentBusy ? "שולח..." : "פרסם"}</Button>
            </div>
            {commentStatus && <div className="mt-2 text-xs text-slate-500">{commentStatus}</div>}
          </Card>

          <Card className="p-5 sm:p-6">
            <h2 className="font-semibold">איך התשלום עובד?</h2>
            <div className="mt-4 space-y-3 text-sm text-slate-600">
              <div className="flex gap-3"><LockKeyhole className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" /><p>בהצטרפות מתבצעת תפיסת מסגרת בלבד. אין חיוב בפועל בשלב הזה.</p></div>
              <div className="flex gap-3"><Package className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" /><p>העסקה מצליחה לאחר הגעה לסף הקנוני של 90% מהיעד. החיוב מתבצע רק לאחר סגירה מוצלחת בהתאם למנגנון סיטון.</p></div>
              <div className="flex gap-3"><CreditCard className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" /><p>הסכום המוצג כולל את הכמות ואת אפשרות המשלוח שבחרת.</p></div>
            </div>
          </Card>
        </section>

        <Card className="h-fit p-5 sm:p-6">
          <h2 className="text-xl font-semibold">הצטרפות לעסקה</h2>
          {!deal.join_open ? (
            <div className="mt-5 rounded-xl border bg-slate-50 p-4 text-sm text-slate-600">{Number(deal.remaining_units || 0) === 0 ? "המלאי אזל · המכירה הסתיימה" : "העסקה אינה פתוחה כרגע להצטרפות חדשה."}</div>
          ) : (
            <div className="mt-5 space-y-5">
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
                <div className="space-y-2"><Label htmlFor="buyer-name">שם</Label><Input id="buyer-name" value={buyerName} onChange={(e) => setBuyerName(e.target.value)} /></div>
                <div className="space-y-2"><Label htmlFor="phone">טלפון</Label><Input id="phone" dir="ltr" value={buyerId} onChange={(e) => setBuyerId(e.target.value)} placeholder="05..." /></div>
                <div className="space-y-2"><Label htmlFor="email">מייל</Label><Input id="email" dir="ltr" type="email" value={buyerEmail} onChange={(e) => setBuyerEmail(e.target.value)} /></div>
                <div className="space-y-2"><Label htmlFor="qty">כמות</Label><Input id="qty" type="number" min="1" max={Math.max(1, deal.remaining_units)} value={qty} onChange={(e) => setQty(e.target.value)} /></div>
              </div>

              {isPhysical && (deal.delivery_options || []).length > 0 && <div className="space-y-2"><Label>מסירה</Label><Select value={deliveryOptionId} onValueChange={setDeliveryOptionId}><SelectTrigger><SelectValue placeholder="בחר אפשרות" /></SelectTrigger><SelectContent>{deal.delivery_options.map((option) => <SelectItem key={option.option_id} value={option.option_id}>{option.label} · {money(option.cost)}</SelectItem>)}</SelectContent></Select></div>}
              {deliveryRequired && <div className="space-y-3"><Input value={deliveryAddress} onChange={(e) => setDeliveryAddress(e.target.value)} placeholder="כתובת למשלוח" /><Input value={deliveryCity} onChange={(e) => setDeliveryCity(e.target.value)} placeholder="עיר" /></div>}
              {isPhysical && <div className="space-y-2"><Label htmlFor="notes">הערות למסירה</Label><Input id="notes" maxLength={200} value={deliveryNotes} onChange={(e) => setDeliveryNotes(e.target.value)} /></div>}

              <div className="rounded-xl border bg-slate-50 p-4">
                <div className="flex items-center justify-between"><span className="text-sm text-slate-600">סך הכול לתפיסת מסגרת</span><span className="text-xl font-bold">{money(total)}</span></div>
                <p className="mt-2 text-xs text-slate-500">תפיסת מסגרת בלבד. לא מתבצע חיוב עכשיו.</p>
              </div>

              <div className="rounded-xl border p-4">
                <div className="flex items-center justify-between gap-3"><div><div className="font-medium">אימות OTP</div><div className="text-xs text-slate-500">נדרש לפני יצירת ההצטרפות</div></div>{otpToken && <CheckCircle2 className="h-5 w-5 text-emerald-600" />}</div>
                {!otpToken && <div className="mt-4 space-y-3">
                  <Select value={otpChannel} onValueChange={setOtpChannel}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="sms">SMS לטלפון</SelectItem><SelectItem value="email">מייל</SelectItem></SelectContent></Select>
                  {!otpChallengeId ? <Button type="button" variant="outline" className="w-full" onClick={requestOtp} disabled={busy === "otp-request"}>{busy === "otp-request" ? "יוצר אתגר..." : "שלח קוד אימות"}</Button> : <div className="space-y-2"><div className="text-xs text-slate-500">יעד: {otpDestinationDisplay}</div><div className="flex gap-2"><Input dir="ltr" inputMode="numeric" value={otpCode} onChange={(e) => setOtpCode(e.target.value)} placeholder="קוד" /><Button type="button" onClick={verifyOtp} disabled={busy === "otp-verify"}>{busy === "otp-verify" ? "בודק..." : "אמת"}</Button></div></div>}
                  {otpStatus && <div className="text-xs text-amber-700">{otpStatus}</div>}
                </div>}
              </div>

              <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
                שכבת הסליקה האמיתית עדיין לא חוברה ל־Base44. לכן כפתור ההצטרפות נשאר חסום עד שיש לנו Authorization אמיתי מספק התשלום. אין כאן חיוב דמה שמתחזה לסליקה.
              </div>

              {error && <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}
              <Button className="w-full" disabled>הצטרף לעסקה · תפיסת מסגרת</Button>
            </div>
          )}
        </Card>
      </main>
    </div>
  );
}
