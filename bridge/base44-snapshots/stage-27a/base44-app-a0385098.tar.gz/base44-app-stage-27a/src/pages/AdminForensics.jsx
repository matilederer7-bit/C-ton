import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Search, ShieldCheck } from "lucide-react";

const inputClass = "w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-400";

function JsonBlock({ value }) {
  return <pre className="max-h-72 overflow-auto whitespace-pre-wrap break-words rounded-lg bg-slate-950 p-3 text-xs text-slate-100">{JSON.stringify(value, null, 2)}</pre>;
}

function Section({ title, rows, empty = "אין התאמות" }) {
  return <Card className="overflow-hidden"><div className="border-b px-5 py-4"><h2 className="font-semibold">{title}</h2><div className="mt-1 text-xs text-slate-500">{rows?.length || 0} תוצאות</div></div><div className="space-y-3 p-5">{rows?.length ? rows.map((row, index)=><JsonBlock key={row.case_id || row.deal_id || row.participant_id || row.event_uuid || row.attempt_id || row.delivery_id || row.attribution_id || index} value={row}/>) : <div className="text-sm text-slate-500">{empty}</div>}</div></Card>;
}

export default function AdminForensics() {
  const [q, setQ] = useState("");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const search = async () => {
    setLoading(true); setError("");
    try {
      const response = await base44.functions.invoke("admin-forensics", { q });
      setData(response?.data || response);
    } catch (e) { setError(e?.response?.data?.error || e?.message || "חיפוש פורנזי נכשל"); }
    finally { setLoading(false); }
  };

  const verdict = data?.verdict || "green";
  return <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
    <header className="border-b bg-white"><div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between"><div><div className="flex items-center gap-2 text-sm font-medium text-indigo-700"><ShieldCheck className="h-4 w-4"/>Forensics</div><h1 className="mt-1 text-2xl font-bold">חקירת מערכת</h1><p className="mt-1 text-sm text-slate-500">חיפוש קריאה בלבד. מזהי Authorization, tracking hashes, secrets ופרטי תשלום רגישים מוסתרים.</p></div><Button asChild variant="outline"><Link to="/admin" className="gap-2"><ArrowRight className="h-4 w-4"/>Mission Control</Link></Button></div></header>
    <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6">
      {error && <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
      <Card className="p-5"><div className="flex flex-col gap-3 sm:flex-row"><input className={inputClass} value={q} onChange={(e)=>setQ(e.target.value)} onKeyDown={(e)=>{if(e.key==="Enter") search();}} placeholder="Deal ID, Participant ID, Case ID, Event ID, source code, State..."/><Button onClick={search} disabled={loading} className="gap-2"><Search className="h-4 w-4"/>{loading?"מחפש...":"חפש"}</Button></div><div className="mt-2 text-xs text-slate-500">אפשר להשאיר ריק לקבלת תמונת מצב רחבה של הרשומות האחרונות.</div></Card>
      {data && <>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><Card className={`p-4 ${verdict==="red"?"border-red-200 bg-red-50":verdict==="yellow"?"border-amber-200 bg-amber-50":"border-emerald-200 bg-emerald-50"}`}><div className="text-xs text-slate-500">Verdict</div><div className="mt-1 text-2xl font-bold">{verdict}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">Deals</div><div className="mt-1 text-2xl font-bold">{data.counts?.deals || 0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">Outbox</div><div className="mt-1 text-2xl font-bold">{data.counts?.outbox || 0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">Support</div><div className="mt-1 text-2xl font-bold">{data.counts?.support_cases || 0}</div></Card></div>
        {(data.anomalies || []).length > 0 && <Card className="p-5"><h2 className="font-semibold">Anomalies</h2><div className="mt-3 flex flex-wrap gap-2">{data.anomalies.map((row,index)=><Badge key={`${row.domain}-${index}`} variant={row.severity==="critical"?"destructive":"secondary"}>{row.domain}: {row.title} · {row.count}</Badge>)}</div></Card>}
        <div className="grid gap-5 xl:grid-cols-2"><Section title="Deals" rows={data.deals}/><Section title="Participants" rows={data.participants}/><Section title="Outbox" rows={data.outbox}/><Section title="Payment Attempts" rows={data.payment_attempts}/><Section title="Support Cases" rows={data.support_cases}/><Section title="Deliveries" rows={data.deliveries}/><Section title="Distribution Attributions" rows={data.attributions}/></div>
        <Card className="p-4 text-xs text-slate-500">Redacted: {(data.redacted_fields || []).join(" · ")}</Card>
      </>}
    </main>
  </div>;
}
