import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, OctagonX, RefreshCw, ShieldAlert, UserCheck } from "lucide-react";

const TYPES=["pause_joining_emergency","pause_charging_emergency","payout_freeze","content_takedown"];
const SCOPES=["global","deal","seller","participant","payout","content"];
const EMERGENCY=new Set(["pause_joining_emergency","pause_charging_emergency"]);
const inputClass="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-400";
function localDefault(){const d=new Date(Date.now()+60*60_000);return new Date(d.getTime()-d.getTimezoneOffset()*60_000).toISOString().slice(0,16);}
function fmt(v){if(!v)return"—";const d=new Date(v);return Number.isNaN(d.getTime())?"—":new Intl.DateTimeFormat("he-IL",{dateStyle:"short",timeStyle:"short"}).format(d);}
function statusLabel(status){return ({pending_approval:"ממתין לאדמין שני",active:"פעיל",released:"שוחרר",expired:"פג תוקף"})[status]||status;}

export default function AdminControls(){
 const [data,setData]=useState(null),[loading,setLoading]=useState(true),[error,setError]=useState(""),[busy,setBusy]=useState("");
 const [form,setForm]=useState({flag_type:"pause_joining_emergency",scope_type:"global",scope_id:"",reason:"",expires_at:localDefault()});
 const invoke=async(payload)=>{const r=await base44.functions.invoke("admin-control-flags",payload);return r?.data||r;};
 const load=async()=>{setLoading(true);setError("");try{setData(await invoke({operation:"list"}));}catch(e){setError(e?.response?.data?.error||e?.message||"לא ניתן לטעון בקרות");}finally{setLoading(false);}};
 useEffect(()=>{load();},[]);
 const act=async(key,payload)=>{setBusy(key);setError("");try{await invoke(payload);await load();}catch(e){setError(e?.response?.data?.error||e?.message||"הפעולה נכשלה");}finally{setBusy("");}};
 const create=async()=>{if(!form.reason.trim())return setError("Reason הוא חובה");if(form.scope_type!=="global"&&!form.scope_id.trim())return setError("Scope ID הוא חובה");const emergency=EMERGENCY.has(form.flag_type);await act("create",{operation:"create",...form,expires_at:emergency?new Date(form.expires_at).toISOString():null});setForm(v=>({...v,reason:"",scope_id:v.scope_type==="global"?"":v.scope_id}));};
 const summary=data?.summary||{};
 return <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
  <header className="border-b bg-white"><div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between"><div><div className="flex items-center gap-2 text-sm font-medium text-red-700"><OctagonX className="h-4 w-4"/>Admin Intervention</div><h1 className="mt-1 text-2xl font-bold">בקרות חירום</h1><p className="mt-1 text-sm text-slate-500">עצירת הצטרפות או חיוב דורשת שני אדמינים שונים. בקשת שחרור אינה מסירה חסימה עד אישור שני.</p></div><div className="flex gap-2"><Button asChild variant="outline"><Link to="/admin" className="gap-2"><ArrowRight className="h-4 w-4"/>Mission Control</Link></Button><Button variant="outline" onClick={load} disabled={loading} className="gap-2"><RefreshCw className={`h-4 w-4 ${loading?"animate-spin":""}`}/>רענון</Button></div></div></header>
  <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6">
   {error&&<div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
   <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6"><Metric label="Active" value={summary.active}/><Metric label="ממתין לאישור" value={summary.pending_approval}/><Metric label="ממתין לשחרור" value={summary.pending_release}/><Metric label="Join paused" value={summary.joining_pauses}/><Metric label="Charging paused" value={summary.charging_pauses}/><Metric label="Released" value={summary.released}/></div>
   <Card className="p-5"><div className="mb-4 flex items-center gap-2"><ShieldAlert className="h-4 w-4"/><h2 className="font-semibold">Flag חדש</h2></div><div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3"><select className={inputClass} value={form.flag_type} onChange={e=>setForm({...form,flag_type:e.target.value})}>{TYPES.map(v=><option key={v}>{v}</option>)}</select><select className={inputClass} value={form.scope_type} onChange={e=>setForm({...form,scope_type:e.target.value,scope_id:e.target.value==="global"?"":form.scope_id})}>{SCOPES.map(v=><option key={v}>{v}</option>)}</select><input className={inputClass} disabled={form.scope_type==="global"} placeholder="Scope ID" value={form.scope_id} onChange={e=>setForm({...form,scope_id:e.target.value})}/><input className={inputClass} placeholder="Reason" value={form.reason} onChange={e=>setForm({...form,reason:e.target.value})}/>{EMERGENCY.has(form.flag_type)&&<input type="datetime-local" className={inputClass} value={form.expires_at} onChange={e=>setForm({...form,expires_at:e.target.value})}/>}</div><Button className="mt-3" variant={EMERGENCY.has(form.flag_type)?"outline":"destructive"} onClick={create} disabled={busy==="create"}>{EMERGENCY.has(form.flag_type)?"שלח לאישור אדמין שני":"הפעל Flag"}</Button>{EMERGENCY.has(form.flag_type)&&<p className="mt-2 text-xs text-slate-500">הבקשה לא תחסום פעילות עד שאדמין אחר יאשר אותה.</p>}</Card>
   <div className="space-y-3">{(data?.flags||[]).map(flag=>{
    const emergency=Boolean(flag.emergency);const pendingRelease=flag.status==="active"&&Boolean(flag.release_requested_at);
    return <Card key={flag.flag_id} className="p-5"><div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between"><div><div className="flex flex-wrap items-center gap-2"><span className="font-semibold">{flag.flag_type}</span><Badge variant={flag.status==="active"?"destructive":"outline"}>{statusLabel(flag.status)}</Badge><Badge variant="secondary">{flag.scope_type}{flag.scope_id?`:${flag.scope_id}`:""}</Badge>{pendingRelease&&<Badge variant="outline">ממתין לאישור שחרור</Badge>}</div><div className="mt-2 text-sm text-slate-600">{flag.reason}</div><div className="mt-1 text-xs text-slate-500">נוצר {fmt(flag.created_at)} · תפוגה {fmt(flag.expires_at)} · Audit {flag.event_count||0}</div>{flag.approved_at&&<div className="mt-1 text-xs text-slate-500">אושר בידי אדמין שני {fmt(flag.approved_at)}</div>}{flag.release_requested_at&&<div className="mt-1 text-xs text-amber-700">שחרור התבקש {fmt(flag.release_requested_at)}. החסימה עדיין פעילה.</div>}</div><div className="flex flex-wrap gap-2">
      {emergency&&flag.status==="pending_approval"&&<Button className="gap-2" variant="destructive" onClick={()=>act(flag.flag_id,{operation:"approve",flag_id:flag.flag_id})} disabled={busy===flag.flag_id}><UserCheck className="h-4 w-4"/>אשר כאדמין שני</Button>}
      {emergency&&flag.status==="active"&&!pendingRelease&&<Button variant="outline" onClick={()=>act(flag.flag_id,{operation:"release_request",flag_id:flag.flag_id,release_reason:"manual admin release request"})} disabled={busy===flag.flag_id}>בקש שחרור</Button>}
      {emergency&&pendingRelease&&<Button variant="outline" onClick={()=>act(flag.flag_id,{operation:"release_approve",flag_id:flag.flag_id})} disabled={busy===flag.flag_id}>אשר שחרור כאדמין שני</Button>}
      {!emergency&&flag.status==="active"&&<Button variant="outline" onClick={()=>act(flag.flag_id,{operation:"release",flag_id:flag.flag_id,release_reason:"manual admin release"})} disabled={busy===flag.flag_id}>שחרר</Button>}
     </div></div></Card>})}</div>
  </main>
 </div>;
}
function Metric({label,value}){return <Card className="p-4"><div className="text-xs text-slate-500">{label}</div><div className="mt-1 text-2xl font-bold">{value||0}</div></Card>}
