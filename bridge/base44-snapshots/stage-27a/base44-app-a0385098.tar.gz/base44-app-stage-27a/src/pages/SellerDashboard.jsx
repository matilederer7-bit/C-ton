import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Clock3, ExternalLink, Package, Plus, RefreshCw, ShieldCheck, Target } from "lucide-react";

const STATE_LABELS = {
  Draft: "טיוטה",
  PendingTarget: "פתוחה להצטרפות",
  TargetReached: "היעד הושג",
  ClosedForJoining: "סגורה להצטרפות",
  ReadyForCharging: "מוכנה לחיוב",
  Charging: "בתהליך חיוב",
  CompletionWindow: "חלון השלמה",
  Completed: "הושלמה",
  Failed: "נכשלה",
  Cancelled: "בוטלה",
};

function money(value) {
  return new Intl.NumberFormat("he-IL", {
    style: "currency",
    currency: "ILS",
    maximumFractionDigits: 2,
  }).format(Number(value || 0));
}

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("he-IL", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

function stateTone(state) {
  if (state === "Completed") return "default";
  if (["Failed", "Cancelled"].includes(state)) return "destructive";
  if (["TargetReached", "ReadyForCharging", "Charging", "CompletionWindow"].includes(state)) return "secondary";
  return "outline";
}

function remaining(value) {
  if (!value) return "—";
  const diff = Math.max(0, new Date(value).getTime() - Date.now());
  if (!Number.isFinite(diff)) return "—";
  const totalMinutes = Math.floor(diff / 60000);
  const days = Math.floor(totalMinutes / 1440);
  const hours = Math.floor((totalMinutes % 1440) / 60);
  const minutes = totalMinutes % 60;
  if (days > 0) return `${days} ימים ${hours} שעות`;
  if (hours > 0) return `${hours}:${String(minutes).padStart(2, "0")} שעות`;
  return `${minutes} דק׳`;
}

export default function SellerDashboard() {
  const [deals, setDeals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [publishingId, setPublishingId] = useState("");
  const [lastUpdatedAt, setLastUpdatedAt] = useState(null);
  const [, setClockTick] = useState(0);

  const loadDeals = async ({ background = false } = {}) => {
    if (!background) setLoading(true);
    if (!background) setError("");
    try {
      const response = await base44.functions.invoke("seller-deals", {});
      const result = response?.data || response;
      setDeals(result?.deals || []);
      setLastUpdatedAt(new Date());
    } catch (e) {
      if (!background) setError(e?.message || "לא ניתן לטעון את עסקאות המוכר");
    } finally {
      if (!background) setLoading(false);
    }
  };

  useEffect(() => {
    loadDeals();
    const refreshTimer = window.setInterval(() => {
      if (document.visibilityState === "visible") loadDeals({ background: true });
    }, 25_000);
    const clockTimer = window.setInterval(() => setClockTick((value) => value + 1), 5_000);
    return () => { window.clearInterval(refreshTimer); window.clearInterval(clockTimer); };
  }, []);

  const summary = useMemo(() => {
    const activeStates = new Set(["PendingTarget", "TargetReached", "ClosedForJoining", "ReadyForCharging", "Charging", "CompletionWindow"]);
    return {
      total: deals.length,
      active: deals.filter((deal) => activeStates.has(deal.state)).length,
      completed: deals.filter((deal) => deal.state === "Completed").length,
      reserved: deals.reduce((sum, deal) => sum + Number(deal.reserved_units || 0), 0),
    };
  }, [deals]);
  const urgentDeals = useMemo(() => deals.filter((deal) => ["Charging", "CompletionWindow"].includes(deal.state)).sort((a, b) => new Date(a.completion_window_until || a.deadline || 0).getTime() - new Date(b.completion_window_until || b.deadline || 0).getTime()), [deals]);
  const regularDeals = useMemo(() => deals.filter((deal) => !["Charging", "CompletionWindow"].includes(deal.state)).sort((a, b) => new Date(b.updated_date || b.created_date || 0).getTime() - new Date(a.updated_date || a.created_date || 0).getTime()), [deals]);
  const orderedDeals = [...urgentDeals, ...regularDeals];
  const stale = Boolean(lastUpdatedAt && Date.now() - lastUpdatedAt.getTime() > 60_000);

  const publishDeal = async (deal) => {
    const confirmed = window.confirm("לפרסם את העסקה? לאחר הפרסום התנאים הקריטיים ננעלים וכלל סף ה־90% חל על העסקה.");
    if (!confirmed) return;
    setPublishingId(deal.deal_id);
    setError("");
    try {
      await base44.functions.invoke("publish-deal", {
        deal_id: deal.deal_id,
        seller_terms_accepted: true,
        seller_critical_terms_accepted: true,
        seller_threshold_90_accepted: true,
        idempotency_key: `publish:${deal.deal_id}`,
      });
      await loadDeals();
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "פרסום העסקה נכשל");
    } finally {
      setPublishingId("");
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b bg-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between">
          <div>
            <div className="flex items-center gap-2 text-sm font-medium text-emerald-700">
              <ShieldCheck className="h-4 w-4" /> אזור מוכר
            </div>
            <h1 className="mt-1 text-2xl font-bold tracking-tight">דשבורד עסקאות</h1>
            <p className="mt-1 text-sm text-slate-500">תמונה חיה של העסקאות שלך בלבד. הנתונים מגיעים דרך Projection בטוח ב־Backend ושינויי State נעשים רק דרך פעולות מורשות.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="outline"><Link to="/seller/analytics">אנליטיקה</Link></Button>
            <Button asChild variant="outline"><Link to="/seller/payouts">תשלומים</Link></Button>
            <Button asChild variant="outline"><Link to="/seller/profile">פרטי מוכר</Link></Button>
            <Button asChild><Link to="/" className="gap-2"><Plus className="h-4 w-4" />עסקה חדשה</Link></Button>
            <Button variant="outline" onClick={() => loadDeals()} disabled={loading} className="gap-2">
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />רענון
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6">
        <div className={`flex flex-wrap items-center justify-between gap-3 rounded-xl border px-4 py-3 text-sm ${stale ? "border-amber-200 bg-amber-50 text-amber-900" : "bg-white text-slate-600"}`}>
          <span>{stale ? "נתונים עלולים להיות לא עדכניים – רענן" : "מתעדכן אוטומטית כל 25 שניות"}</span>
          <span className="text-xs">{lastUpdatedAt ? `עודכן לאחרונה ${lastUpdatedAt.toLocaleTimeString("he-IL", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}` : "טרם התקבל עדכון"}</span>
        </div>
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card className="p-5"><div className="flex items-center justify-between"><div><div className="text-sm text-slate-500">כל העסקאות</div><div className="mt-1 text-3xl font-bold">{summary.total}</div></div><Package className="h-6 w-6 text-slate-400" /></div></Card>
          <Card className="p-5"><div className="flex items-center justify-between"><div><div className="text-sm text-slate-500">עסקאות פעילות</div><div className="mt-1 text-3xl font-bold">{summary.active}</div></div><Clock3 className="h-6 w-6 text-orange-500" /></div></Card>
          <Card className="p-5"><div className="flex items-center justify-between"><div><div className="text-sm text-slate-500">עסקאות שהושלמו</div><div className="mt-1 text-3xl font-bold">{summary.completed}</div></div><Target className="h-6 w-6 text-emerald-600" /></div></Card>
          <Card className="p-5"><div className="flex items-center justify-between"><div><div className="text-sm text-slate-500">יחידות שמורות</div><div className="mt-1 text-3xl font-bold">{summary.reserved}</div></div><Package className="h-6 w-6 text-blue-500" /></div></Card>
        </section>

        {error && <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}

        <Card className="overflow-hidden">
          <div className="border-b px-5 py-4">
            <h2 className="font-semibold">העסקאות שלי</h2>
            <p className="mt-1 text-xs text-slate-500">ה־Backend מאמת בעלות ומחזיר רק שדות מוכר בטוחים. הרשומה הקנונית של Deal אינה נקראת ישירות מהדפדפן.</p>
          </div>

          {loading ? (
            <div className="p-10 text-center text-sm text-slate-500">טוען עסקאות...</div>
          ) : deals.length === 0 ? (
            <div className="p-10 text-center">
              <div className="font-medium">עדיין אין עסקאות</div>
              <p className="mt-1 text-sm text-slate-500">צור עסקה ראשונה כדי להתחיל.</p>
              <Button asChild className="mt-4"><Link to="/">צור עסקה</Link></Button>
            </div>
          ) : (
            <div>
              {orderedDeals.map((deal, index) => {
                const reserved = Number(deal.reserved_units || 0);
                const minimum = Math.max(1, Number(deal.min_units || 1));
                const minimumProgress = Math.min(100, Math.round((reserved / minimum) * 100));
                const isUrgent = ["Charging", "CompletionWindow"].includes(deal.state);
                const endingAt = deal.state === "CompletionWindow" ? deal.completion_window_until : deal.deadline;
                const endingMs = endingAt ? new Date(endingAt).getTime() : Number.POSITIVE_INFINITY;
                const underHour = Number.isFinite(endingMs) && endingMs - Date.now() > 0 && endingMs - Date.now() < 60 * 60 * 1000;
                return (
                  <React.Fragment key={deal.deal_id}>
                    {index === 0 && urgentDeals.length > 0 && <div className="border-b bg-amber-50 px-5 py-3 text-sm font-semibold text-amber-900">עסקאות דחופות · Charging / Completion Window</div>}
                    {index === urgentDeals.length && regularDeals.length > 0 && <div className="border-y bg-slate-50 px-5 py-3 text-sm font-semibold text-slate-700">כל השאר · לפי עדכון אחרון</div>}
                    <div className={`border-b p-5 last:border-b-0 ${deal.state === "CompletionWindow" ? "bg-amber-50/50" : "bg-white"}`}>
                      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                        <div className="flex min-w-0 flex-1 gap-4">
                          <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-slate-100">{deal.primary_image_url ? <img src={deal.primary_image_url} alt="" className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-slate-400"><Package className="h-6 w-6" /></div>}</div>
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-2"><h3 className="truncate text-lg font-semibold">{deal.title}</h3><Badge variant={stateTone(deal.state)}>{STATE_LABELS[deal.state] || deal.state}</Badge>{underHour && <span className="text-sm font-semibold text-red-700">מסתיים בקרוב · {remaining(endingAt)}</span>}</div>
                            {deal.short_description && <div className="mt-1 line-clamp-2 text-sm text-slate-500">{deal.short_description}</div>}

                            <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
                              <div><div className="text-xs text-slate-500">נפח עסקה</div><div className={`mt-1 font-semibold ${deal.state === "Failed" ? "text-slate-500 line-through" : ""}`}>{money(deal.volume_amount)}</div></div>
                              <div><div className="text-xs text-emerald-700">מחויב</div><div className="mt-1 font-semibold text-emerald-700">{deal.final_units || 0}</div></div>
                              <div><div className="text-xs text-orange-700">{deal.state === "CompletionWindow" ? "בסיכון" : "בהמתנה"}</div><div className="mt-1 font-semibold text-orange-700">{deal.pending_units || 0}</div></div>
                              <div><div className="text-xs text-slate-500">לא חויב</div><div className="mt-1 font-medium">{deal.failed_units || 0}</div></div>
                              <div><div className="text-xs text-slate-500">מינימום</div><div className="mt-1 font-medium">{deal.min_units}</div></div>
                              <div><div className="text-xs text-slate-500">זמן</div><div className="mt-1 font-medium">{isUrgent ? remaining(endingAt) : remaining(deal.deadline)}</div></div>
                            </div>

                            <div className="mt-4 space-y-2"><div className="flex items-center justify-between text-xs text-slate-500"><span>{reserved} / {minimum} יחידות אל המינימום</span><span>{minimumProgress}%</span></div><Progress value={minimumProgress} /></div>
                            {deal.state === "Failed" && deal.failure_reason && <div className="mt-3 text-sm text-red-700">{deal.failure_reason}</div>}
                          </div>
                        </div>

                        <div className="flex shrink-0 flex-wrap gap-2 lg:w-48 lg:flex-col">
                          <Button asChild variant="outline"><Link to={`/seller/deal/${encodeURIComponent(deal.deal_id)}`}>פרטי עסקה</Link></Button>
                          {deal.state === "Draft" ? <Button onClick={() => publishDeal(deal)} disabled={publishingId === deal.deal_id}>{publishingId === deal.deal_id ? "מפרסם..." : "פרסם עסקה"}</Button> : <Button asChild variant="outline"><a href={`/deal/${encodeURIComponent(deal.deal_id)}`} target="_blank" rel="noreferrer" className="gap-2"><ExternalLink className="h-4 w-4" />עמוד קונה</a></Button>}
                        </div>
                      </div>
                    </div>
                  </React.Fragment>
                );
              })}
            </div>
          )}
        </Card>

        <p className="text-xs leading-5 text-slate-500">עמלת סיטון הקנונית היא 8% על הכול כולל משלוח, למעט מע״מ. אין עמלת מפיצים. הדשבורד אינו מאפשר שינוי ידני של State או מצב כספי.</p>
      </main>
    </div>
  );
}
