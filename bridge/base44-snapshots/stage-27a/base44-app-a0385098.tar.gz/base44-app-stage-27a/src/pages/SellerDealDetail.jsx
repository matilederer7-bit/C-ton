import React, { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, ArrowRight, Clock3, ExternalLink, FileText, PackageCheck, PlusCircle, RefreshCw, ShieldCheck, WalletCards, XCircle } from "lucide-react";

const STATE_LABELS = {
  Draft: "טיוטה",
  PendingTarget: "פתוחה להצטרפות",
  TargetReached: "היעד הושג",
  ClosedForJoining: "סגורה להצטרפות",
  ReadyForCharging: "מוכנה לחיוב",
  Charging: "בתהליך חיוב",
  CompletionWindow: "חלון השלמה",
  Completed: "הושלמה",
  Failed: "נכשלה",
  Cancelled: "בוטלה",
};

const TERMINAL = new Set(["Completed", "Failed", "Cancelled"]);
const PIE_COLORS = ["#166534", "#f97316", "#b91c1c"];

function money(value) {
  return new Intl.NumberFormat("he-IL", { style: "currency", currency: "ILS", maximumFractionDigits: 2 }).format(Number(value || 0));
}
function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("he-IL", { dateStyle: "short", timeStyle: "short" }).format(date);
}
function entries(record) {
  return Object.entries(record || {}).sort((a, b) => Number(b[1]) - Number(a[1]));
}
function remaining(value) {
  if (!value) return "—";
  const diff = new Date(value).getTime() - Date.now();
  if (!Number.isFinite(diff) || diff <= 0) return "הזמן הסתיים";
  const minutes = Math.floor(diff / 60000), days = Math.floor(minutes / 1440), hours = Math.floor((minutes % 1440) / 60), mins = minutes % 60;
  if (days > 0) return `${days} ימים ${hours} שעות`;
  if (hours > 0) return `${hours} שעות ${mins} דקות`;
  return `${mins} דקות`;
}
function statusClass(state) {
  if (state === "Completed") return "border-emerald-200 bg-emerald-50 text-emerald-800";
  if (["Failed", "Cancelled"].includes(state)) return "border-red-200 bg-red-50 text-red-800";
  if (state === "CompletionWindow") return "border-red-200 bg-red-50 text-red-800";
  if (["TargetReached", "ReadyForCharging"].includes(state)) return "border-emerald-200 bg-emerald-50 text-emerald-800";
  if (state === "Charging") return "border-blue-200 bg-blue-50 text-blue-800";
  return "border-orange-200 bg-orange-50 text-orange-800";
}

export default function SellerDealDetail() {
  const { dealId } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [cancelling, setCancelling] = useState(false);
  const [closing, setClosing] = useState(false);

  const load = async () => {
    setLoading(true); setError("");
    try {
      const response = await base44.functions.invoke("seller-deal-detail", { deal_id: dealId });
      setData(response?.data || response);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "לא ניתן לטעון את העסקה");
    } finally { setLoading(false); }
  };

  useEffect(() => {
    load();
    const timer = window.setInterval(load, 15000);
    return () => window.clearInterval(timer);
  }, [dealId]);

  const deal = data?.deal;
  const summary = data?.summary || {};
  const aggregates = data?.aggregates || {};
  const terminal = TERMINAL.has(deal?.state);
  const liveState = ["PendingTarget","TargetReached","ClosedForJoining","ReadyForCharging","Charging","CompletionWindow"].includes(deal?.state);
  const endingAt = deal?.state === "CompletionWindow" ? deal?.completion_window_until : deal?.deadline;

  const progress = useMemo(() => {
    if (!deal) return { inventory: 0, minimum: 0 };
    const reserved = Number(deal.reserved_units || 0);
    const max = Math.max(1, Number(deal.max_units || 1));
    const minimum = Math.max(1, Number(deal.min_units || 1));
    return { inventory: Math.min(100, Math.round((reserved / max) * 100)), minimum: Math.min(100, Math.round((reserved / minimum) * 100)) };
  }, [deal]);

  const terminalPie = useMemo(() => [
    { name: "חויבו בסבב הראשון", value: Number(summary.initially_charged_units || 0) },
    { name: "הושלמו בחלון", value: Number(summary.recovered_units || 0) },
    { name: "נפלו ולא נכללו", value: Number(summary.excluded_units || 0) },
  ].filter((row) => row.value > 0), [summary]);

  const cancelDraft = async () => {
    if (!dealId) return;
    setCancelling(true); setError("");
    try {
      await base44.functions.invoke("cancel-deal", { deal_id: dealId, idempotency_key: `cancel:${dealId}` });
      await load();
    } catch (e) { setError(e?.response?.data?.error || e?.message || "ביטול הטיוטה נכשל"); }
    finally { setCancelling(false); }
  };

  const closeJoining = async () => {
    if (!dealId || deal?.state !== "TargetReached") return;
    if (!window.confirm("לסגור את העסקה להצטרפות חדשה? לאחר הסגירה לא ניתן לפתוח מחדש.")) return;
    setClosing(true); setError("");
    try {
      await base44.functions.invoke("close-joining", { deal_id: dealId, idempotency_key: `close-joining:${dealId}` });
      await load();
    } catch (e) { setError(e?.response?.data?.error || e?.message || "סגירת ההצטרפות נכשלה"); }
    finally { setClosing(false); }
  };

  const cloneDeal = () => {
    if (!deal) return;
    const firstDelivery = Array.isArray(deal.delivery_options) ? deal.delivery_options[0] : null;
    const clone = {
      title: deal.title || "",
      short_description: deal.short_description || "",
      what_you_get: deal.what_you_get || "",
      deal_type: deal.deal_type || "physical_product",
      price_per_unit: String(deal.price_per_unit ?? ""),
      min_units: String(deal.min_units ?? ""),
      max_units: String(deal.max_units ?? ""),
      deadline_hours: "",
      delivery_label: firstDelivery?.label || "איסוף עצמי",
      delivery_cost: String(firstDelivery?.cost ?? 0),
      voucher_face_value: String(deal.voucher_terms?.face_value_amount ?? ""),
      ticket_event_name: deal.ticket_terms?.event_name || "",
      ticket_event_starts_at: deal.ticket_terms?.event_starts_at || "",
      source_deal_id: deal.deal_id,
    };
    window.sessionStorage.setItem("siton_clone_deal", JSON.stringify(clone));
    window.location.href = "/?clone=1";
  };

  return <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
    <header className="border-b bg-white">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between">
        <div className="flex min-w-0 items-center gap-4">
          {deal?.primary_image_url ? <img src={deal.primary_image_url} alt="" className="h-14 w-14 rounded-xl object-cover" /> : <div className="grid h-14 w-14 shrink-0 place-items-center rounded-xl bg-slate-100"><ShieldCheck className="h-6 w-6 text-slate-400"/></div>}
          <div className="min-w-0">
            <div className="text-sm font-medium text-emerald-700">אזור מוכר</div>
            <div className="mt-1 flex flex-wrap items-center gap-2"><h1 className="truncate text-2xl font-bold">{deal?.title || "פרטי עסקה"}</h1>{deal?.state && <Badge variant="outline" className={statusClass(deal.state)}>{STATE_LABELS[deal.state] || deal.state}</Badge>}</div>
            {terminal && <p className="mt-1 text-sm text-slate-500">נסגרה: {formatDate(deal?.closed_at)}</p>}
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline"><Link to="/seller" className="gap-2"><ArrowRight className="h-4 w-4"/>חזרה לדשבורד</Link></Button>
          {!terminal && <Button variant="outline" onClick={load} disabled={loading} className="gap-2"><RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`}/>רענון</Button>}
          {!terminal && deal?.state === "Draft" && <Button asChild><Link to={`/seller/deal/${encodeURIComponent(deal.deal_id)}/edit`}>ערוך טיוטה</Link></Button>}
          {!terminal && deal?.state === "Draft" && <Button asChild variant="outline"><Link to={`/seller/deal/${encodeURIComponent(deal.deal_id)}/images`}>תמונות</Link></Button>}
          {!terminal && deal?.state === "Draft" && <Button variant="destructive" onClick={cancelDraft} disabled={cancelling} className="gap-2"><XCircle className="h-4 w-4"/>{cancelling ? "מבטל..." : "בטל טיוטה"}</Button>}
          {!terminal && deal?.state === "TargetReached" && <Button onClick={closeJoining} disabled={closing}>{closing ? "סוגר..." : "סגור להצטרפות"}</Button>}
          {!terminal && deal?.state && deal.state !== "Draft" && <Button asChild><a href={`/deal/${encodeURIComponent(deal.deal_id)}`} target="_blank" rel="noreferrer" className="gap-2"><ExternalLink className="h-4 w-4"/>עמוד קונה</a></Button>}
        </div>
      </div>
    </header>

    <main className="mx-auto max-w-6xl space-y-6 px-4 py-6 sm:px-6">
      {error && <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}
      {loading && !deal ? <Card className="p-10 text-center text-sm text-slate-500">טוען...</Card> : !deal ? <Card className="p-10 text-center text-sm text-slate-500">העסקה לא נמצאה או שאינה שייכת למוכר המחובר.</Card> : terminal ? (
        <TerminalDeal deal={deal} summary={summary} aggregates={aggregates} pie={terminalPie} cloneDeal={cloneDeal} />
      ) : (
        <>
          <Card className="p-5 sm:p-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between"><div><p className="text-sm text-slate-500">{deal.short_description || "עסקה חיה"}</p></div><div className="text-left"><div className="text-xs text-slate-500">מחיר ליחידה</div><div className="text-2xl font-bold">{money(deal.price_per_unit)}</div></div></div>
            <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5"><Metric label="יחידות שמורות" value={deal.reserved_units}/><Metric label="יעד מינימום" value={deal.min_units}/><Metric label="סף פיננסי 90%" value={deal.threshold_units}/><Metric label="מלאי מקסימלי" value={deal.max_units}/><Metric label="דדליין" value={formatDate(deal.deadline)} small/></div>
            <div className="mt-6 space-y-3"><div><div className="mb-1 flex justify-between text-xs text-slate-500"><span>ניצול מלאי</span><span>{progress.inventory}%</span></div><Progress value={progress.inventory}/></div><div><div className="mb-1 flex justify-between text-xs text-slate-500"><span>התקדמות למינימום</span><span>{progress.minimum}%</span></div><Progress value={progress.minimum}/></div></div>
          </Card>
          <section className="grid gap-4 md:grid-cols-4"><MoneyMetric label="נפח עסקה" value={summary.volume_amount}/><Metric label="מחויב סופית" value={summary.final_units} tone="success"/><Metric label={deal.state === "CompletionWindow" ? "בסיכון" : "בהמתנה"} value={summary.pending_units} tone="warning"/><Metric label="לא חויב" value={summary.failed_units}/></section>
          {liveState && <Card className="p-5"><div className="flex items-center gap-2"><Clock3 className="h-5 w-5 text-slate-500"/><h3 className="font-semibold">מה יקרה עכשיו</h3></div><div className="mt-2 text-sm text-slate-700">{deal.state === "CompletionWindow" ? (summary.would_meet_financial_threshold_now ? "אם חלון ההשלמה היה מסתיים עכשיו, העסקה הייתה עומדת בסף הפיננסי." : "אם חלון ההשלמה היה מסתיים עכשיו, העסקה הייתה נכשלת.") : deal.state === "Charging" ? "החיובים מתבצעים כעת. אין צורך בפעולה מצד המוכר." : deal.state === "TargetReached" ? "המינימום הושג. ניתן לסגור להצטרפות ולהתקדם למסלול החיוב." : deal.state === "ClosedForJoining" || deal.state === "ReadyForCharging" ? "העסקה נעולה לצפייה בלבד. הפעולות הבאות מתבצעות אוטומטית." : "העסקה פתוחה וממשיכה לצבור יחידות."}</div><div className="mt-2 text-sm font-medium">זמן שנותר: {remaining(endingAt)}</div></Card>}
          <section className="grid gap-4 md:grid-cols-2"><AttributionCard title="שיטות מסירה" data={aggregates.delivery_method_quantity}/><AttributionCard title="מקורות הפצה" data={aggregates.distribution_source_quantity} note="ייחוס בלבד, ללא רכיב כספי או עמלת מפיץ."/></section>
        </>
      )}
    </main>
  </div>;
}

function TerminalDeal({ deal, summary, aggregates, pie, cloneDeal }) {
  const completed = deal.state === "Completed";
  const failed = deal.state === "Failed";
  return <>
    <Card className="p-5 sm:p-6">
      <h2 className="text-lg font-semibold">תקציר סופי</h2>
      {failed && <div className="mt-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800"><div className="font-semibold">סיבת כשל</div><div className="mt-1">{summary.failure_reason || "העסקה לא הושלמה"}</div></div>}
      {deal.state === "Cancelled" && <div className="mt-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">העסקה בוטלה. אין פתיחה מחדש של העסקה הסגורה.</div>}
      <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4"><Metric label="כמות סופית" value={summary.final_units || 0} tone={completed ? "success" : undefined}/><Metric label="חויבו בסבב הראשון" value={summary.initially_charged_units || 0}/><Metric label="הושלמו בחלון" value={summary.recovered_units || 0} tone="warning"/><Metric label="נפלו ולא נכללו" value={summary.excluded_units || 0}/></div>
      {pie.length > 0 && <div className="mt-6 h-52"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={pie} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={2}>{pie.map((row, index) => <Cell key={row.name} fill={PIE_COLORS[index % PIE_COLORS.length]}/>)}</Pie><Tooltip formatter={(value, name) => [`${value} יחידות`, name]}/></PieChart></ResponsiveContainer></div>}
    </Card>

    <section className="grid gap-4 lg:grid-cols-2">
      <Card className="p-5">
        <div className="flex items-center gap-2"><WalletCards className="h-5 w-5 text-emerald-700"/><h2 className="font-semibold">כספים</h2></div>
        {completed ? <><div className="mt-4 grid gap-3 sm:grid-cols-3"><MoneyMetric label="ברוטו שנגבה" value={summary.gross_collected}/><MoneyMetric label="עמלת סיטון" value={summary.platform_fee_total}/><MoneyMetric label="נטו למוכר" value={summary.seller_net_payable}/></div><p className="mt-4 text-sm text-slate-600">הסכומים מבוססים על Money Ledger סופי. עמלת סיטון היא 8% על הגבייה כולל משלוח, בתוספת מע״מ על עמלת סיטון. אין עמלת מפיצים.</p><p className="mt-2 text-sm text-slate-600">העברה למוכר תלויה בספק הסליקה. כרגע ספק העברה חיצוני עדיין אינו מחובר, ולכן לא מוצג תאריך משוער.</p><Button asChild variant="outline" className="mt-4"><Link to="/seller/payouts">פרטי תשלומים</Link></Button></> : <><div className="mt-4 grid gap-3 sm:grid-cols-2"><MoneyMetric label="נגבה בפועל" value={summary.gross_collected}/><MoneyMetric label="החזרים שנרשמו" value={summary.refunds_total}/></div><p className="mt-4 text-sm text-slate-600">בעסקה שלא הושלמה אין זכאות לאספקה. אם נרשמו חיובים בפועל, ההחזר מטופל במסלול המערכתי בלבד ולא ידנית על ידי המוכר.</p></>}
      </Card>

      <Card className="p-5">
        <div className="flex items-center gap-2"><FileText className="h-5 w-5 text-indigo-700"/><h2 className="font-semibold">מסמכים וקבלות</h2></div>
        <p className="mt-3 text-sm text-slate-600">מסמכים מותרים רק לקונים שחויבו סופית. אין יצירת מסמך עבור קונה שלא חויב.</p>
        <div className="mt-4 rounded-xl border bg-slate-50 p-4 text-sm"><div className="font-medium">סטטוס ספק מסמכים</div><div className="mt-1 text-slate-600">הנפקה חיצונית עדיין חסומה עד חיבור ספק חשבוניות ומקור פיננסי מוסמך.</div></div>
        <Button asChild variant="outline" className="mt-4"><Link to={`/seller/deal/${encodeURIComponent(deal.deal_id)}/receipts`}>פתח מסמכים</Link></Button>
      </Card>
    </section>

    {completed && <Card className="p-5"><div className="flex items-center gap-2"><PackageCheck className="h-5 w-5 text-slate-700"/><h2 className="font-semibold">קונים ואספקה</h2></div><p className="mt-3 text-sm text-slate-600">רק קונים מחויבים סופית נכנסים למסלול האספקה. פרטי משלוח, סטטוס ומעקב נמצאים במסך המסירות.</p><Button asChild className="mt-4"><Link to={`/seller/deal/${encodeURIComponent(deal.deal_id)}/fulfillment`}>פתח מסירות ורשימת משלוחים</Link></Button>{["voucher","ticket"].includes(deal.deal_type) && <Button asChild variant="outline" className="mt-4 mr-2"><Link to={`/seller/deal/${encodeURIComponent(deal.deal_id)}/digital-fulfillment`}>{deal.deal_type === "voucher" ? "פתח שוברים" : "פתח כרטיסים"}</Link></Button>}</Card>}

    <section className="grid gap-4 md:grid-cols-2"><AttributionCard title="שיטות מסירה" data={aggregates.delivery_method_quantity}/><AttributionCard title="נתוני לינקים של מפיצים" data={aggregates.distribution_source_quantity} note="הנתונים הם ייחוס ומדידה בלבד. אין עמלת מפיצים ואין התחשבנות כספית במערכת."/></section>

    <Card className="p-5">
      <div className="flex items-start gap-3"><AlertTriangle className="mt-0.5 h-5 w-5 text-slate-500"/><div><h2 className="font-semibold">פעולות ניהול</h2><p className="mt-1 text-sm text-slate-600">אין במסך הזה Refund, Capture או Void ידניים. פעולות כסף נשארות במסלולים המערכתיים בלבד.</p></div></div>
      <Button onClick={cloneDeal} className="mt-4 gap-2"><PlusCircle className="h-4 w-4"/>צור עסקה דומה</Button>
    </Card>
  </>;
}

function Metric({ label, value, tone = "", small = false }) {
  const cls = tone === "success" ? "text-emerald-700" : tone === "warning" ? "text-orange-700" : "text-slate-900";
  return <div><div className="text-xs text-slate-500">{label}</div><div className={`${small ? "mt-1 text-base" : "mt-1 text-xl"} font-semibold ${cls}`}>{value ?? 0}</div></div>;
}
function MoneyMetric({ label, value }) {
  return <div><div className="text-xs text-slate-500">{label}</div><div className="mt-1 text-xl font-semibold">{money(value)}</div></div>;
}
function AttributionCard({ title, data, note = "" }) {
  const rows = entries(data);
  return <Card className="p-5"><h3 className="font-semibold">{title}</h3><div className="mt-4 space-y-2">{rows.length ? rows.map(([key, value]) => <div key={key} className="flex justify-between rounded-lg bg-slate-50 px-3 py-2 text-sm"><span>{key}</span><span className="font-semibold">{value}</span></div>) : <div className="text-sm text-slate-500">אין נתונים</div>}</div>{note && <div className="mt-3 text-xs text-slate-500">{note}</div>}</Card>;
}
