import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, LifeBuoy, Search, ShieldCheck, Store, UserRound } from "lucide-react";

function fmt(v){if(!v)return"—";const d=new Date(v);return Number.isNaN(d.getTime())?"—":d.toLocaleString("he-IL");}

export default function AdminSearch(){
 const {kind,ref}=useParams();
 return kind&&ref?<UserProfile kind={kind} refValue={decodeURIComponent(ref)}/>:<Omnisearch/>;
}

function Omnisearch(){
 const [q,setQ]=useState("");const [data,setData]=useState(null);const [busy,setBusy]=useState(false);const [error,setError]=useState("");
 const submit=async(e)=>{e?.preventDefault();if(q.trim().length<2)return;setBusy(true);setError("");try{const r=await base44.functions.invoke("admin-omnisearch",{operation:"search",query:q});setData(r?.data||r);}catch(e2){setError(e2?.response?.data?.error||e2?.message||"החיפוש נכשל");}finally{setBusy(false);}};
 return <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
  <header className="border-b bg-white"><div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-5 sm:px-6"><div><div className="flex items-center gap-2 text-sm font-medium text-indigo-700"><Search className="h-4 w-4"/>Omnisearch</div><h1 className="mt-1 text-2xl font-bold">חיפוש מערכת</h1><p className="mt-1 text-sm text-slate-500">טלפון, אימייל, Deal ID, Participant ID, Seller ID או Correlation ID.</p></div><Button asChild variant="outline"><Link to="/admin" className="gap-2"><ArrowRight className="h-4 w-4"/>Mission Control</Link></Button></div></header>
  <main className="mx-auto max-w-6xl space-y-5 px-4 py-6 sm:px-6">
   <form onSubmit={submit} className="flex gap-2"><Input value={q} onChange={e=>setQ(e.target.value)} placeholder="חפש בכל המערכת..." autoFocus/><Button disabled={busy||q.trim().length<2}>{busy?"מחפש...":"חיפוש"}</Button></form>
   {error&&<div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
   {data&&<div className="grid gap-4 lg:grid-cols-3">
    <ResultCard title="עסקאות" icon={Store} empty="לא נמצאו עסקאות">{(data.deals||[]).map(row=><div key={row.deal_id} className="rounded-lg border bg-white p-3"><div className="font-medium">{row.title}</div><div className="mt-1 text-xs text-slate-500">{row.seller_display_name||""} · {row.state}</div><Button asChild size="sm" variant="outline" className="mt-3"><Link to={`/admin/deals/${encodeURIComponent(row.deal_id)}`}>פתח Deal Profile</Link></Button></div>)}</ResultCard>
    <ResultCard title="משתמשים" icon={UserRound} empty="לא נמצאו משתמשים">{(data.users||[]).map(row=><div key={`${row.kind}:${row.ref}`} className="rounded-lg border bg-white p-3"><div className="font-medium">{row.display_name}</div><div className="mt-1 text-xs text-slate-500">{row.kind==="seller"?"מוכר":"קונה"} · {row.status}</div>{(row.phone||row.email)&&<div className="mt-1 text-xs text-slate-500">{row.phone||row.email}</div>}<Button asChild size="sm" variant="outline" className="mt-3"><Link to={`/admin/user/${row.kind}/${encodeURIComponent(row.ref)}`}>User Profile</Link></Button></div>)}</ResultCard>
    <ResultCard title="פניות" icon={LifeBuoy} empty="לא נמצאו פניות">{(data.cases||[]).map(row=><div key={row.case_id} className="rounded-lg border bg-white p-3"><div className="font-medium">{row.subject}</div><div className="mt-1 text-xs text-slate-500">{row.priority} · {row.status} · {fmt(row.opened_at)}</div><Button asChild size="sm" variant="outline" className="mt-3"><Link to="/admin/support">מרכז תמיכה</Link></Button></div>)}</ResultCard>
   </div>}
  </main>
 </div>;
}

function ResultCard({title,icon:Icon,empty,children}){return <Card className="p-5"><div className="flex items-center gap-2"><Icon className="h-5 w-5 text-slate-500"/><h2 className="font-semibold">{title}</h2></div><div className="mt-4 space-y-2">{children?.length?children:<div className="text-sm text-slate-500">{empty}</div>}</div></Card>;}

function UserProfile({kind,refValue}){
 const [data,setData]=useState(null);const [loading,setLoading]=useState(true);const [error,setError]=useState("");
 const load=async()=>{setLoading(true);setError("");try{const r=await base44.functions.invoke("admin-omnisearch",{operation:"user_detail",kind,ref:refValue});setData(r?.data||r);}catch(e){setError(e?.response?.data?.error||e?.message||"לא ניתן לטעון משתמש");}finally{setLoading(false);}};
 useEffect(()=>{load();},[kind,refValue]);const p=data?.profile,s=data?.stats||{};
 return <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
  <header className="border-b bg-white"><div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between"><div><div className="flex items-center gap-2 text-sm font-medium text-indigo-700"><UserRound className="h-4 w-4"/>User Profile</div><h1 className="mt-1 text-2xl font-bold">{p?.display_name||"משתמש"}</h1>{p&&<div className="mt-1 text-sm text-slate-500">{p.kind==="seller"?"מוכר":"קונה"} · {p.status}</div>}</div><div className="flex gap-2"><Button asChild variant="outline"><Link to="/admin/search">חיפוש</Link></Button><Button asChild variant="outline"><Link to="/admin/forensics">Audit & Forensics</Link></Button></div></div></header>
  <main className="mx-auto max-w-6xl space-y-5 px-4 py-6 sm:px-6">
   {error&&<div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}{loading&&!data?<div className="p-12 text-center text-slate-500">טוען...</div>:p&&<>
    <Card className="p-5"><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4"><Field label="סוג" value={p.kind==="seller"?"מוכר":"קונה"}/><Field label="טלפון" value={p.phone||"—"}/><Field label="אימייל" value={p.email||"—"}/><Field label="סטטוס" value={p.status||"—"}/></div>{p.verification_status&&<div className="mt-4"><Badge variant="outline">KYC: {p.verification_status}</Badge></div>}</Card>
    <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><Metric label="עסקאות" value={s.deals}/>{kind==="buyer"&&<Metric label="רשומות השתתפות" value={s.participation_records}/>} {kind==="buyer"&&<Metric label="יחידות" value={s.units}/>}<Card className="p-4"><div className="text-xs text-slate-500">כסף</div><div className="mt-2 text-sm font-medium text-amber-800">לא מוצג עד Snapshot פיננסי מוכח</div></Card></section>
    {kind==="buyer"&&<div className="grid gap-4 lg:grid-cols-2"><StateCard title="Buyer States" values={s.buyer_state_units}/><StateCard title="Money States" values={s.money_state_units}/></div>}
    <Card className="overflow-hidden"><div className="border-b px-5 py-4"><h2 className="font-semibold">עסקאות</h2></div><div className="divide-y">{(data.deals||[]).length?(data.deals||[]).map(d=><div key={d.deal_id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-4"><div><div className="font-medium">{d.title}</div><div className="mt-1 text-xs text-slate-500">{d.state} · {fmt(d.updated_at)}</div></div><Button asChild size="sm" variant="outline"><Link to={`/admin/deals/${encodeURIComponent(d.deal_id)}`}>Deal Profile</Link></Button></div>):<div className="p-8 text-center text-sm text-slate-500">אין עסקאות</div>}</div></Card>
    <Card className="p-5"><h2 className="font-semibold">פניות תמיכה קשורות</h2><div className="mt-4 space-y-2">{(data.support||[]).length?(data.support||[]).map(c=><div key={c.case_id} className="rounded-lg border p-3 text-sm"><div className="font-medium">{c.subject}</div><div className="mt-1 text-xs text-slate-500">{c.priority} · {c.status}</div></div>):<div className="text-sm text-slate-500">אין פניות</div>}</div></Card>
    <Card className="border-amber-200 bg-amber-50 p-4 text-sm text-amber-900"><div className="flex gap-3"><ShieldCheck className="mt-0.5 h-5 w-5"/><div>{kind==="seller"?"ניהול סטטוס מוכר נשאר במסך KYC/מוכרים, ו־Freeze נעשה ב־Control Plane. אין פעולה כספית בפרופיל.":"אין כרגע מודל קנוני ל־Suspend/Ban של זהות קונה שאינה חשבון. לכן לא הומצא כפתור שלא ניתן לאכוף."}</div></div></Card>
   </>}
  </main>
 </div>;
}
function Field({label,value}){return <div><div className="text-xs text-slate-500">{label}</div><div className="mt-1 font-medium break-words">{value}</div></div>;}
function Metric({label,value}){return <Card className="p-4"><div className="text-xs text-slate-500">{label}</div><div className="mt-1 text-2xl font-bold">{value??0}</div></Card>;}
function StateCard({title,values={}}){return <Card className="p-5"><h2 className="font-semibold">{title}</h2><div className="mt-4 flex flex-wrap gap-2">{Object.entries(values||{}).length?Object.entries(values).map(([k,v])=><Badge key={k} variant="secondary">{k}: {v}</Badge>):<span className="text-sm text-slate-500">אין נתונים</span>}</div></Card>;}
