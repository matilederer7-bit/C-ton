import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Download, Gift, RefreshCw, ShieldAlert, Ticket } from "lucide-react";

function esc(value) {
  const text = String(value ?? "");
  return `"${text.replace(/"/g, '""')}"`;
}

export default function SellerDigitalFulfillment() {
  const { dealId } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");

  const invoke = async (payload) => {
    const response = await base44.functions.invoke("seller-digital-fulfillment", payload);
    return response?.data || response;
  };
  const load = async () => {
    setLoading(true); setError("");
    try { setData(await invoke({ operation:"list", deal_id:dealId })); }
    catch (e) { setError(e?.response?.data?.error || e?.message || "לא ניתן לטעון יחידות Fulfillment"); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [dealId]);

  const redeem = async (unit) => {
    setBusy(unit.fulfillment_unit_id); setError("");
    try { await invoke({ operation:"redeem", deal_id:dealId, fulfillment_unit_id:unit.fulfillment_unit_id }); await load(); }
    catch (e) { setError(e?.response?.data?.error || e?.message || "Redeem נכשל"); }
    finally { setBusy(""); }
  };

  const exportCsv = async () => {
    setError("");
    try {
      const result = await invoke({ operation:"export", deal_id:dealId });
      const rows = result?.export_rows || [];
      if (!rows.length) return setError("אין יחידות לייצוא כרגע");
      const headers = Object.keys(rows[0]);
      const csv = [headers.join(","), ...rows.map((row) => headers.map((key) => esc(row[key])).join(","))].join("\n");
      const blob = new Blob(["\ufeff", csv], { type:"text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `siton-${data?.deal?.deal_type || "digital"}-${dealId}.csv`; a.click(); URL.revokeObjectURL(url);
    } catch (e) { setError(e?.response?.data?.error || e?.message || "הייצוא נכשל"); }
  };

  const deal = data?.deal;
  const readiness = data?.readiness || {};
  const units = data?.units || [];
  const isVoucher = deal?.deal_type === "voucher";
  return <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
    <header className="border-b bg-white"><div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between"><div><div className="flex items-center gap-2 text-sm font-medium text-indigo-700">{isVoucher ? <Gift className="h-4 w-4"/> : <Ticket className="h-4 w-4"/>}Digital Fulfillment</div><h1 className="mt-1 text-2xl font-bold">{isVoucher ? "שוברים" : "כרטיסים"} · {deal?.title || "עסקה"}</h1><p className="mt-1 text-sm text-slate-500">נשמרים רק hash ו־4 התווים האחרונים. הקוד המלא אינו נשמר במערכת.</p></div><div className="flex gap-2"><Button asChild variant="outline"><Link to={`/seller/deal/${dealId}`} className="gap-2"><ArrowRight className="h-4 w-4"/>פרטי עסקה</Link></Button><Button variant="outline" onClick={load} disabled={loading} className="gap-2"><RefreshCw className={`h-4 w-4 ${loading?"animate-spin":""}`}/>רענון</Button><Button onClick={exportCsv} className="gap-2"><Download className="h-4 w-4"/>CSV</Button></div></div></header>
    <main className="mx-auto max-w-6xl space-y-6 px-4 py-6 sm:px-6">
      {error && <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5"><Card className="p-4"><div className="text-xs text-slate-500">זכאים</div><div className="mt-1 text-2xl font-bold">{readiness.eligible_participants || 0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">יחידות צפויות</div><div className="mt-1 text-2xl font-bold">{readiness.expected_units || 0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">יחידות קיימות</div><div className="mt-1 text-2xl font-bold">{readiness.existing_units || 0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">חסרות</div><div className="mt-1 text-2xl font-bold">{readiness.missing_units || 0}</div></Card><Card className="p-4"><div className="text-xs text-slate-500">Redeemed</div><div className="mt-1 text-2xl font-bold">{readiness.redeemed || 0}</div></Card></div>
      {!readiness.issuance_enabled && <Card className="border-amber-200 bg-amber-50 p-4"><div className="flex gap-3"><ShieldAlert className="mt-0.5 h-5 w-5 text-amber-700"/><div><div className="font-semibold">הנפקה אוטומטית חסומה</div><div className="mt-1 text-sm text-amber-800">{readiness.issuance_blocker || "מסירת קוד חד־פעמית עדיין לא הוכחה."}</div><div className="mt-1 text-xs text-amber-700">המערכת לא תיצור קוד מלא שאפשר לאבד במקרה של קריסה או אובדן Response.</div></div></div></Card>}
      {loading && !data ? <Card className="p-10 text-center text-slate-500">טוען...</Card> : units.length === 0 ? <Card className="p-10 text-center text-slate-500">אין יחידות שהונפקו. Eligibility כבר מחושב, אבל יצירת קוד נשארת חסומה.</Card> : <div className="space-y-3">{units.map((unit)=><Card key={unit.fulfillment_unit_id} className="p-5"><div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><div><div className="flex items-center gap-2"><span className="font-semibold">יחידה {unit.unit_index}</span><Badge variant="outline">{unit.status}</Badge></div><div className="mt-1 text-xs text-slate-500">Participant {unit.participant_id}</div></div><div className="flex items-center gap-5"><div className="text-left"><div className="text-xs text-slate-500">4 תווים אחרונים</div><div className="font-mono text-lg font-bold">{unit.code_display_last4 || "—"}</div></div>{["Issued","Sent"].includes(unit.status) && <Button onClick={()=>redeem(unit)} disabled={busy===unit.fulfillment_unit_id}>{busy===unit.fulfillment_unit_id?"מסמן...":"סמן כמומש"}</Button>}</div></div></Card>)}</div>}
    </main>
  </div>;
}
