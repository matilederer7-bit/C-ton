import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Copy, ExternalLink, Link2, Megaphone, Plus, RefreshCw } from "lucide-react";

const inputClass="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-400";
function fmt(v){if(!v)return"—";const d=new Date(v);return Number.isNaN(d.getTime())?"—":new Intl.DateTimeFormat("he-IL",{dateStyle:"short",timeStyle:"short"}).format(d);}

export default function DistributorPortal(){
 const [data,setData]=useState(null),[loading,setLoading]=useState(true),[error,setError]=useState(""),[busy,setBusy]=useState("");
 const [labels,setLabels]=useState({});
 const invoke=async(payload)=>{const r=await base44.functions.invoke("distributor-portal",payload);return r?.data||r;};
 const load=async()=>{setLoading(true);setError("");try{setData(await invoke({operation:"list"}));}catch(e){setError(e?.response?.data?.error||e?.message||"לא ניתן לטעון את אזור המפיץ");}finally{setLoading(false);}};
 useEffect(()=>{load();},[]);
 const totals=useMemo(()=>{const t={links:0,clicks:0,visits:0,joins:0,units:0};for(const access of data?.accesses||[])for(const source of access.sources||[]){t.links+=1;t.clicks+=Number(source.metrics?.clicks||0);t.visits+=Number(source.metrics?.visits||0);t.joins+=Number(source.metrics?.joins||0);t.units+=Number(source.metrics?.units||0);}return t;},[data]);
 const createLink=async(access)=>{setBusy(access.access_id);setError("");try{await invoke({operation:"create_link",access_id:access.access_id,label:labels[access.access_id]||""});setLabels(v=>({...v,[access.access_id]:""}));await load();}catch(e){setError(e?.response?.data?.error||e?.message||"יצירת קישור נכשלה");}finally{setBusy("");}};
 const linkFor=(dealId,code)=>`${window.location.origin}/deal/${encodeURIComponent(dealId)}?ref=${encodeURIComponent(code)}`;
 const copy=async(url)=>{try{await navigator.clipboard.writeText(url);setError("");}catch{setError(url);}};
 return <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
  <header className="border-b bg-white"><div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between"><div><div className="flex items-center gap-2 text-sm font-medium text-indigo-700"><Megaphone className="h-4 w-4"/>Distributor Portal</div><h1 className="mt-1 text-2xl font-bold">אזור מפיצים</h1><p className="mt-1 text-sm text-slate-500">עסקאות שהוקצו לך וקישורי הפצה ייחודיים. הייחוס הוא למדידה בלבד ואין עמלת מפיץ או יתרה לתשלום.</p></div><Button variant="outline" onClick={load} disabled={loading} className="gap-2"><RefreshCw className={`h-4 w-4 ${loading?"animate-spin":""}`}/>רענון</Button></div></header>
  <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6">
   {error&&<div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 break-all">{error}</div>}
   <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5"><Metric label="קישורים" value={totals.links}/><Metric label="קליקים" value={totals.clicks}/><Metric label="כניסות" value={totals.visits}/><Metric label="הצטרפויות" value={totals.joins}/><Metric label="יחידות" value={totals.units}/></div>
   {loading&&!data?<Card className="p-10 text-center text-slate-500">טוען...</Card>:!(data?.accesses||[]).length?<Card className="p-10 text-center"><div className="font-semibold">אין כרגע עסקאות שהוקצו לך</div><div className="mt-2 text-sm text-slate-500">Admin צריך לאשר לך עסקה לפני שניתן לייצר קישור הפצה.</div></Card>:<div className="space-y-4">{(data.accesses||[]).map(access=><Card key={access.access_id} className="p-5"><div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between"><div><div className="flex flex-wrap items-center gap-2"><h2 className="font-semibold">{access.deal?.title||"עסקה"}</h2><Badge variant="outline">{access.deal?.state||"לא זמינה"}</Badge><Badge variant={access.status==="active"?"secondary":"outline"}>{access.status==="active"?"מורשה":"הרשאה בוטלה"}</Badge></div><div className="mt-2 text-xs text-slate-500">Deal {access.deal?.deal_id} · דדליין {fmt(access.deal?.deadline)}</div><div className="mt-2 text-sm text-slate-600">התקדמות: {access.deal?.reserved_units||0} מתוך יעד {access.deal?.threshold_units||0}. מלאי מרבי {access.deal?.max_units||0}.</div></div>{access.deal?.public&&<Button asChild variant="outline"><Link target="_blank" to={`/deal/${access.deal.deal_id}`} className="gap-2"><ExternalLink className="h-4 w-4"/>פתח עסקה</Link></Button>}</div>
     {access.status==="active"&&access.deal?.public&&<div className="mt-5 rounded-xl border bg-slate-50 p-4"><div className="flex items-center gap-2"><Plus className="h-4 w-4"/><div className="font-medium">קישור חדש</div></div><div className="mt-3 flex flex-col gap-2 sm:flex-row"><input className={inputClass} placeholder="שם פנימי לקישור, למשל קבוצת ווטסאפ א'" value={labels[access.access_id]||""} onChange={e=>setLabels({...labels,[access.access_id]:e.target.value})}/><Button onClick={()=>createLink(access)} disabled={busy===access.access_id} className="shrink-0">צור קישור</Button></div></div>}
     <div className="mt-4 space-y-2">{(access.sources||[]).map(source=>{const url=linkFor(access.deal.deal_id,source.source_code);return <div key={source.source_id} className="rounded-xl border bg-white p-4"><div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between"><div><div className="flex items-center gap-2"><Link2 className="h-4 w-4"/><span className="font-medium">{source.display_name}</span><Badge variant={source.active?"secondary":"outline"}>{source.active?"פעיל":"כבוי"}</Badge></div><div className="mt-1 text-xs text-slate-400">{source.source_code}</div><div className="mt-2 flex flex-wrap gap-3 text-sm text-slate-600"><span>{source.metrics?.clicks||0} קליקים</span><span>{source.metrics?.visits||0} כניסות</span><span>{source.metrics?.joins||0} הצטרפויות</span><span>{source.metrics?.units||0} יחידות</span></div></div><Button variant="outline" className="gap-2" onClick={()=>copy(url)} disabled={!source.active}><Copy className="h-4 w-4"/>העתק קישור</Button></div></div>})}</div>
    </Card>)}</div>}
   <Card className="border-indigo-100 bg-indigo-50 p-4 text-sm text-indigo-900"><strong>כלל כספי:</strong> קישורי מפיץ משמשים לייחוס ומדידה בלבד. עמלת המפיץ היא אפס. אין יתרה, payout או settlement שנוצרים מההפצה.</Card>
  </main>
 </div>;
}
function Metric({label,value}){return <Card className="p-4"><div className="text-xs text-slate-500">{label}</div><div className="mt-1 text-2xl font-bold">{value||0}</div></Card>}
