import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRight, Save, ShieldCheck } from "lucide-react";

export default function SellerProfile() {
  const [seller, setSeller] = useState(null);
  const [form, setForm] = useState({ display_name: "", business_name: "", support_phone: "", support_email: "" });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await base44.functions.invoke("get-seller-profile", {});
      const result = response?.data || response;
      const current = result?.seller || null;
      setSeller(current);
      if (current) {
        setForm({
          display_name: current.display_name || "",
          business_name: current.business_name || "",
          support_phone: current.support_phone || "",
          support_email: current.support_email || "",
        });
      }
    } catch (e) {
      setError(e?.message || "לא ניתן לטעון את פרופיל המוכר");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const setField = (name, value) => setForm((prev) => ({ ...prev, [name]: value }));

  const submit = async (event) => {
    event.preventDefault();
    setSaving(true);
    setError("");
    setSuccess("");
    try {
      const response = await base44.functions.invoke("update-seller-profile", form);
      const result = response?.data || response;
      setSuccess("פרטי המוכר נשמרו בהצלחה");
      setSeller((prev) => ({ ...(prev || {}), ...(result.seller || {}) }));
    } catch (e) {
      const body = e?.response?.data;
      setError(body?.error || e?.message || "שמירת פרטי המוכר נכשלה");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b bg-white">
        <div className="mx-auto flex max-w-3xl items-center justify-between gap-4 px-4 py-5 sm:px-6">
          <div>
            <div className="flex items-center gap-2 text-sm font-medium text-emerald-700"><ShieldCheck className="h-4 w-4" /> אזור מוכר</div>
            <h1 className="mt-1 text-2xl font-bold">פרטי המוכר</h1>
          </div>
          <Button asChild variant="outline"><Link to="/" className="gap-2"><ArrowRight className="h-4 w-4" />חזרה</Link></Button>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-6 sm:px-6">
        <Card className="p-5 sm:p-6">
          {loading ? (
            <div className="py-10 text-center text-sm text-slate-500">טוען...</div>
          ) : !seller ? (
            <div className="space-y-3 py-6 text-center">
              <div className="font-medium">עדיין אין חשבון מוכר</div>
              <p className="text-sm text-slate-500">חשבון המוכר נוצר עם יצירת טיוטת העסקה הראשונה.</p>
              <Button asChild><Link to="/">יצירת עסקה ראשונה</Link></Button>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-5">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2"><Label htmlFor="display-name">שם תצוגה</Label><Input id="display-name" value={form.display_name} onChange={(e) => setField("display_name", e.target.value)} maxLength={160} required /></div>
                <div className="space-y-2"><Label htmlFor="business-name">שם העסק</Label><Input id="business-name" value={form.business_name} onChange={(e) => setField("business_name", e.target.value)} maxLength={200} required /></div>
                <div className="space-y-2"><Label htmlFor="support-phone">טלפון שירות</Label><Input id="support-phone" value={form.support_phone} onChange={(e) => setField("support_phone", e.target.value)} maxLength={40} /></div>
                <div className="space-y-2"><Label htmlFor="support-email">מייל שירות</Label><Input id="support-email" type="email" value={form.support_email} onChange={(e) => setField("support_email", e.target.value)} maxLength={254} /></div>
              </div>

              <div className="grid gap-3 rounded-xl border bg-slate-50 p-4 sm:grid-cols-3">
                <div><div className="text-xs text-slate-500">מזהה מוכר</div><div className="mt-1 break-all text-sm font-medium">{seller.seller_id}</div></div>
                <div><div className="text-xs text-slate-500">סטטוס</div><div className="mt-1 text-sm font-medium">{seller.seller_status}</div></div>
                <div><div className="text-xs text-slate-500">אימות</div><div className="mt-1 text-sm font-medium">{seller.verification_status}</div></div>
              </div>
              <p className="text-xs leading-5 text-slate-500">מזהה המוכר, סטטוס המוכר וסטטוס האימות מוצגים לקריאה בלבד. אין אפשרות לשנות אותם דרך מסך זה או דרך SDK ישיר.</p>

              {error && <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}
              {success && <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-700">{success}</div>}

              <Button type="submit" disabled={saving} className="gap-2"><Save className="h-4 w-4" />{saving ? "שומר..." : "שמור פרטים"}</Button>
            </form>
          )}
        </Card>
      </main>
    </div>
  );
}