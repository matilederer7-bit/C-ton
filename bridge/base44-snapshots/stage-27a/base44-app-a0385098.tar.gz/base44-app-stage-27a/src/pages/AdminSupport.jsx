import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, RefreshCw, ShieldAlert, LifeBuoy, Plus } from "lucide-react";

const STATUSES = ["Open","NeedsSeller","NeedsAdmin","WaitingExternal","Resolved","Closed"];
const PRIORITIES = ["Low","Normal","High","Urgent"];
const TYPES = ["RefundRequest","DeliveryIssue","SellerRisk","BuyerComplaint","PaymentMismatch","InvoiceIssue","ContentReport","SystemException","Other"];

const STATUS_LABEL = { Open:"פתוח", NeedsSeller:"ממתין למוכר", NeedsAdmin:"דורש אדמין", WaitingExternal:"ממתין לחיצוני", Resolved:"נפתר", Closed:"סגור" };
const PRIORITY_LABEL = { Low:"נמוכה", Normal:"רגילה", High:"גבוהה", Urgent:"דחופה" };

function fmt(value) {
  if (!value) return "—";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? "—" : new Intl.DateTimeFormat("he-IL", { dateStyle:"short", timeStyle:"short" }).format(d);
}

function Field({ label, children }) {
  return <label className="block"><div className="mb-1 text-xs font-medium text-slate-600">{label}</div>{children}</label>;
}

const inputClass = "w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-slate-400";

export default function AdminSupport() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filters, setFilters] = useState({ status:"", priority:"", case_type:"" });
  const [create, setCreate] = useState({ subject:"", case_type:"BuyerComplaint", priority:"Normal", reason:"", deal_id:"", seller_id:"" });
  const [drafts, setDrafts] = useState({});
  const [busy, setBusy] = useState("");

  const invoke = async (payload) => {
    const response = await base44.functions.invoke("admin-support-cases", payload);
    return response?.data || response;
  };

  const load = async () => {
    setLoading(true); setError("");
    try {
      setData(await invoke({ operation:"list", ...filters, limit:300 }));
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "לא ניתן לטעון את מרכז התמיכה");
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const readiness = data?.support_readiness || {};
  const cases = data?.cases || [];
  const verdictLabel = readiness.verdict === "blocked" ? "חסום" : readiness.verdict === "warning" ? "אזהרה" : "תקין";

  const updateDraft = (caseId, patch) => setDrafts((current) => ({ ...current, [caseId]: { ...(current[caseId] || {}), ...patch } }));
  const draftFor = (row) => ({
    status: drafts[row.case_id]?.status ?? row.status,
    priority: drafts[row.case_id]?.priority ?? row.priority,
    assignee: drafts[row.case_id]?.assignee ?? row.assignee ?? "",
    note: drafts[row.case_id]?.note ?? "",
    reason: drafts[row.case_id]?.reason ?? "",
    resolution_note: drafts[row.case_id]?.resolution_note ?? row.resolution_note ?? ""
  });

  const createCase = async () => {
    if (!create.subject.trim() || !create.reason.trim()) return setError("נדרשים נושא וסיבה לפתיחת Case");
    setBusy("create"); setError("");
    try {
      await invoke({ operation:"create", ...create });
      setCreate({ subject:"", case_type:"BuyerComplaint", priority:"Normal", reason:"", deal_id:"", seller_id:"" });
      await load();
    } catch (e) { setError(e?.response?.data?.error || e?.message || "פתיחת Case נכשלה"); }
    finally { setBusy(""); }
  };

  const saveCase = async (row) => {
    const draft = draftFor(row);
    if (!draft.reason.trim()) return setError("Reason הוא חובה בכל שינוי Case");
    setBusy(row.case_id); setError("");
    try {
      await invoke({ operation:"update", case_id:row.case_id, ...draft });
      setDrafts((current) => { const next = { ...current }; delete next[row.case_id]; return next; });
      await load();
    } catch (e) { setError(e?.response?.data?.error || e?.message || "עדכון Case נכשל"); }
    finally { setBusy(""); }
  };

  const escalate = async (row) => {
    const reason = draftFor(row).reason.trim();
    if (!reason) return setError("Reason הוא חובה להסלמה");
    setBusy(row.case_id); setError("");
    try { await invoke({ operation:"escalate", case_id:row.case_id, reason, note:draftFor(row).note }); await load(); }
    catch (e) { setError(e?.response?.data?.error || e?.message || "הסלמה נכשלה"); }
    finally { setBusy(""); }
  };

  const overdueByPriority = useMemo(() => readiness.sla || {}, [readiness.sla]);

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b bg-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-5 sm:px-6 md:flex-row md:items-center md:justify-between">
          <div><div className="flex items-center gap-2 text-sm font-medium text-indigo-700"><LifeBuoy className="h-4 w-4"/>Support Operations</div><h1 className="mt-1 text-2xl font-bold">מרכז תמיכה ותפעול</h1><p className="mt-1 text-sm text-slate-500">תיעוד, SLA והסלמה בלבד. התמיכה אינה יכולה לאשר או לבצע Refund או לשנות Money State.</p></div>
          <div className="flex gap-2"><Button asChild variant="outline"><Link to="/admin" className="gap-2"><ArrowRight className="h-4 w-4"/>Mission Control</Link></Button><Button variant="outline" onClick={load} disabled={loading} className="gap-2"><RefreshCw className={`h-4 w-4 ${loading ? "animate-spin":""}`}/>רענון</Button></div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6">
        {error && <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <Card className="p-4"><div className="text-xs text-slate-500">פתוחים</div><div className="mt-1 text-2xl font-bold">{readiness.open || 0}</div></Card>
          <Card className="p-4"><div className="text-xs text-slate-500">Urgent פתוחים</div><div className="mt-1 text-2xl font-bold">{readiness.urgent_open || 0}</div></Card>
          <Card className="p-4"><div className="text-xs text-slate-500">High פתוחים</div><div className="mt-1 text-2xl font-bold">{readiness.high_open || 0}</div></Card>
          <Card className="p-4"><div className="text-xs text-slate-500">חריגות SLA</div><div className="mt-1 text-2xl font-bold">{readiness.overdue_count || 0}</div><div className="mt-1 text-xs text-slate-500">U {overdueByPriority.Urgent || 0} · H {overdueByPriority.High || 0} · N {overdueByPriority.Normal || 0} · L {overdueByPriority.Low || 0}</div></Card>
          <Card className={`p-4 ${readiness.verdict === "blocked" ? "border-red-200 bg-red-50" : readiness.verdict === "warning" ? "border-amber-200 bg-amber-50" : "border-emerald-200 bg-emerald-50"}`}><div className="text-xs text-slate-500">Readiness</div><div className="mt-1 text-2xl font-bold">{verdictLabel}</div></Card>
        </div>

        <Card className="p-5">
          <div className="mb-4 flex items-center gap-2"><Plus className="h-4 w-4"/><h2 className="font-semibold">פתיחת Case</h2></div>
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            <Field label="נושא"><input className={inputClass} value={create.subject} onChange={(e)=>setCreate({...create,subject:e.target.value})}/></Field>
            <Field label="סוג"><select className={inputClass} value={create.case_type} onChange={(e)=>setCreate({...create,case_type:e.target.value})}>{TYPES.map(v=><option key={v}>{v}</option>)}</select></Field>
            <Field label="עדיפות"><select className={inputClass} value={create.priority} onChange={(e)=>setCreate({...create,priority:e.target.value})}>{PRIORITIES.map(v=><option key={v}>{PRIORITY_LABEL[v]}</option>)}</select></Field>
            <Field label="Deal ID אופציונלי"><input className={inputClass} value={create.deal_id} onChange={(e)=>setCreate({...create,deal_id:e.target.value})}/></Field>
            <Field label="Seller ID אופציונלי"><input className={inputClass} value={create.seller_id} onChange={(e)=>setCreate({...create,seller_id:e.target.value})}/></Field>
            <Field label="Reason"><input className={inputClass} value={create.reason} onChange={(e)=>setCreate({...create,reason:e.target.value})}/></Field>
          </div>
          <Button className="mt-4" onClick={createCase} disabled={busy === "create"}>{busy === "create" ? "פותח..." : "פתח Case"}</Button>
        </Card>

        <Card className="p-5">
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="סטטוס"><select className={inputClass} value={filters.status} onChange={(e)=>setFilters({...filters,status:e.target.value})}><option value="">הכול</option>{STATUSES.map(v=><option key={v} value={v}>{STATUS_LABEL[v]}</option>)}</select></Field>
            <Field label="עדיפות"><select className={inputClass} value={filters.priority} onChange={(e)=>setFilters({...filters,priority:e.target.value})}><option value="">הכול</option>{PRIORITIES.map(v=><option key={v} value={v}>{PRIORITY_LABEL[v]}</option>)}</select></Field>
            <Field label="סוג"><select className={inputClass} value={filters.case_type} onChange={(e)=>setFilters({...filters,case_type:e.target.value})}><option value="">הכול</option>{TYPES.map(v=><option key={v}>{v}</option>)}</select></Field>
          </div><Button variant="outline" className="mt-3" onClick={load}>החל סינון</Button>
        </Card>

        <div className="space-y-4">
          {loading && !data ? <Card className="p-10 text-center text-slate-500">טוען Cases...</Card> : cases.length === 0 ? <Card className="p-10 text-center text-slate-500">אין Cases להצגה.</Card> : cases.map((row) => {
            const draft = draftFor(row);
            const closed = row.status === "Resolved" || row.status === "Closed";
            return <Card key={row.case_id} className={`overflow-hidden ${row.sla_overdue ? "border-red-200" : ""}`}>
              <div className="border-b px-5 py-4"><div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between"><div><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold">{row.subject}</h3><Badge variant="outline">{row.case_type}</Badge><Badge variant={row.priority === "Urgent" ? "destructive" : "secondary"}>{PRIORITY_LABEL[row.priority] || row.priority}</Badge><Badge variant="outline">{STATUS_LABEL[row.status] || row.status}</Badge>{row.sla_overdue && <Badge variant="destructive">SLA חורג</Badge>}</div><div className="mt-1 text-xs text-slate-500">{row.case_id} · נפתח {fmt(row.opened_at)} · SLA {fmt(row.sla_due_at)}</div></div>{row.sla_overdue && <ShieldAlert className="h-5 w-5 text-red-600"/>}</div></div>
              <div className="grid gap-4 p-5 lg:grid-cols-[1fr_1fr]">
                <div className="space-y-3 text-sm"><div><span className="text-slate-500">Reason נוכחי:</span> {row.reason}</div>{row.deal_id && <div><span className="text-slate-500">Deal:</span> {row.deal_id}</div>}{row.participant_id && <div><span className="text-slate-500">Participant:</span> {row.participant_id}</div>}{row.seller_id && <div><span className="text-slate-500">Seller:</span> {row.seller_id}</div>}{row.assignee && <div><span className="text-slate-500">Assignee:</span> {row.assignee}</div>}{row.resolution_note && <div><span className="text-slate-500">Resolution:</span> {row.resolution_note}</div>}<div className="text-xs text-slate-400">Audit events: {Array.isArray(row.event_journal) ? row.event_journal.length : 0}</div></div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <Field label="סטטוס"><select disabled={closed} className={inputClass} value={draft.status} onChange={(e)=>updateDraft(row.case_id,{status:e.target.value})}>{STATUSES.map(v=><option key={v} value={v}>{STATUS_LABEL[v]}</option>)}</select></Field>
                  <Field label="עדיפות"><select disabled={closed} className={inputClass} value={draft.priority} onChange={(e)=>updateDraft(row.case_id,{priority:e.target.value})}>{PRIORITIES.map(v=><option key={v}>{PRIORITY_LABEL[v]}</option>)}</select></Field>
                  <Field label="Assignee"><input disabled={closed} className={inputClass} value={draft.assignee} onChange={(e)=>updateDraft(row.case_id,{assignee:e.target.value})}/></Field>
                  <Field label="Reason לשינוי"><input disabled={closed} className={inputClass} value={draft.reason} onChange={(e)=>updateDraft(row.case_id,{reason:e.target.value})}/></Field>
                  <Field label="Note"><textarea disabled={closed} className={`${inputClass} min-h-20`} value={draft.note} onChange={(e)=>updateDraft(row.case_id,{note:e.target.value})}/></Field>
                  <Field label="Resolution note"><textarea disabled={closed} className={`${inputClass} min-h-20`} value={draft.resolution_note} onChange={(e)=>updateDraft(row.case_id,{resolution_note:e.target.value})}/></Field>
                  {!closed && <div className="flex flex-wrap gap-2 sm:col-span-2"><Button onClick={()=>saveCase(row)} disabled={busy === row.case_id}>שמור שינוי</Button><Button variant="destructive" onClick={()=>escalate(row)} disabled={busy === row.case_id || row.priority === "Urgent"}>הסלם ל־Urgent</Button></div>}
                </div>
              </div>
            </Card>;
          })}
        </div>
      </main>
    </div>
  );
}
