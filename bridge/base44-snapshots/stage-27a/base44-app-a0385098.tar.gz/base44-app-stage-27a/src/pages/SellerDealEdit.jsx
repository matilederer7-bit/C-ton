import React, { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowRight, Save, ShieldCheck } from "lucide-react";

function toLocalInput(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  const offset = date.getTimezoneOffset() * 60_000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 16);
}

export default function SellerDealEdit() {
  const { dealId } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState(null);

  const threshold = useMemo(() => Math.ceil(0.9 * Math.max(1, Number(form?.min_units || 1))), [form?.min_units]);

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await base44.functions.invoke("seller-deal-detail", { deal_id: dealId });
      const result = response?.data || response;
      const deal = result?.deal;
      if (!deal) throw new Error("העסקה לא נמצאה");
      if (deal.state !== "Draft") throw new Error("ניתן לערוך עסקה רק כל עוד היא Draft");
      const delivery = Array.isArray(deal.delivery_options) ? deal.delivery_options[0] : null;
      setForm({
        title: deal.title || "",
        short_description: deal.short_description || "",
        what_you_get: deal.what_you_get || "",
        deal_type: deal.deal_type || "physical_product",
        price_per_unit: String(deal.price_per_unit ?? ""),
        min_units: String(deal.min_units ?? ""),
        max_units: String(deal.max_units ?? ""),
        deadline: toLocalInput(deal.deadline),
        delivery_option_id: delivery?.option_id || "",
        delivery_type: delivery?.option_type || "pickup",
        delivery_label: delivery?.label || "איסוף עצמי",
        delivery_cost: String(delivery?.cost ?? 0),
        voucher_face_value: String(deal.voucher_terms?.face_value_amount ?? ""),
        ticket_event_name: deal.ticket_terms?.event_name || "",
        ticket_event_starts_at: toLocalInput(deal.ticket_terms?.event_starts_at),
      });
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "לא ניתן לטעון את הטיוטה");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [dealId]);

  const setField = (name, value) => setForm((prev) => ({ ...prev, [name]: value }));

  const submit = async (event) => {
    event.preventDefault();
    if (!form) return;
    setSaving(true);
    setError("");
    try {
      const payload = {
        deal_id: dealId,
        title: form.title,
        short_description: form.short_description,
        what_you_get: form.what_you_get,
        deal_type: form.deal_type,
        price_per_unit: Number(form.price_per_unit),
        min_units: Number(form.min_units),
        max_units: Number(form.max_units),
        deadline: new Date(form.deadline).toISOString(),
      };
      if (form.deal_type === "physical_product") {
        payload.delivery_options = [{
          ...(form.delivery_option_id ? { option_id: form.delivery_option_id } : {}),
          option_type: form.delivery_type,
          label: form.delivery_label,
          cost: Number(form.delivery_cost || 0),
          sort_order: 0,
        }];
      }
      if (form.deal_type === "voucher") {
        payload.voucher_terms = {
          face_value_amount: Number(form.voucher_face_value),
          currency: "ILS",
          voucher_code_mode: "system_generated",
        };
      }
      if (form.deal_type === "ticket") {
        payload.ticket_terms = {
          event_name: form.ticket_event_name,
          event_starts_at: new Date(form.ticket_event_starts_at).toISOString(),
          seat_mode: "general_admission",
          ticket_type: "general_admission",
        };
      }
      await base44.functions.invoke("update-deal-draft", payload);
      navigate(`/seller/deal/${encodeURIComponent(dealId)}`);
    } catch (e) {
      setError(e?.response?.data?.error || e?.message || "שמירת הטיוטה נכשלה");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50 text-slate-900">
      <header className="border-b bg-white">
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-4 px-4 py-5 sm:px-6">
          <div>
            <div className="flex items-center gap-2 text-sm font-medium text-emerald-700"><ShieldCheck className="h-4 w-4" />אזור מוכר</div>
            <h1 className="mt-1 text-2xl font-bold">עריכת טיוטת עסקה</h1>
            <p className="mt-1 text-sm text-slate-500">העריכה מותרת רק ב־Draft. אחרי Publish התנאים הקריטיים נעולים.</p>
          </div>
          <Button asChild variant="outline"><Link to={`/seller/deal/${encodeURIComponent(dealId)}`} className="gap-2"><ArrowRight className="h-4 w-4" />חזרה</Link></Button>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-6 sm:px-6">
        {loading ? <Card className="p-10 text-center text-sm text-slate-500">טוען...</Card> : !form ? <Card className="p-10 text-center text-sm text-red-700">{error || "לא ניתן לערוך את העסקה"}</Card> : (
          <Card className="p-5 sm:p-6">
            <form onSubmit={submit} className="space-y-5">
              <div className="space-y-2"><Label htmlFor="edit-title">כותרת העסקה</Label><Input id="edit-title" value={form.title} onChange={(e) => setField("title", e.target.value)} maxLength={200} required /></div>
              <div className="space-y-2"><Label htmlFor="edit-description">תיאור קצר</Label><Textarea id="edit-description" value={form.short_description} onChange={(e) => setField("short_description", e.target.value)} maxLength={1200} /></div>
              <div className="space-y-2"><Label htmlFor="edit-what">מה מקבלים</Label><Textarea id="edit-what" value={form.what_you_get} onChange={(e) => setField("what_you_get", e.target.value)} maxLength={2000} /></div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2"><Label>סוג העסקה</Label><Select value={form.deal_type} onValueChange={(value) => setField("deal_type", value)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="physical_product">מוצר פיזי</SelectItem><SelectItem value="voucher">שובר</SelectItem><SelectItem value="ticket">כרטיס</SelectItem></SelectContent></Select></div>
                <div className="space-y-2"><Label htmlFor="edit-price">מחיר ליחידה</Label><Input id="edit-price" type="number" min="0.01" step="0.01" value={form.price_per_unit} onChange={(e) => setField("price_per_unit", e.target.value)} required /></div>
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <div className="space-y-2"><Label htmlFor="edit-min">יעד מינימום</Label><Input id="edit-min" type="number" min="1" step="1" value={form.min_units} onChange={(e) => setField("min_units", e.target.value)} required /></div>
                <div className="space-y-2"><Label htmlFor="edit-max">מלאי מקסימלי</Label><Input id="edit-max" type="number" min="1" step="1" value={form.max_units} onChange={(e) => setField("max_units", e.target.value)} required /></div>
                <div className="rounded-lg border bg-slate-50 p-3"><div className="text-xs text-slate-500">סף 90%</div><div className="mt-1 text-2xl font-bold">{threshold}</div></div>
              </div>

              <div className="space-y-2"><Label htmlFor="edit-deadline">דדליין</Label><Input id="edit-deadline" type="datetime-local" value={form.deadline} onChange={(e) => setField("deadline", e.target.value)} required /><p className="text-xs text-slate-500">חייב להיות בין שעתיים לשבעה ימים קדימה בזמן השמירה.</p></div>

              {form.deal_type === "physical_product" && <div className="grid gap-4 rounded-xl border bg-slate-50 p-4 sm:grid-cols-3">
                <div className="space-y-2"><Label>סוג מסירה</Label><Select value={form.delivery_type} onValueChange={(value) => setField("delivery_type", value)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="pickup">איסוף עצמי</SelectItem><SelectItem value="delivery">משלוח</SelectItem><SelectItem value="distribution_point">נקודת חלוקה</SelectItem></SelectContent></Select></div>
                <div className="space-y-2"><Label htmlFor="edit-delivery-label">תיאור מסירה</Label><Input id="edit-delivery-label" value={form.delivery_label} onChange={(e) => setField("delivery_label", e.target.value)} required /></div>
                <div className="space-y-2"><Label htmlFor="edit-delivery-cost">עלות מסירה</Label><Input id="edit-delivery-cost" type="number" min="0" step="0.01" value={form.delivery_cost} onChange={(e) => setField("delivery_cost", e.target.value)} /></div>
              </div>}

              {form.deal_type === "voucher" && <div className="space-y-2 rounded-xl border bg-slate-50 p-4"><Label htmlFor="edit-voucher">ערך נקוב</Label><Input id="edit-voucher" type="number" min="0.01" step="0.01" value={form.voucher_face_value} onChange={(e) => setField("voucher_face_value", e.target.value)} required /></div>}

              {form.deal_type === "ticket" && <div className="grid gap-4 rounded-xl border bg-slate-50 p-4 sm:grid-cols-2"><div className="space-y-2"><Label htmlFor="edit-event-name">שם האירוע</Label><Input id="edit-event-name" value={form.ticket_event_name} onChange={(e) => setField("ticket_event_name", e.target.value)} required /></div><div className="space-y-2"><Label htmlFor="edit-event-start">תחילת האירוע</Label><Input id="edit-event-start" type="datetime-local" value={form.ticket_event_starts_at} onChange={(e) => setField("ticket_event_starts_at", e.target.value)} required /></div></div>}

              {error && <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}
              <Button type="submit" disabled={saving} className="gap-2"><Save className="h-4 w-4" />{saving ? "שומר..." : "שמור טיוטה"}</Button>
            </form>
          </Card>
        )}
      </main>
    </div>
  );
}
