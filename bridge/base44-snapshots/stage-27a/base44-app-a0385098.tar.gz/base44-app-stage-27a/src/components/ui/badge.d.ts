import * as React from "react";

export type BadgeVariant = "default" | "secondary" | "destructive" | "outline";

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: BadgeVariant | null;
}

export declare function Badge(props: BadgeProps): React.JSX.Element;
export declare const badgeVariants: (props?: {
  variant?: BadgeVariant | null;
  className?: string;
}) => string;
