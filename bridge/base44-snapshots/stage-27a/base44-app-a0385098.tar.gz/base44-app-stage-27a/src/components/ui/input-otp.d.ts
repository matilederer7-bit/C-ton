import * as React from "react";
import type { OTPInputProps } from "input-otp";

export declare const InputOTP: React.ForwardRefExoticComponent<
  OTPInputProps & React.RefAttributes<HTMLInputElement>
>;
export declare const InputOTPGroup: React.ForwardRefExoticComponent<
  React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>
>;
export interface InputOTPSlotProps extends React.HTMLAttributes<HTMLDivElement> {
  index: number;
}
export declare const InputOTPSlot: React.ForwardRefExoticComponent<
  InputOTPSlotProps & React.RefAttributes<HTMLDivElement>
>;
export declare const InputOTPSeparator: React.ForwardRefExoticComponent<
  React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>
>;
