import * as React from "react";

type DivComponent = React.ForwardRefExoticComponent<
  React.HTMLAttributes<HTMLDivElement> & React.RefAttributes<HTMLDivElement>
>;

export declare const Card: DivComponent;
export declare const CardHeader: DivComponent;
export declare const CardFooter: DivComponent;
export declare const CardTitle: DivComponent;
export declare const CardDescription: DivComponent;
export declare const CardContent: DivComponent;
