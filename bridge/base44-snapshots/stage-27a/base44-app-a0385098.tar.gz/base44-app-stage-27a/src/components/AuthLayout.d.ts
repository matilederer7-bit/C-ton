import * as React from "react";

export interface AuthLayoutProps {
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  footer?: React.ReactNode;
  children?: React.ReactNode;
}

export default function AuthLayout(props: AuthLayoutProps): React.JSX.Element;
