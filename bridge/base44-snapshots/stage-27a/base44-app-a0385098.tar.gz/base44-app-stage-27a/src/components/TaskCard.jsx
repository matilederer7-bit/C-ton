import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, User, Calendar, Pencil, Trash2, ArrowRight, ArrowLeft } from "lucide-react";

const PRIORITY_CONFIG = {
  urgent: { label: "דחוף", className: "bg-red-500/10 text-red-600 border-red-500/30" },
  high: { label: "גבוהה", className: "bg-orange-500/10 text-orange-600 border-orange-500/30" },
  medium: { label: "בינונית", className: "bg-blue-500/10 text-blue-600 border-blue-500/30" },
  low: { label: "נמוכה", className: "bg-slate-500/10 text-slate-500 border-slate-500/30" },
};

export default function TaskCard({ task, onEdit, onDelete, onMove, compact }) {
  const priority = PRIORITY_CONFIG[task.priority] || PRIORITY_CONFIG.medium;

  return (
    <Card className="p-4 space-y-3 hover:shadow-md transition-shadow border-border/60 group" dir="rtl">
      <div className="flex items-start justify-between gap-2">
        <h3 className="font-semibold text-sm leading-tight flex-1">{task.title}</h3>
        <Badge variant="outline" className={priority.className + " shrink-0"}>
          {priority.label}
        </Badge>
      </div>
      {task.description && !compact && (
        <p className="text-xs text-muted-foreground line-clamp-2">{task.description}</p>
      )}
      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
        {task.assignee && (
          <span className="flex items-center gap-1">
            <User className="w-3 h-3" /> {task.assignee}
          </span>
        )}
        {task.location && (
          <span className="flex items-center gap-1">
            <MapPin className="w-3 h-3" /> {task.location}
          </span>
        )}
        {task.due_date && (
          <span className="flex items-center gap-1">
            <Calendar className="w-3 h-3" /> {task.due_date}
          </span>
        )}
      </div>
      <div className="flex items-center justify-between pt-1 border-t border-border/40">
        <div className="flex gap-1">
          {task.status !== "backlog" && (
            <button
              onClick={() => onMove(task, "backlog")}
              className="p-1.5 hover:bg-muted rounded-md transition-colors"
              title="חזרה לתור"
            >
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
          {task.status !== "in_progress" && (
            <button
              onClick={() => onMove(task, "in_progress")}
              className="p-1.5 hover:bg-muted rounded-md transition-colors"
              title="העבר לביצוע"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          )}
          {task.status !== "done" && (
            <button
              onClick={() => onMove(task, "done")}
              className="p-1.5 hover:bg-muted rounded-md transition-colors"
              title="סיום"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={() => onEdit(task)}
            className="p-1.5 hover:bg-muted rounded-md transition-colors"
            title="עריכה"
          >
            <Pencil className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onDelete(task)}
            className="p-1.5 hover:bg-red-50 hover:text-red-600 rounded-md transition-colors"
            title="מחיקה"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </Card>
  );
}