import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
// Add page imports here
import Home from './pages/Home';
import PublicDeal from './pages/PublicDeal';
import SellerProfile from './pages/SellerProfile';
import SellerDashboard from './pages/SellerDashboard';
import SellerDealDetail from './pages/SellerDealDetail';
import SellerDealEdit from './pages/SellerDealEdit';
import SellerFulfillment from './pages/SellerFulfillment';
import SellerReceipts from './pages/SellerReceipts';
import SellerDigitalFulfillment from './pages/SellerDigitalFulfillment';
import SellerAnalytics from './pages/SellerAnalytics';
import SellerPayouts from './pages/SellerPayouts';
import SellerDealImages from './pages/SellerDealImages';
import AdminOverview from './pages/AdminOverview';
import AdminSellers from './pages/AdminSellers';
import AdminSupport from './pages/AdminSupport';
import AdminDistribution from './pages/AdminDistribution';
import AdminForensics from './pages/AdminForensics';
import AdminNotifications from './pages/AdminNotifications';
import AdminControls from './pages/AdminControls';
import AdminDeals from './pages/AdminDeals';
import AdminSearch from './pages/AdminSearch';
import AdminSystemStatus from './pages/AdminSystemStatus';
import AdminPayouts from './pages/AdminPayouts';
import BuyerTracking from './pages/BuyerTracking';
import DistributorPortal from './pages/DistributorPortal';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      {/* Add your page Route elements here */}
      <Route path="/" element={<Home />} />
      <Route path="/seller" element={<SellerDashboard />} />
      <Route path="/seller/deal/:dealId" element={<SellerDealDetail />} />
      <Route path="/seller/deal/:dealId/edit" element={<SellerDealEdit />} />
      <Route path="/seller/deal/:dealId/images" element={<SellerDealImages />} />
      <Route path="/seller/deal/:dealId/fulfillment" element={<SellerFulfillment />} />
      <Route path="/seller/deal/:dealId/receipts" element={<SellerReceipts />} />
      <Route path="/seller/deal/:dealId/digital-fulfillment" element={<SellerDigitalFulfillment />} />
      <Route path="/seller/profile" element={<SellerProfile />} />
      <Route path="/seller/analytics" element={<SellerAnalytics />} />
      <Route path="/seller/payouts" element={<SellerPayouts />} />
      <Route path="/distributor" element={<DistributorPortal />} />
      <Route path="/admin" element={<AdminOverview />} />
      <Route path="/admin/sellers" element={<AdminSellers />} />
      <Route path="/admin/support" element={<AdminSupport />} />
      <Route path="/admin/distribution" element={<AdminDistribution />} />
      <Route path="/admin/forensics" element={<AdminForensics />} />
      <Route path="/admin/notifications" element={<AdminNotifications />} />
      <Route path="/admin/controls" element={<AdminControls />} />
      <Route path="/admin/deals" element={<AdminDeals />} />
      <Route path="/admin/deals/:dealId" element={<AdminDeals />} />
      <Route path="/admin/search" element={<AdminSearch />} />
      <Route path="/admin/user/:kind/:ref" element={<AdminSearch />} />
      <Route path="/admin/system" element={<AdminSystemStatus />} />
      <Route path="/admin/payouts" element={<AdminPayouts />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {
  return (
    <QueryClientProvider client={queryClientInstance}>
      <Router>
        <ScrollToTop />
        <Routes>
          <Route path="/deal/:dealId" element={<PublicDeal />} />
          <Route path="/app/track/:participantId" element={<BuyerTracking />} />
          <Route path="/*" element={
            <AuthProvider>
              <AuthenticatedApp />
            </AuthProvider>
          } />
        </Routes>
      </Router>
      <Toaster />
    </QueryClientProvider>
  )
}

export default App