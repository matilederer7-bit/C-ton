# AGENTS.md

## Project Context

This is a Base44 app repository. Treat it as user-owned application code, keep changes focused on the user's request, and preserve existing project conventions.

Start with `README.md` for local setup, environment variables, and publish workflow.

## Base44 References

- CLI overview: https://docs.base44.com/developers/references/cli/get-started/overview.md
- Agent skills: https://docs.base44.com/developers/backend/overview/skills.md

If your agent supports Agent Skills, install or update Base44 skills before Base44-specific work:

```bash
npx skills add base44/skills
```

## Key Files

- `src/`: frontend application source.
- `src/api/base44Client.js`: frontend Base44 SDK client.
- `vite.config.js`: Vite config and Base44 Vite plugin setup.
- `.env.local`: local-only environment values; never commit secrets.

## Working Notes

- Use `base44 dev` as the default local development command when you need the local Base44 backend. It can run the backend and frontend together.
- When docs or code mention the frontend being started automatically, that usually means the Base44 project config includes `site.serveCommand`, for example `"serveCommand": "npm run dev"` in `base44/config.jsonc`.
- Use `npm run dev` only for frontend-only work against the hosted Base44 backend.
- Prefer the existing Base44 CLI workflow over adding new npm scripts for Base44-specific tasks.
- Reuse the existing SDK client and Vite plugin patterns before adding new Base44 integration paths.
- Run the relevant checks from `package.json` before finishing code changes.

## Parallel Agent Coordination

Two coding agents may work on this app at the same time. Avoid last-writer-wins edits.

- Before editing an existing file, inspect `git log -3 -- <path>` and current `git status`.
- If the same file received a new commit while you were working, stop and merge intentionally; do not repeatedly overwrite/reapply in a loop.
- Prefer independent files/surfaces when another agent is actively changing a path.
- Stage 30 currently owns constitution/enforcement work under `scripts/base44-constitution-*`, `base44/lib/domain-*`, and `base44/functions/transition-engine/`. Do not rewrite those files from unrelated tasks.
- Product/UI work should not change canonical Deal/Buyer/Money transitions or add new Action names without first updating the constitution conflict register.
- Every meaningful stage ends with build/lint or focused gates, a Base44 checkpoint, and an update to the migration status documentation.
