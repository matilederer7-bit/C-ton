import fs from "node:fs";
import path from "node:path";
import {
  Action,
  BuyerState,
  DealState,
  ErrorCode,
  MoneyState,
  thresholdUnits,
} from "../base44/lib/domain-contract.mjs";

const ROOT = process.cwd();
const FUNCTION_ROOT = path.join(ROOT, "base44/functions");
const SOURCE_ROOTS = [FUNCTION_ROOT, path.join(ROOT, "src")];
const OFFICIAL_ACTIONS = new Set(Object.values(Action));
const DEAL_STATES = new Set(Object.values(DealState));
const BUYER_STATES = new Set(Object.values(BuyerState));
const MONEY_STATES = new Set(Object.values(MoneyState));
const ERROR_CODES = new Set(Object.values(ErrorCode));

function walk(root) {
  if (!fs.existsSync(root)) return [];
  const out = [];
  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    const file = path.join(root, entry.name);
    if (entry.isDirectory()) out.push(...walk(file));
    else if (/\.(?:m?[jt]sx?)$/.test(entry.name)) out.push(file);
  }
  return out;
}

function rel(file) {
  return path.relative(ROOT, file).replaceAll(path.sep, "/");
}

function lineOf(text, index) {
  return text.slice(0, index).split("\n").length;
}

const findings = [];
function finding(rule, file, line, detail) {
  findings.push({ rule, file: rel(file), line, detail });
}

function scanBackendMutation(file, text) {
  if (rel(file).startsWith("base44/functions/transition-engine/")) return;
  const updatePattern = /\.(?:update|updateMany)\s*\(/g;
  for (const match of text.matchAll(updatePattern)) {
    const start = match.index ?? 0;
    const chunk = text.slice(start, start + 2200);
    const stateMutation = /\$set\s*:\s*\{[^}]{0,1500}\b(state|buyer_state|money_state)\s*:/s.exec(chunk);
    if (stateMutation) finding("P0.1", file, lineOf(text, start), `state mutation outside transition-engine: ${stateMutation[1]}`);
  }
}

function scanActionLiterals(file, text) {
  const re = /action_name\s*:\s*["'`]([^"'`]+)["'`]/g;
  for (const match of text.matchAll(re)) {
    const value = match[1];
    if (!OFFICIAL_ACTIONS.has(value)) finding("P0.2_ACTION", file, lineOf(text, match.index ?? 0), `illegal Action literal: ${value}`);
  }
}

function scanErrorCodeLiterals(file, text) {
  const re = /\bcode\s*:\s*["'`]([A-Z][A-Z0-9_]+)["'`]/g;
  for (const match of text.matchAll(re)) {
    const value = match[1];
    if (value.includes("STAGE") || value.includes("PASS")) continue;
    if (!ERROR_CODES.has(value)) finding("P0.2_ERROR", file, lineOf(text, match.index ?? 0), `non-canonical ErrorCode literal: ${value}`);
  }
}

function scanPaymentSdk(file, text) {
  const relative = rel(file);
  const hasProviderSdk = /(?:from\s*["'](?:@stripe\/stripe-js|@stripe\/react-stripe-js|stripe|braintree|paypal)|require\s*\(\s*["'](?:stripe|braintree|paypal))/i.test(text);
  if (hasProviderSdk && !relative.includes("/workers/")) finding("P0.3", file, 1, "Payment SDK import outside /workers/");
}

function scanMutatingEndpointIdempotency(file, text) {
  if (!rel(file).startsWith("base44/functions/")) return;
  const mutates = /\.(?:create|update|updateMany|delete)\s*\(/.test(text);
  if (!mutates) return;
  const hasIdem = /idempotency[_-]?key/i.test(text);
  if (!hasIdem) finding("P0.4", file, 1, "mutating backend function has no idempotency_key contract");
}

for (const root of SOURCE_ROOTS) {
  for (const file of walk(root)) {
    const text = fs.readFileSync(file, "utf8");
    if (file.startsWith(FUNCTION_ROOT)) {
      scanBackendMutation(file, text);
      scanActionLiterals(file, text);
      scanErrorCodeLiterals(file, text);
      scanMutatingEndpointIdempotency(file, text);
    }
    scanPaymentSdk(file, text);
  }
}

const thresholdCases = [
  [100, 90],
  [11, 10],
  [51, 46],
  [50, 45],
];
for (const [minimum, expected] of thresholdCases) {
  const actual = thresholdUnits(minimum);
  if (actual !== expected) findings.push({ rule: "P0.5", file: "base44/lib/domain-contract.mjs", line: 1, detail: `threshold ${minimum}: expected ${expected}, got ${actual}` });
}

const rules = [...new Set(findings.map((item) => item.rule))].sort();
console.log(JSON.stringify({
  ok: findings.length === 0,
  findings_count: findings.length,
  failing_rules: rules,
  findings,
  canonical_counts: {
    deal_states: DEAL_STATES.size,
    buyer_states: BUYER_STATES.size,
    money_states: MONEY_STATES.size,
    actions: OFFICIAL_ACTIONS.size,
    error_codes: ERROR_CODES.size,
  },
}, null, 2));

if (findings.length) process.exit(1);
