# Siton Constitution Addendum v1.6 — Participant Join Authorization Action

Date: 2026-08-12
Status: approved project-owner decision
Scope: the canonical Buyer and Money transitions created by a successfully authorized Join

## Versioned decision

The closed official Action list is extended by exactly one Action:

`participant.join_authorize`

This is the ninth official Action. It represents one indivisible intent only: after external payment authorization has been proven, register the committed participant and move the participant from `NotJoined` to `JoinedAuthorized` and from `NoFinancial` to `AuthHeld`.

## Mandatory semantics

- Legal Buyer transition: `NotJoined -> JoinedAuthorized` only.
- Legal Money transition: `NoFinancial -> AuthHeld` only.
- The two transitions are a pair. Neither may be committed without the other.
- A valid SHA-256 hash of authorization evidence is mandatory. The narrow PostgreSQL boundary stores the hash, not buyer PII, card data, authorization ids or payment tokens.
- The Reservation Commit, both State changes and both canonical Audit rows must be written in one PostgreSQL transaction.
- Any failure in either Audit insert must roll back the Reservation Commit, committed-unit counter and both State changes.
- The action uses the Join idempotency key. Replay with the same evidence returns the canonical result; replay with different evidence fails closed.
- Concurrent replay must leave one committed participant projection and exactly two Audit rows: one `buyer_state` row and one `money_state` row.
- A missing, invalid or failed authorization does not commit the Reservation, does not change Buyer or Money State, does not create canonical Audit and does not count toward committed units.
- Base44 may create its local Participant and Deal projections only after PostgreSQL reports `JoinedAuthorized`, `AuthHeld`, the matching evidence hash and exactly two Join-authorization Audit rows.

## Contract changes

The following canonical contracts now include `participant.join_authorize`:

- the official Action enum
- the Audit `action_name` CHECK
- the idempotency `action_name` CHECK
- the paired Buyer and Money transition mapping for authorized Join

No other State, Action, ErrorCode or transition is changed by this addendum.

## Safety boundary

This addendum legalizes the canonical Action and its atomic evidence contract. It does not connect a payment provider, enable real Join, configure PostgreSQL credentials or make the product production-ready. Join remains fail-closed until the managed non-production PostgreSQL path and real authorization provider are connected and repeatedly proven end to end.
