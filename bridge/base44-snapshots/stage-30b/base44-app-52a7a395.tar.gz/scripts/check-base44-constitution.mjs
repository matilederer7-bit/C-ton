import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';

const stateValues = ['Draft','PendingTarget','TargetReached','ClosedForJoining','ReadyForCharging','Charging','CompletionWindow','Completed','Failed','Cancelled','NotJoined','JoinedAuthorized','LockedIn','ChargingAttempt','ChargedSuccess','ChargeFailedCompletion','Recovered','Dropped','DealCompleted','DealFailed','NoFinancial','AuthHeld','AuthLocked','ChargeAttempt','ChargeFailedRecovery','RecoveredCharge','AuthReleased','Refunded'];
const actionValues = ['deal.publish','deal.target_reached','participant.join_authorize','deal.close_joining','deal.prepare_charging','charging.start','charging.recovery','charging.finalize','refund.issue'];
const errorValues = ['INVALID_INPUT','ILLEGAL_STATE_TRANSITION','NOT_IN_WINDOW','WINDOW_NOT_EXPIRED','IDEMPOTENT_REPLAY','PAYMENT_FAILED','AUTH_EXPIRED','FORBIDDEN_ACTION','TEMPORARILY_UNAVAILABLE'];
function walk(dir){if(!fs.existsSync(dir))return[];return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>{const f=path.join(dir,e.name);return e.isDirectory()?walk(f):[f]});}
const backendFiles=walk('base44/functions').filter(f=>f.endsWith('.ts'));
const codeFiles=[...walk('base44'),...walk('src')].filter(f=>/\.(?:ts|tsx|js|jsx)$/.test(f));
const failures=[];const passes=[];const blockers=[];
function quoted(line,value){return line.includes(`"${value}"`)||line.includes(`'${value}'`);}

for(const file of backendFiles){
  if(file.endsWith('/contract.ts'))continue;
  const lines=fs.readFileSync(file,'utf8').split('\n');
  lines.forEach((line,index)=>{
    for(const value of [...stateValues,...actionValues,...errorValues]) if(quoted(line,value)) failures.push(`P0.2 literal ${value} at ${file}:${index+1}`);
    if(/\b(?:fail|err|error|responseError)\([^\n]*,\s*["'][a-z][a-z0-9_:-]*["']\s*\)/.test(line)) failures.push(`P0.2 non-canonical system error code at ${file}:${index+1}`);
    if(/\bcode\s*:\s*["'][a-z][a-z0-9_:-]*["']/.test(line) && !/\berror_code\s*:/.test(line)) failures.push(`P0.2 non-canonical object error code at ${file}:${index+1}`);
    if(file!=='base44/functions/transition-engine/entry.ts' && /\$set\s*:\s*\{[^\n]*(?:state|buyer_state|money_state)\s*:/.test(line)) failures.push(`P0.1 state DB mutation outside transition engine at ${file}:${index+1}`);
  });
}
for(const file of codeFiles){
  const lines=fs.readFileSync(file,'utf8').split('\n');
  lines.forEach((line,index)=>{
    if(/(?:from\s+["'](?:stripe|@stripe\/[^"']+|paypal|braintree)["']|require\(["'](?:stripe|@stripe\/[^"']+|paypal|braintree)["'])/i.test(line) && !file.replaceAll('\\','/').includes('/workers/')) failures.push(`P0.3 payment SDK outside workers at ${file}:${index+1}`);
  });
}
if(!failures.some(x=>x.startsWith('P0.2')))passes.push('P0.2 closed State/Action/Error constants: PASS');
if(!failures.some(x=>x.startsWith('P0.3')))passes.push('P0.3 payment SDK import boundary across repo code: PASS');

const mutatingEntrypoints=[
  'base44/functions/join-deal/entry.ts',
  'base44/functions/publish-deal/entry.ts',
  'base44/functions/close-joining/entry.ts',
  'base44/functions/prepare-charging/entry.ts',
  'base44/functions/start-charging/entry.ts',
  'base44/functions/apply-charge-results/entry.ts',
  'base44/functions/apply-recovery-results/entry.ts',
  'base44/functions/finalize-deal/entry.ts',
];
for(const file of mutatingEntrypoints){
  const source=fs.readFileSync(file,'utf8');
  if(!source.includes('idempotency_key')||!/(required|idempotencyKey|idempotency_key is required)/.test(source)) failures.push(`P0.4 mutating endpoint lacks required idempotency at ${file}`);
}
if(!failures.some(x=>x.startsWith('P0.4')))passes.push('P0.4 mutating product endpoints require idempotency: PASS');
blockers.push('C-08 strict HTTP-method wording remains unresolved for read-only Base44 POST transport');

const constitutionSource=fs.readFileSync('base44/shared/constitution.ts','utf8');
const compiled=ts.transpileModule(constitutionSource,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const c=await import(`data:text/javascript;base64,${Buffer.from(compiled).toString('base64')}`);
const thresholdCases=[[100,89,false],[11,9,false],[11,10,true],[51,46,true],[50,50,true]];
if(thresholdCases.every(([min,success,expected])=>(success>=c.thresholdUnits(min))===expected))passes.push('P0.5 90% ceiling cases: PASS');else failures.push('P0.5 threshold cases failed');

const guard=fs.readFileSync('base44/functions/payment-attempt-guard/entry.ts','utf8');
const engine=fs.readFileSync('base44/functions/transition-engine/entry.ts','utf8');
const joinSource=fs.readFileSync('base44/functions/join-deal/entry.ts','utf8');
const reconcileJoinSource=fs.readFileSync('base44/functions/reconcile-join-intents/entry.ts','utf8');
const inventoryBridgeSource=fs.readFileSync('base44/functions/inventory-bridge/entry.ts','utf8');
if(!(c.Action.DealTargetReached==='deal.target_reached'&&engine.includes('Action.DealTargetReached')&&engine.includes('assertTargetReachedAllowed')&&engine.includes('TRANSITION_INTERNAL_CALL_SECRET')&&joinSource.includes('functions.invoke("transition-engine"')&&joinSource.includes('Action.DealTargetReached')&&reconcileJoinSource.includes('functions.invoke("transition-engine"')&&reconcileJoinSource.includes('Action.DealTargetReached')))failures.push('P0.1 TargetReached centralized transition enforcement missing');
if(!(c.Action.ParticipantJoinAuthorize==='participant.join_authorize'&&joinSource.includes('Action.ParticipantJoinAuthorize')&&joinSource.includes('authorization_evidence_hash')&&joinSource.includes('join_authorize_audit_count')&&inventoryBridgeSource.includes('authorization_evidence_hash')))failures.push('P0.2 participant.join_authorize canonical Action or PostgreSQL evidence gate missing');
else {
  expectCode(()=>c.assertJoinAuthorizeAllowed(c.BuyerState.NotJoined,c.MoneyState.NoFinancial,''),c.ErrorCode.IllegalStateTransition,'join authorize without evidence hash');
  expectCode(()=>c.assertJoinAuthorizeAllowed(c.BuyerState.JoinedAuthorized,c.MoneyState.NoFinancial,'a'.repeat(64)),c.ErrorCode.IllegalStateTransition,'join authorize from non-source Buyer State');
  c.assertJoinAuthorizeAllowed(c.BuyerState.NotJoined,c.MoneyState.NoFinancial,'a'.repeat(64));
  passes.push('P0.2 participant.join_authorize canonical Action, source-State guard and PostgreSQL evidence gate: PASS');
}
if(guard.includes('MAX_ATTEMPTS = 3')&&guard.includes('30 * 60_000')&&guard.includes('payment_retry_attempt_count:currentCount')&&(engine.match(/attempt guard evidence missing/g)||[]).length===2)passes.push('P0.7 retry-storm structural enforcement: PASS');else failures.push('P0.7 retry-storm structural enforcement missing');
if(engine.includes('scheduleUnknownPaymentReconcile')&&engine.includes('without visible State change')&&fs.existsSync('base44/functions/reconcile-payment-jobs/entry.ts'))passes.push('P0.8/P0.9 UNKNOWN reconcile path: PASS');else failures.push('P0.8/P0.9 UNKNOWN reconcile path missing');

function expectCode(fn,code,label){try{fn();failures.push(`P0.10 ${label} did not throw`);}catch(error){if(error?.code!==code)failures.push(`P0.10 ${label} expected ${code}, got ${error?.code||error?.message}`);}}
function expectTargetCode(fn,code,label){try{fn();failures.push(`P0.1 ${label} did not throw`);}catch(error){if(error?.code!==code)failures.push(`P0.1 ${label} expected ${code}, got ${error?.code||error?.message}`);}}
const now=Date.now();
expectTargetCode(()=>c.assertTargetReachedAllowed(c.DealState.PendingTarget,9,10),c.ErrorCode.IllegalStateTransition,'target reached below minimum');
c.assertTargetReachedAllowed(c.DealState.PendingTarget,10,10);
expectTargetCode(()=>c.assertTargetReachedAllowed(c.DealState.TargetReached,10,10),c.ErrorCode.IllegalStateTransition,'target reached replay through a new transition');
if(!failures.some(x=>x.startsWith('P0.1 ')))passes.push('P0.1 TargetReached transition is centralized, minimum-gated and internally authenticated: PASS');
expectCode(()=>c.assertChargingStartAllowed(c.DealState.CompletionWindow,new Date(now+3600000).toISOString()),c.ErrorCode.ForbiddenAction,'charging.start inside CompletionWindow');
expectCode(()=>c.assertRecoveryAllowed(c.DealState.CompletionWindow,new Date(now+3600000).toISOString(),0,now,false),c.ErrorCode.ForbiddenAction,'recovery without eligible participant');
expectCode(()=>c.assertFinalizeAllowed(c.DealState.CompletionWindow,new Date(now+3600000).toISOString(),now),c.ErrorCode.WindowNotExpired,'finalize before expiry');
if(c.resolveFinalDealState(9,10)!==c.DealState.Failed)failures.push('P0.10 finalize below threshold must resolve Failed');
if(!failures.some(x=>x.startsWith('P0.10')))passes.push('P0.10 Completion Window mandatory cases: PASS');

blockers.push('P0.7 live two-worker race integration proof is still required before production');
blockers.push('P0.11 canonical PostgreSQL State+Audit transaction proof is not connected in Base44 yet');
console.log(JSON.stringify({passes,failures,blockers},null,2));
process.exitCode=failures.length?1:0;
