# Siton Constitution conflicts — 2026-08-11

Status: blocking for production where noted. No silent interpretation is allowed.

## C-02 — RESOLVED: PendingTarget to TargetReached Action

Resolved on 2026-08-12 by the project owner through Constitution Addendum v1.5.

The official Action list now includes `deal.target_reached`. It is a system-only, idempotent Action for `PendingTarget -> TargetReached` after authoritative committed Join units reach the full `min_units`. The 90 percent `threshold_units` value does not trigger this transition. Join and reconciliation no longer mutate Deal State directly; the central Transition Engine owns the conditional transition.

The source conflict is closed. P0.11 remains separate: production still requires a managed PostgreSQL proof that State and canonical Audit are written in the same transaction.

## C-03 — Refund is a legal Action but has no canonical Outbox/PaymentAttempt representation

`refund.issue` is a legal Action and the product requires refunds. The canonical Outbox event_type list has no refund job. The canonical PaymentAttempt attempt_type list contains only `charge_start`, `recovery`, `reconcile` and has no refund attempt.

Current Base44 migration has broader migration-only types. They must not be declared canonical until a versioned Constitution/DB contract resolves the representation.

## C-04 — Cancelled is a legal DealState but no transition reaches it

`Cancelled` appears in the closed DealState list. Product requirements allow seller cancellation before ReadyForCharging. The closed Deal transition table does not include any `-> Cancelled` transition and the closed Action list has no cancellation Action.

The current cancel endpoint remains fail-closed. Do not invent a transition or Action.

## C-05 — repeat purchases conflict with canonical participant uniqueness

The current product specification explicitly allows the same buyer to make multiple separate purchases in the same Deal. The canonical PostgreSQL contract has `UNIQUE (deal_id, user_id)` on participants.

Do not remove the uniqueness constraint or suppress repeat purchases by interpretation. A versioned data-model decision is required, for example one Participant identity plus multiple purchase/reservation rows, or removal/change of the uniqueness contract.

## C-06 — buyer cancellation state conflict

The current product specification describes a K9 `User Cancelled` buyer state. The closed Constitution BuyerState list does not include such a state and explicitly forbids additional states.

Do not add K9 to code without a versioned Constitution change. Do not pretend `Dropped` or `DealFailed` is equivalent without an explicit decision.

## C-07 — canonical Outbox names differ from migration Outbox names

Canonical DB contract event types: `enqueue_charge_job`, `enqueue_recovery_job`, `enqueue_finalize_job`, `process_webhook`, `notify_success`, `notify_failure`.
Migration implementation currently uses `charge_deal`, `recovery_deal`, `finalize_deal`, plus migration/task events such as `deadline_check` and refund-related events.

Before production, either migrate to the canonical names and separate non-Outbox task scheduling, or version the DB contract. No aliasing should be treated as canonical silently.

## C-08 — P0.4 HTTP-method wording conflicts with Base44 function transport

The enforcement checklist says every POST/PUT/DELETE requires idempotency. Base44 backend functions commonly use POST even for read-only operations such as status/list queries. The Constitution also describes idempotency as mandatory for external Actions and side effects.

Until a versioned clarification exists, all mutating/product Actions must require idempotency. Read-only POST functions will not be reclassified as mutating by guesswork. Production compliance should keep this item visible.

## C-09 — retry/DLQ timing has three conflicting canonical descriptions

The enforcement checklist says infrastructure failure receives 3 retries and then DLQ. Constitution section 10 says 3 immediate retries with backoff 1s/5s/30s, then a delayed Reconcile Job inside the Completion Window. The canonical PostgreSQL Outbox contract defines `max_attempts default 10`.

The migration Outbox currently uses a different bounded retry contract. Do not change it to 3 or 10, and do not declare P1.1 canonical, until a versioned Constitution decision reconciles immediate retries, delayed reconciliation and final DLQ timing.

## C-10 — fulfillment Audit action conflicts with the closed Action list

The approved Seller terminal UX asks a shipping-issue update to be written to `audit_log` with `action_name: support.shipping_issue`. The Constitution and canonical PostgreSQL `audit_log.action_name` CHECK allow only the seven closed Actions and explicitly forbid additional Action names.

Current fulfillment therefore keeps shipping status history in a dedicated operational event journal. It must not be represented as canonical Constitution Audit until a versioned Constitution/DB decision either adds legal support Actions or defines a separate non-State operational audit contract.

## C-11 — seller refund authority conflicts across current product/UX sources

One current product section says a seller may execute a refund up to 14 days after Deal completion. The approved Seller terminal UX says refund requests are handled only by the Siton team and the seller must not execute a manual refund. The Constitution also exposes `refund.issue` but does not resolve actor authority, and C-03 still blocks its canonical job/attempt representation.

The migration remains fail-closed for seller Refund/Capture/Void. Do not expose a seller refund execution control until the authority conflict and C-03 are resolved by a versioned decision.

## C-12 — participant.join_authorize has no canonical Action decision

The Join implementation records BuyerState and MoneyState evidence with `action_name: participant.join_authorize`. That name is not in the versioned official Action list, including Addendum v1.5.

This is not resolved by the TargetReached decision. The strict scanner must remain red for this name until the project owner either adds a versioned participant Join Action or defines these records as a separate non-canonical operational event contract that does not use `action_name`.

## Enforcement decision

- Keep real money disabled.
- Keep cancellation fail-closed.
- Do not add realtime UX work that depends on unresolved state semantics.
- Continue only with non-conflicting enforcement and projections.
- These conflicts must remain listed in PROJECT_STATUS.md until resolved by an explicit versioned Constitution decision.
