# Siton Constitution Addendum v1.5 — TargetReached Action

Date: 2026-08-12
Status: approved project-owner decision
Scope: the automatic Deal transition from PendingTarget to TargetReached

## Versioned decision

The closed official Action list is extended by exactly one Action:

`deal.target_reached`

This Action is a system-only Action. It represents one intent only: the automatic transition of a Deal from `PendingTarget` to `TargetReached`.

## Mandatory semantics

- Legal transition: `PendingTarget -> TargetReached` only.
- Trigger: committed and successfully authorized Join units are greater than or equal to `min_units`.
- The trigger uses the full minimum. `threshold_units`, the 90 percent financial-success threshold, must not trigger `TargetReached`.
- A Hold, pending authorization, failed authorization, released reservation or expired reservation does not count.
- The idempotency key is deterministic per Deal: `target-reached:<deal_id>`.
- Concurrent attempts must produce one state transition and one canonical Audit event.
- The state update and canonical Audit insert must occur in the same PostgreSQL transaction.
- This Action does not require an Outbox event because it does not itself create external work.
- The Action is not available as a seller, buyer or administrator control. It may be invoked only by the internal Join or Join-reconciliation path after authoritative committed-unit evidence exists.

## Contract changes

The following canonical contracts now include `deal.target_reached`:

- the official Action enum
- the Audit `action_name` CHECK
- the idempotency `action_name` CHECK
- the Deal transition mapping for `PendingTarget -> TargetReached`

No other State, Action, ErrorCode or transition is changed by this addendum.

## Base44 implementation status

- The Action exists in the shared TypeScript and JavaScript domain contracts.
- Join and Join reconciliation no longer mutate Deal State directly.
- Both paths call the central Transition Engine with a protected internal-call secret.
- The Transition Engine checks committed units against `min_units`, performs a conditional `PendingTarget` update and embeds the transition journal in the same Base44 document update.
- A normalized `DealAudit` record remains a derived projection after the document update.

The Base44 document-level implementation closes C-02 and the two former P0.1 violations. It does not by itself close P0.11. Production remains blocked until a managed PostgreSQL path proves the State and canonical Audit insert in one database transaction under concurrency.
