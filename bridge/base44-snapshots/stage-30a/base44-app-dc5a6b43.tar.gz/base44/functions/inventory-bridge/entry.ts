import { ErrorCode } from "../../shared/constitution.ts";
import { createClientFromRequest } from "npm:@base44/sdk";

const enc = new TextEncoder();
const ROUTES: Record<string, string> = {
  sync: "/v1/deals/sync",
  close: "/v1/deals/close",
  hold: "/v1/reservations/hold",
  commit: "/v1/reservations/commit",
  release: "/v1/reservations/release",
  lookup: "/v1/reservations/lookup",
  reservation_status: "/v1/reservations/status",
  status: "/v1/inventory/status"
};

function fail(status: number, error: string, code?: string, details?: unknown) {
  return Response.json({ ok: false, error, ...(code ? { code } : {}), ...(details ? { details } : {}) }, { status });
}

function stable(value: any): any {
  if (Array.isArray(value)) return value.map(stable);
  if (value === null || typeof value !== "object") return value;
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, stable(value[key])]));
}

function uuid(value: unknown, field: string) {
  const text = String(value || "").trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(text)) {
    throw Object.assign(new Error(`${field} must be a valid UUID`), { status: 400, code: `invalid_${field}` });
  }
  return text;
}

function positiveInt(value: unknown, field: string) {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1) throw Object.assign(new Error(`${field} must be a positive integer`), { status: 400, code: `invalid_${field}` });
  return n;
}

function text(value: unknown, field: string, max: number) {
  const result = String(value || "").trim();
  if (!result || result.length > max) throw Object.assign(new Error(`${field} is invalid`), { status: 400, code: `invalid_${field}` });
  return result;
}

async function sha256(value: string) {
  const out = await crypto.subtle.digest("SHA-256", enc.encode(value));
  return [...new Uint8Array(out)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function hmac(secret: string, value: string) {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const out = await crypto.subtle.sign("HMAC", key, enc.encode(value));
  return [...new Uint8Array(out)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function callReservation(operation: string, payload: Record<string, unknown>) {
  const baseUrl = String(Deno.env.get("RESERVATION_SERVICE_URL") || "").trim().replace(/\/+$/, "");
  const secret = String(Deno.env.get("RESERVATION_SERVICE_SHARED_SECRET") || "").trim();
  if (!baseUrl || secret.length < 32) throw Object.assign(new Error("reservation service is not configured"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
  if (!baseUrl.startsWith("https://") && Deno.env.get("RESERVATION_SERVICE_ALLOW_INSECURE_HTTP") !== "true") {
    throw Object.assign(new Error("reservation service requires HTTPS"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
  }
  const path = ROUTES[operation];
  if (!path) throw Object.assign(new Error("unsupported inventory operation"), { status: 400, code: ErrorCode.InvalidInput });
  const body = JSON.stringify(stable(payload));
  const timestamp = String(Math.floor(Date.now() / 1000));
  const bodyHash = await sha256(body);
  const signature = await hmac(secret, `${timestamp}\nPOST\n${path}\n${bodyHash}`);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(`${baseUrl}${path}`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-siton-timestamp": timestamp, "x-siton-signature": signature, ...(payload.idempotency_key ? { "idempotency-key": String(payload.idempotency_key) } : {}) },
      body,
      signal: controller.signal
    });
    let data: any = null;
    try { data = await response.json(); } catch { data = null; }
    if (!response.ok) throw Object.assign(new Error(String(data?.error || `reservation service returned ${response.status}`)), { status: response.status, code: String(data?.code || "reservation_service_error"), details: data?.details });
    return data;
  } catch (error: any) {
    if (error?.name === "AbortError") throw Object.assign(new Error("reservation service timed out"), { status: 503, code: ErrorCode.TemporarilyUnavailable });
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "method_not_allowed", ErrorCode.ForbiddenAction);
  const base44 = createClientFromRequest(req);
  let user: any;
  try { user = await base44.auth.me(); } catch { return fail(401, "authentication required", ErrorCode.ForbiddenAction); }
  if (String(user?.role || "") !== "admin") return fail(403, "admin required", ErrorCode.ForbiddenAction);

  let body: any;
  try { body = await req.json(); } catch { return fail(400, "invalid JSON body", ErrorCode.InvalidInput); }
  const operation = String(body?.operation || "").trim();
  try {
    let payload: Record<string, unknown>;
    if (operation === "sync") payload = { deal_id: uuid(body.deal_id, "deal_id"), max_units: positiveInt(body.max_units, "max_units"), min_units: positiveInt(body.min_units, "min_units"), status: "open", idempotency_key: text(body.idempotency_key, "idempotency_key", 200) };
    else if (operation === "close") payload = { deal_id: uuid(body.deal_id, "deal_id"), max_units: positiveInt(body.max_units, "max_units"), idempotency_key: text(body.idempotency_key, "idempotency_key", 200) };
    else if (operation === "hold") payload = { deal_id: uuid(body.deal_id, "deal_id"), qty: positiveInt(body.qty, "qty"), idempotency_key: text(body.idempotency_key, "idempotency_key", 200), request_hash: text(body.request_hash, "request_hash", 128) };
    else if (operation === "commit" || operation === "release" || operation === "reservation_status") payload = { reservation_id: uuid(body.reservation_id, "reservation_id") };
    else if (operation === "lookup") payload = { deal_id: uuid(body.deal_id, "deal_id"), idempotency_key: text(body.idempotency_key, "idempotency_key", 200) };
    else if (operation === "status") payload = { deal_id: uuid(body.deal_id, "deal_id") };
    else return fail(400, "unsupported inventory operation", ErrorCode.InvalidInput);
    return Response.json({ ok: true, operation, result: await callReservation(operation, payload) });
  } catch (error: any) {
    const status = Number(error?.status || error?.statusCode || 502);
    return fail(status >= 400 && status < 600 ? status : 502, String(error?.message || "reservation_service_error"), String(error?.code || "reservation_service_error"), error?.details);
  }
});
